--[[
    Axel Admin Menu - bootstrap

    Solves the fresh-install lockout, which is what sandbox hits hardest.

    Axel is authoritative over ranks: GetUserGroup returns AXELRank and
    PlayerInitialSpawn assigns it from the database, defaulting to "user".
    That is correct once someone holds superadmin, but on a fresh server
    nobody does, and the ways an operator would normally already be an admin
    are all bypassed:

      * A listen server host is superadmin to the engine. Axel overwrote that
        with the stored rank, so a hosted sandbox game left the host unable to
        open their own menu.

      * garrysmod/settings/users.txt is how dedicated servers without an admin
        mod assign superadmin. Nothing in Axel read it. The engine's original
        GetUserGroup is never captured either, and Axel calls the engine's
        SetUserGroup underneath with the Axel rank, so by the time any addon
        could ask, the engine's own answer has already been overwritten. The
        file is therefore parsed directly - it is the only source that survives
        the override.

    Three rules keep this from becoming a privilege-escalation hole:

      1. Promotion only ever happens from the root rank. A player who has been
         deliberately given any other rank is never touched, so this cannot
         undo a demotion or override a decision made in the menu.
      2. Every source is server-side and unforgeable by a client: a convar in
         server.cfg, the engine's own listen-host flag, and a file under
         garrysmod/settings that only the host can write.
      3. Nothing here grants a rank that does not already exist in the rank
         table.
]]

AXEL.Bootstrap = AXEL.Bootstrap or {}

local ownerConVar = CreateConVar("axel_owner_steamid", "",
    {FCVAR_PROTECTED, FCVAR_ARCHIVE},
    "SteamIDs granted superadmin on join while they hold the default rank. " ..
    "Comma separated, STEAM_0:X:Y or SteamID64. Set this in server.cfg.")

local listenHostConVar = CreateConVar("axel_bootstrap_listenhost", "1",
    {FCVAR_ARCHIVE},
    "Grant the listen server host superadmin when they hold the default rank.")

-- Independent of the old archived listen-host setting, so upgrading an
-- existing install also defaults new Sandbox hosts to user.
local sandboxHostConVar = CreateConVar("axel_bootstrap_sandboxhost", "0",
    {FCVAR_ARCHIVE},
    "Opt in to automatic superadmin for Sandbox listen hosts. Default: user.")

local usersFileConVar = CreateConVar("axel_bootstrap_usersfile", "1",
    {FCVAR_ARCHIVE},
    "Honour garrysmod/settings/users.txt when a player holds the default rank.")

local USERS_FILE = "settings/users.txt"

--[[ ------------------------------------------------------------------------
    SteamID handling
--------------------------------------------------------------------------- ]]

--[[
    Returns a canonical STEAM_0:X:Y string, or nil.

    users.txt entries are also allowed to be IP addresses, and those are
    deliberately dropped rather than guessed at: an IP cannot be tied to an
    account, so honouring one would hand superadmin to whoever next holds that
    address.
]]
local function canonicalSteamID(value)
    if (not isstring(value)) then return nil end

    value = string.upper(string.Trim(value))
    if (value == "") then return nil end

    if (string.match(value, "^STEAM_%d:%d:%d+$")) then return value end

    -- SteamID64s are 17 digits today, but match on convertibility rather than
    -- length so this does not rot if that ever changes.
    if (string.match(value, "^%d+$")) then
        local ok, converted = pcall(util.SteamIDFrom64, value)
        if (ok and isstring(converted) and
            string.match(converted, "^STEAM_%d:%d:%d+$")) then
            return converted
        end
    end

    return nil
end

AXEL.Bootstrap.CanonicalSteamID = canonicalSteamID

--- SteamIDs listed in axel_owner_steamid, as a set.
function AXEL.Bootstrap.Owners()
    local owners = {}

    for entry in string.gmatch(ownerConVar:GetString(), "[^,%s]+") do
        local steamid = canonicalSteamID(entry)
        if (steamid) then owners[steamid] = true end
    end

    return owners
end

--[[ ------------------------------------------------------------------------
    users.txt
--------------------------------------------------------------------------- ]]

--[[
    Parses garrysmod/settings/users.txt into steamid -> group.

    Read fresh each time rather than cached: an operator who adds themselves to
    the file expects a reconnect to be enough, not a map change. It is a small
    file read a handful of times per join at most.
]]
function AXEL.Bootstrap.ReadUsersFile()
    local result = {}

    if (not usersFileConVar:GetBool()) then return result end

    local raw = file.Read(USERS_FILE, "GAME")
    if (not raw or string.Trim(raw) == "") then return result end

    -- Malformed KeyValues throws rather than returning nil, and a syntax error
    -- in a config file must not take the server's join path with it.
    local ok, parsed = pcall(util.KeyValuesToTable, raw)
    if (not ok or not istable(parsed)) then
        MsgC(Color(220, 48, 52), "[Axel] ", Color(210, 213, 218),
            "Could not parse " .. USERS_FILE .. "; ignoring it.\n")
        return result
    end

    for group, entries in pairs(parsed) do
        -- An empty group block parses to a string, not a table.
        if (istable(entries) and isstring(group)) then
            group = string.lower(string.Trim(group))

            for _, value in pairs(entries) do
                local steamid = canonicalSteamID(value)
                if (steamid) then result[steamid] = group end
            end
        end
    end

    return result
end

--[[ ------------------------------------------------------------------------
    Who already holds superadmin
--------------------------------------------------------------------------- ]]

--[[
    Every stored player whose rank inherits superadmin.

    Reads the JSON rank backup as well as the table, because the case this
    exists to detect is a database that came back empty - and the backup is
    precisely what survives that.
]]
function AXEL.Bootstrap.SuperAdmins()
    local seen, found = {}, {}

    local function add(steamid, name, rank)
        steamid = tostring(steamid or "")
        if (steamid == "" or seen[steamid]) then return end
        if (not AXEL.InheritsFrom(rank, AXEL.SuperRank)) then return end

        seen[steamid] = true
        found[#found + 1] = {steamid = steamid, name = name or "?", rank = rank}
    end

    local rows = sql.Query("SELECT steamid, name, rank FROM axel_players")
    if (istable(rows)) then
        for _, row in ipairs(rows) do add(row.steamid, row.name, row.rank) end
    end

    for steamid, entry in pairs(AXEL.PlayerRankBackup or {}) do
        if (istable(entry)) then add(steamid, entry.name, entry.rank) end
    end

    return found
end

function AXEL.Bootstrap.HasSuperAdmin()
    return #AXEL.Bootstrap.SuperAdmins() > 0
end

--[[ ------------------------------------------------------------------------
    Resolution
--------------------------------------------------------------------------- ]]

--[[
    The rank this player should be promoted to, and why. nil for no change.

    Ordered most to least explicit, so an operator who sets the convar is not
    overruled by a stale users.txt entry.
]]
function AXEL.Bootstrap.Resolve(client)
    if (not IsValid(client) or not client:IsPlayer()) then return nil end
    if (client:IsBot()) then return nil end

    --[[
        The one rule that makes this safe to run on every join: a player who
        already holds anything other than the default rank is left alone.
        Without it, a superadmin demoted to user in the menu would be handed
        their rank straight back on reconnect.
    ]]
    if (client:GetUserGroup() ~= AXEL.RootRank) then return nil end

    local steamid = client:SteamID()

    if (AXEL.Bootstrap.Owners()[steamid]) then
        return AXEL.SuperRank, "axel_owner_steamid"
    end

    -- IsListenServerHost is an engine method Axel does not override, so it
    -- still answers correctly even when rank data is unreadable.
    local allowHost = listenHostConVar:GetBool()
    if (AXEL.IsSandbox()) then allowHost = sandboxHostConVar:GetBool() end
    if (allowHost and client:IsListenServerHost()) then
        return AXEL.SuperRank, "listen server host"
    end

    local group = AXEL.Bootstrap.ReadUsersFile()[steamid]
    if (group and AXEL.Ranks[group]) then
        return group, USERS_FILE
    end

    -- A users.txt group with no matching Axel rank is reported rather than
    -- silently ignored, since the operator plainly intended something.
    if (group) then
        MsgC(Color(226, 169, 60), "[Axel] ", Color(210, 213, 218),
            client:Nick() .. " is '" .. group .. "' in " .. USERS_FILE ..
            ", but no Axel rank by that name exists. Ignored.\n")
    end

    return nil
end

--[[ ------------------------------------------------------------------------
    Application
--------------------------------------------------------------------------- ]]

local function promote(client)
    if (not IsValid(client)) then return end

    local rank, reason = AXEL.Bootstrap.Resolve(client)
    if (not rank) then return end

    local ok, message = AXEL.SetRank(client, rank, 0, nil)

    if (not ok) then
        MsgC(Color(220, 48, 52), "[Axel] ", Color(210, 213, 218),
            "Bootstrap could not set " .. client:Nick() .. " to " .. rank ..
            ": " .. tostring(message) .. "\n")
        return
    end

    MsgC(Color(85, 184, 112), "[Axel] ", Color(210, 213, 218),
        client:Nick() .. " (" .. client:SteamID() .. ") granted '" .. rank ..
        "' via " .. reason .. ".\n")

    client:ChatPrint("[Axel] You have been granted '" .. rank ..
        "' (" .. reason .. "). Press F1 or type !menu to open the admin menu.")

    AXEL.Log("BOOTSTRAP", "Bootstrap", "setrank", client:SteamID(),
        rank .. " via " .. reason)
end

--[[
    Deferred by a frame deliberately.

    Hooks on the same event are stored in a table and iterated with pairs, so
    the order between this and AXEL.LoadRank is not defined. Running a frame
    later guarantees the stored rank has already been applied - otherwise
    LoadRank could overwrite the promotion immediately after it happened.
]]
hook.Add("PlayerInitialSpawn", "AXEL.Bootstrap", function(client)
    timer.Simple(0, function() promote(client) end)
end)

--[[
    Sweeps everyone already connected.

    Covers a mid-session install or lua_refresh, where PlayerInitialSpawn has
    long since fired for the very player who needs the promotion.
]]
function AXEL.Bootstrap.Sweep()
    for _, client in ipairs(player.GetAll()) do promote(client) end
end

hook.Add("InitPostEntity", "AXEL.BootstrapSweep", function()
    timer.Simple(1, AXEL.Bootstrap.Sweep)
end)

timer.Simple(1, AXEL.Bootstrap.Sweep)

--[[ ------------------------------------------------------------------------
    Guidance
--------------------------------------------------------------------------- ]]

--[[
    Says plainly what to do when nobody can administer the server.

    A silent lockout is the worst outcome here: the menu simply refuses to open
    and nothing explains why, which is the exact experience this module exists
    to remove.
]]
function AXEL.Bootstrap.Advise()
    if (AXEL.Bootstrap.HasSuperAdmin()) then return false end

    MsgC(Color(226, 169, 60), "\n[Axel] ", Color(238, 240, 243),
        "NO SUPERADMIN EXISTS ON THIS SERVER\n")
    MsgC(Color(210, 213, 218),
        "  Nobody can open the admin menu until one is set. Any one of these\n" ..
        "  will do it, in the server console:\n\n" ..
        "    axel_bootstrap_grant STEAM_0:1:12345678\n" ..
        "      Grants superadmin immediately. Works for offline players.\n\n" ..
        "    axel setrank \"Player Name\" superadmin\n" ..
        "      The normal command. The player must be connected.\n\n" ..
        "  Or, so that it survives a database wipe, add to server.cfg:\n\n" ..
        "    axel_owner_steamid \"STEAM_0:1:12345678\"\n\n" ..
        "  Sandbox defaults to user, including new listen hosts. Explicit owners\n" ..
        "  and settings/users.txt grants still apply. Run axel_bootstrap to see what\n" ..
        "  this server currently detects.\n\n")

    return true
end

hook.Add("InitPostEntity", "AXEL.BootstrapAdvise", function()
    timer.Simple(2, AXEL.Bootstrap.Advise)
end)

-- Repeat the advice when someone joins and still nobody is an admin, since an
-- operator is far more likely to be watching the console at that moment than
-- at startup.
hook.Add("PlayerInitialSpawn", "AXEL.BootstrapAdvise", function(client)
    timer.Simple(1, function()
        if (not IsValid(client)) then return end
        if (not AXEL.Bootstrap.Advise()) then return end

        MsgC(Color(210, 213, 218),
            "  Connected: " .. client:Nick() .. " " .. client:SteamID() .. "\n\n")
    end)
end)

--[[ ------------------------------------------------------------------------
    Console commands
--------------------------------------------------------------------------- ]]

local function report(client)
    local lines = {}
    local function line(text) lines[#lines + 1] = text end

    line("[Axel] Bootstrap report")

    local supers = AXEL.Bootstrap.SuperAdmins()
    if (#supers == 0) then
        line("  Stored superadmins: none. Nobody can administer this server.")
    else
        line("  Stored superadmins: " .. #supers)
        for _, entry in ipairs(supers) do
            line("    " .. entry.steamid .. "  " .. tostring(entry.name) ..
                "  (" .. tostring(entry.rank) .. ")")
        end
    end

    local owners, ownerCount = AXEL.Bootstrap.Owners(), 0
    for steamid in pairs(owners) do
        ownerCount = ownerCount + 1
        line("  axel_owner_steamid: " .. steamid)
    end
    if (ownerCount == 0) then line("  axel_owner_steamid: not set") end

    line("  Listen host bootstrap: " ..
        (GetConVar("axel_bootstrap_listenhost"):GetBool() and "on" or "off"))

    line("  Sandbox default rank: user")
    line("  Sandbox host bootstrap: " .. (sandboxHostConVar:GetBool() and "on" or "off"))

    local users = AXEL.Bootstrap.ReadUsersFile()
    local userCount = 0
    for steamid, group in pairs(users) do
        userCount = userCount + 1
        local known = AXEL.Ranks[group] and "" or "   <- no Axel rank by this name"
        line("  " .. USERS_FILE .. ": " .. steamid .. " = " .. group .. known)
    end
    if (userCount == 0) then
        line("  " .. USERS_FILE .. ": no usable entries" ..
            (GetConVar("axel_bootstrap_usersfile"):GetBool() and "" or " (disabled)"))
    end

    line("  Connected players:")
    for _, target in ipairs(player.GetAll()) do
        local rank, reason = AXEL.Bootstrap.Resolve(target)
        local pending = rank and ("  -> would become " .. rank .. " (" .. reason .. ")") or ""
        line("    " .. target:SteamID() .. "  " .. target:Nick() ..
            "  " .. target:GetUserGroup() .. pending ..
            (target:IsListenServerHost() and "  [listen host]" or ""))
    end

    for _, text in ipairs(lines) do
        if (IsValid(client)) then
            client:PrintMessage(HUD_PRINTCONSOLE, text)
        else
            print(text)
        end
    end
end

concommand.Add("axel_bootstrap", function(client)
    --[[
        A locked-out player cannot read the server console, so this has to be
        available to them. It only reports; it changes nothing. The rank of
        every connected player is already sent to the menu, so this discloses
        nothing a client could not otherwise see.
    ]]
    report(IsValid(client) and client or nil)
end)

concommand.Add("axel_bootstrap_grant", function(client, _, args)
    -- Server console only. This is the one path that grants superadmin without
    -- a permission check, so it must not be reachable by a connected player
    -- under any circumstances.
    if (IsValid(client)) then
        client:PrintMessage(HUD_PRINTCONSOLE,
            "[Axel] axel_bootstrap_grant can only be run from the server console.")
        return
    end

    local steamid = canonicalSteamID(args and args[1] or "")
    if (not steamid) then
        print("[Axel] Usage: axel_bootstrap_grant <STEAM_0:X:Y or SteamID64> [rank]")
        print("[Axel] Run axel_bootstrap to list connected players and their SteamIDs.")
        return
    end

    local rank = string.lower(string.Trim(tostring(args and args[2] or AXEL.SuperRank)))
    if (not AXEL.Ranks[rank]) then
        print("[Axel] No such rank '" .. rank .. "'.")
        return
    end

    -- Prefer the live player so the rank applies to their session immediately;
    -- AXEL.SetRank accepts a bare SteamID for anyone offline.
    local target = steamid
    for _, connected in ipairs(player.GetAll()) do
        if (connected:SteamID() == steamid) then target = connected break end
    end

    local ok, message = AXEL.SetRank(target, rank, 0, nil)
    print("[Axel] " .. tostring(message))

    if (ok and not IsValid(target)) then
        print("[Axel] " .. steamid .. " is offline; the rank applies on their next join.")
    end
end)
