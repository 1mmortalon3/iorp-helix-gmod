IMPERIAL ORDER COMMUNICATIONS THEME
==================================

This package is a themed build of communications_upd32.8alpha.

CHANGES
- Unified red, black, steel-gray and white Imperial interface.
- Imperial crest in communications window headers.
- Imperial Communications labels, relay branding and spawn categories.
- Imperial-themed channel colors.
- Default channel corrected from the nonexistent Combine channel to Imperial Comms.
- External close-button image dependency removed.
- Original networking, channel, relay, admin and comms behavior retained.

INSTALL
Place the imperial_order_communications folder in garrysmod/addons/.
Remove or disable the unthemed communications_upd32.8alpha copy to avoid duplicate Lua loading.

DEPENDENCIES
This remains the same communications system and still requires the dependencies used by the original add-on, including NCS Shared/PIXEL resources where applicable.
