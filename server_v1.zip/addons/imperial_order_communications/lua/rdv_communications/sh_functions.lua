
function NCS_COMMUNICATIONS.GetPassiveChannels(P)
    if IsValid(P) then
        P = P:EntIndex()
    end

    NCS_COMMUNICATIONS.PASSIVE[P] = NCS_COMMUNICATIONS.PASSIVE[P] or {}

    return NCS_COMMUNICATIONS.PASSIVE[P] or {}
end

function NCS_COMMUNICATIONS.GetActiveChannel(P)
    if !NCS_COMMUNICATIONS.Players then
        return false
    end

    if CLIENT then
        if IsValid(P) then
            P = P:EntIndex()
        end
        
        if !NCS_COMMUNICATIONS.Players[P] then
            return false
        else
            return NCS_COMMUNICATIONS.Players[P]
        end
    else
        return NCS_COMMUNICATIONS.ACTIVE[P]
    end
end

function NCS_COMMUNICATIONS.CanAccessChannel(ply, channel)
    local LIST = NCS_COMMUNICATIONS.LIST[channel]

    if !LIST then
        return
    end

    if LIST.CustomCheck then
        local CHECK = LIST.CustomCheck(ply)

        if CHECK ~= nil then
            return CHECK
        end
    end

    if LIST.Factions and !table.IsEmpty(LIST.Factions) then
        if !LIST.Factions[team.GetName(ply:Team())] then
            return false
        end
    end

    local HOOK = hook.Run("RDV_COMMS_CanAccessChannel", ply, channel)

    if ( HOOK == false ) then
        return false
    end

    return true
end

function NCS_COMMUNICATIONS.GetMemberCount(CHANNEL)
    if CLIENT then
        local TAB = NCS_COMMUNICATIONS.OCCUPANTS[CHANNEL]

        if !TAB then
            return 0
        else
            return TAB
        end
    end
end

function NCS_COMMUNICATIONS.GetCommsEnabled(P)
    if !IsValid(P) then return false end

    if CLIENT then 
        if ( NCS_COMMUNICATIONS.RELAY == false ) then 
            return false 
        else
            return true
        end
    else
        local COUNT = 0

        for k, v in pairs(NCS_COMMUNICATIONS.RELAYS) do
            if v.TEAMS and v.TEAMS[team.GetName(P:Team())] then
                COUNT = COUNT + 1

                if ( v.ENABLED == true ) then
                    return true
                end
            end
        end

        if COUNT <= 0 then
            return true
        end

        return false
    end
end

function NCS_COMMUNICATIONS.GetChannelColor(ID)
    if !NCS_COMMUNICATIONS.LIST[ID] then
        return color_white
    end

    return NCS_COMMUNICATIONS.LIST[ID].Color or color_white
end