if NCS_COMMUNICATIONS and NCS_COMMUNICATIONS.LOADED then return end

function NCS_COMMUNICATIONS.AddPassiveChannel(P, channel)
    if IsValid(P) then
        P = P:EntIndex()
    end

    NCS_COMMUNICATIONS.PASSIVE[P] = NCS_COMMUNICATIONS.PASSIVE[P] or {}
    NCS_COMMUNICATIONS.SPASSIVE[P] = NCS_COMMUNICATIONS.SPASSIVE[P] or {}

    if NCS_COMMUNICATIONS.PASSIVE[P][channel] then
        return
    end

    table.insert(NCS_COMMUNICATIONS.SPASSIVE[P], channel)

    NCS_COMMUNICATIONS.PASSIVE[P][channel] = true

    net.Start("RDV_COMMS_SetPassive")
        net.WriteUInt(P, 8)
        net.WriteString(channel)
        net.WriteBool(true)
    net.Broadcast()

    hook.Run("RDV_COMMS_JoinPassiveChannel", P, channel)
end

function NCS_COMMUNICATIONS.RemovePassiveChannel(P, channel)
    if IsValid(P) then
        P = P:EntIndex()
    end

    NCS_COMMUNICATIONS.PASSIVE[P] = NCS_COMMUNICATIONS.PASSIVE[P] or {}
    NCS_COMMUNICATIONS.SPASSIVE[P] = NCS_COMMUNICATIONS.SPASSIVE[P] or {}

    if !NCS_COMMUNICATIONS.PASSIVE[P][channel] then
        return
    end

    for k, v in ipairs(NCS_COMMUNICATIONS.SPASSIVE[P]) do
        if ( v == channel ) then
            table.remove(NCS_COMMUNICATIONS.SPASSIVE[P], k)
        end
    end
    
    NCS_COMMUNICATIONS.PASSIVE[P][channel] = nil

    net.Start("RDV_COMMS_SetPassive")
        net.WriteUInt(P, 8)
        net.WriteString(channel)
        net.WriteBool(false)
    net.Broadcast()

    hook.Run("RDV_COMMS_LeavePassiveChannel", P, channel)
end

--[[---------------------------------]]--
--  Exit Channel
--[[---------------------------------]]--

function NCS_COMMUNICATIONS.ExitCurrentChannel(ply, network)
    if !IsValid(ply) then return end

    local CURRENT = NCS_COMMUNICATIONS.GetActiveChannel(ply)

    if !CURRENT then
        return
    end

    NCS_COMMUNICATIONS.ACTIVE[ply] = false

    --
    --  Remove from Players Table.
    --

    local TAB = NCS_COMMUNICATIONS.Players
    local COUNT = #TAB

    local UID = ply:EntIndex()

    for i = 1, COUNT do
        if !TAB[i] then
            continue
        end

        if ( TAB[i].UID == UID ) then
            table.remove(NCS_COMMUNICATIONS.Players, i)
        end
    end

    --
    --  Network
    --

    if network then
        net.Start("RDV_COMMS_Disconnect")
            net.WriteUInt(ply:EntIndex(), 8)
        net.Broadcast()
    end
end

--[[---------------------------------]]--
--  Change Channel
--[[---------------------------------]]--

function NCS_COMMUNICATIONS.SetChannel(P, CHANNEL)
    if !IsValid(P) or !CHANNEL then return end

    local ACTIVE = NCS_COMMUNICATIONS.GetActiveChannel(P)

    if ( CHANNEL == ACTIVE ) then
        return
    end

    --
    -- Don't allow players to connect to passive channels.
    --

    local PASSIVE = NCS_COMMUNICATIONS.GetPassiveChannels(P)

    if PASSIVE[CHANNEL] then
        return
    end

    --
    -- Remove Active Channel.
    --

    local TAB = NCS_COMMUNICATIONS.Players
    local COUNT = #TAB

    local UID = P:EntIndex()

    for i = 1, COUNT do
        if !TAB[i] or !TAB[i].UID then
            continue
        end
        
        if ( TAB[i].UID == UID ) then
            table.remove(NCS_COMMUNICATIONS.Players, i)
        end
    end

    --
    -- Set the Active Channel.
    --

    hook.Run("RDV_COMMS_PreChannelConnect", P, CHANNEL)

    NCS_COMMUNICATIONS.Players = NCS_COMMUNICATIONS.Players or {}

    local INSERTED = table.insert(NCS_COMMUNICATIONS.Players, {
        Client = P,
        UID = P:EntIndex(),
        Channel = CHANNEL,
    })

    NCS_COMMUNICATIONS.ACTIVE[P] = CHANNEL

    net.Start("RDV_COMMS_Connect")
        net.WriteUInt(P:EntIndex(), 8)
        net.WriteString(CHANNEL)
    net.Broadcast()

    hook.Run("RDV_COMMS_PostChannelConnect", P, CHANNEL)
end