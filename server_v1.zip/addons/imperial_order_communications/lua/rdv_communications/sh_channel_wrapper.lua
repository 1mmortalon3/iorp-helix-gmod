if NCS_COMMUNICATIONS and NCS_COMMUNICATIONS.LOADED then return end

function NCS_COMMUNICATIONS.RegisterChannel(self, CHANNEL, DATA)
    local jobCategories = {}

    if RPExtraTeams then
        for k, v in pairs(RPExtraTeams) do
            jobCategories[v.category] = jobCategories[v.category] or {}
            table.insert(jobCategories[v.category], v.name)
        end
    end

    local NEW = {}

    if DATA.Factions then
        for k, v in ipairs(DATA.Factions) do
            NEW[v] = true
        end
    end

    if RPExtraTeams and DATA.Categories then
        for k, v in ipairs(DATA.Categories) do
            if !jobCategories[v] then continue end
            for a, b in pairs(jobCategories[v]) do
                NEW[b] = true
            end
        end
    end

    MsgC(Color(255, 0, 0), "---------------------------------------------------------------------------\n")
    MsgC(Color(255, 80, 80), "[IMPERIAL_ORDER] Imperial Communications\n\n")
    MsgC(Color(190, 25, 30), "Adding New Channel:\n")
    MsgC(Color(220, 220, 220), CHANNEL.."\n")
    MsgC(Color(190, 25, 30), "Job Count:\n")
    MsgC(Color(220, 220, 220), table.Count(NEW).."\n\n")
    MsgC(Color(255, 0, 0), "---------------------------------------------------------------------------\n")

    DATA.Factions = NEW or {}

    if DATA.Speakers and table.IsEmpty(DATA.Speakers) then
        DATA.Speakers = nil
    end
    
    if !DATA.Color then
        DATA.Color = color_white
    end

    local HOOK = hook.Run("RDV_COMMS_CanRegisterChannel", CHANNEL, DATA)
    if ( HOOK == false ) then
        return
    end

    NCS_COMMUNICATIONS.LIST[CHANNEL] = DATA
end