if NCS_COMMUNICATIONS and NCS_COMMUNICATIONS.LOADED then return end

net.Receive("RDV_COMMS_SetPassive", function()
    local UID = net.ReadUInt(8)
    local CHN = net.ReadString()
    local STA = net.ReadBool()

    local P = Entity(UID)
    
    if !IsValid(P) or !P:IsPlayer() then return end

    NCS_COMMUNICATIONS.PASSIVE[UID] = NCS_COMMUNICATIONS.PASSIVE[UID] or {}
    NCS_COMMUNICATIONS.SPASSIVE[UID] = NCS_COMMUNICATIONS.SPASSIVE[UID] or {}

    NCS_COMMUNICATIONS.OCCUPANTS[CHN] = NCS_COMMUNICATIONS.OCCUPANTS[CHN] or 0

    if STA then
        table.insert(NCS_COMMUNICATIONS.SPASSIVE[UID], CHN)

        NCS_COMMUNICATIONS.PASSIVE[UID][CHN] = true

        NCS_COMMUNICATIONS.OCCUPANTS[CHN] = NCS_COMMUNICATIONS.OCCUPANTS[CHN] + 1
    else
        for k, v in ipairs(NCS_COMMUNICATIONS.SPASSIVE[UID]) do
            if ( CHN == v ) then
                table.remove(NCS_COMMUNICATIONS.SPASSIVE[UID], k)
                break
            end
        end

        NCS_COMMUNICATIONS.PASSIVE[UID][CHN] = nil

        NCS_COMMUNICATIONS.OCCUPANTS[CHN] = NCS_COMMUNICATIONS.OCCUPANTS[CHN] - 1
    end
end )

net.Receive("RDV_COMMS_SendPassive", function()
    local PCOUNT = net.ReadUInt(8)

    for i = 1, PCOUNT do
        local P = net.ReadUInt(8)
        local T = net.ReadTable()

        NCS_COMMUNICATIONS.PASSIVE[P] = NCS_COMMUNICATIONS.PASSIVE[P] or {}
        NCS_COMMUNICATIONS.SPASSIVE[P] = NCS_COMMUNICATIONS.SPASSIVE[P] or {}

        for k, v in ipairs(T) do
            NCS_COMMUNICATIONS.OCCUPANTS[v] = NCS_COMMUNICATIONS.OCCUPANTS[v] or 0

            NCS_COMMUNICATIONS.OCCUPANTS[v] = NCS_COMMUNICATIONS.OCCUPANTS[v] + 1

            NCS_COMMUNICATIONS.PASSIVE[P][v] = true
        end

        NCS_COMMUNICATIONS.SPASSIVE[P] = T
    end
end)

net.Receive("RDV_COMMS_ClearPassive", function()
    local P = net.ReadUInt(8)

    NCS_COMMUNICATIONS.PASSIVE[P] = NCS_COMMUNICATIONS.PASSIVE[P] or {}
    NCS_COMMUNICATIONS.SPASSIVE[P] = NCS_COMMUNICATIONS.SPASSIVE[P] or {}

    for k, v in ipairs(NCS_COMMUNICATIONS.SPASSIVE[P]) do
        NCS_COMMUNICATIONS.OCCUPANTS[v] = NCS_COMMUNICATIONS.OCCUPANTS[v] or 0

        NCS_COMMUNICATIONS.OCCUPANTS[v] = NCS_COMMUNICATIONS.OCCUPANTS[v] - 1
    end

    NCS_COMMUNICATIONS.PASSIVE[P] = nil
    NCS_COMMUNICATIONS.SPASSIVE[P] = nil
end )