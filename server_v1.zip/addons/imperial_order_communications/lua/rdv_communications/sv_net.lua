
util.AddNetworkString("RDV_COMMS_SendPassive")
util.AddNetworkString("RDV_COMMS_Disconnect")
util.AddNetworkString("RDV_COMMS_Connect")
util.AddNetworkString("RDV_COMMS_Sync")
util.AddNetworkString("RDV_COMMS_RemoveChannel")
util.AddNetworkString("RDV_COMMS_SetPassive")
util.AddNetworkString("RDV_COMMS_ClearPassive")
util.AddNetworkString("RDV_COMMS_MUTE")

--
util.AddNetworkString("RDV.COMMUNICATIONS.SendCommsMessage")
util.AddNetworkString("RDV.COMMUNICATIONS.RelayToggled")
util.AddNetworkString("RDV.COMMUNICATIONS.OpenConfig")
util.AddNetworkString("RDV.COMMUNICATIONS.CreateChannel")
util.AddNetworkString("RDV_COMMUNICATIONS_Talking")
--

local function SendNotification(ply, msg)
    local CFG = NCS_COMMUNICATIONS.S_CFG

    local COL = CFG.chatColor
    local PRE = CFG.chatPrefix
	
    NCS_SHARED.AddText(ply, COL, "["..PRE.."] ", color_white, msg)
end

net.Receive("RDV_COMMS_Disconnect", function(len, ply)
    local CHANNEL = NCS_COMMUNICATIONS.GetActiveChannel(ply)

    local CAN = hook.Run("RDV_COMMS_PreChannelDisconnect", ply, CHANNEL)
    if (CAN == false) then return end

    NCS_COMMUNICATIONS.ExitCurrentChannel(ply, true)

    hook.Run("RDV_COMMS_PostChannelDisconnect", ply, CHANNEL)
end)

net.Receive("RDV_COMMS_MUTE", function(len, ply)
    NCS_COMMUNICATIONS.MUTED[ply] = !NCS_COMMUNICATIONS.MUTED[ply]
end)

local DELAY = {}

net.Receive("RDV_COMMS_Connect", function(len, ply)
    if DELAY[ply] and DELAY[ply] > CurTime() then
        return
    end

    local CHANNEL = net.ReadString()

    if !NCS_COMMUNICATIONS.CanAccessChannel(ply, CHANNEL) then
        return
    end

    local CAN = NCS_COMMUNICATIONS.SetChannel(ply, CHANNEL)

    if CAN then
        local LChannel = NCS_SHARED.GetLang(nil, "COMMS_switchedChannel", {
            CHANNEL,
        })

        SendNotification(ply, LChannel)
    end

    DELAY[ply] = CurTime() + 2
end)

net.Receive("RDV_COMMS_SetPassive", function(_, P)
    if DELAY[P] and DELAY[P] > CurTime() then
        return
    end

    local CHANNEL = net.ReadString()

    if !NCS_COMMUNICATIONS.LIST[CHANNEL] then
        return
    end

    if !NCS_COMMUNICATIONS.CanAccessChannel(P, CHANNEL) then
        return
    end

    local STATUS = net.ReadBool()
    local CFG = NCS_COMMUNICATIONS.S_CFG

    if STATUS then
        if ( table.Count(NCS_COMMUNICATIONS.GetPassiveChannels(P)) ) < NCS_COMMUNICATIONS.S_CFG.passiveChannelCount then
            NCS_COMMUNICATIONS.AddPassiveChannel(P, CHANNEL)
        end
    else
        NCS_COMMUNICATIONS.RemovePassiveChannel(P, CHANNEL)
    end

    DELAY[P] = CurTime() + 2
end )
