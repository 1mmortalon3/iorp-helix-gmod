local COMMS = NCS_COMMUNICATIONS

--[[---------------------------------------------
    Command Channel — anyone can join, always on
-----------------------------------------------]]
COMMS:RegisterChannel("Command", {
    Color = Color(225, 225, 230, 220),
    NoRelay = true,
})
--[[---------------------------------------------
    Imperial Comms — all military personnel
-----------------------------------------------]]
COMMS:RegisterChannel("Imperial Comms", {
    Color = Color(190, 25, 30, 230),
    Categories = {
        "Imperial Cadets",    
        "Stormtrooper Corps",
        "Imperial Shock Regiment",
        "Imperial Navy",
        "Inferno Squad",
        "Imperial Commandos",
        "Imperial High Command",
        "Imperial Death Trooper Detachment",
        "Naval Pilot Squadron",
        "Emperors Inner Circle",
        "The Imperial Inquisitorious",
        "Imperial Death Trooper Detachment",
        "Bounty Hunters",
    },
    NoRelay = true,
})
--[[---------------------------------------------
    Battalion / Unit Channels
-----------------------------------------------]]
COMMS:RegisterChannel("Stormtrooper Corps", {
    Color = Color(205, 205, 212, 220),
    Categories = {
        "Stormtrooper Corps",
    },
    NoRelay = true,
})

COMMS:RegisterChannel("Imperial Cadets", {
    Color = Color(165, 165, 175, 220),
    Categories = {
       "Imperial Cadets",
    },
    NoRelay = true,
})

COMMS:RegisterChannel("Imperial Navy", {
    Color = Color(120, 125, 135, 220),
    Categories = {
       "Imperial Navy",
    },
    NoRelay = true,
})

COMMS:RegisterChannel("Imperial Shock Regiment", {
    Color = Color(220, 35, 40, 230),
    Categories = {
         "Imperial Shock Regiment",
    },
    NoRelay = true,
})
COMMS:RegisterChannel("Naval Pilot Squadron", {
    Color = Color(105, 110, 120, 220),
    Categories = {
        "Naval Pilot Squadron",
    },
    NoRelay = true,
})
COMMS:RegisterChannel("Imperial Death Trooper Detachment", {
    Color = Color(105, 110, 120, 220),
    Categories = {
       "Imperial Death Trooper Detachment",
    },
    NoRelay = true,
})
COMMS:RegisterChannel("Imperial Ground Crew", {
    Color = Color(105, 110, 120, 220),
    Categories = {
        "Imperial Ground Crew",
    },
    NoRelay = true,
})
--[[---------------------------------------------
    Special Operations Channels
-----------------------------------------------]]
COMMS:RegisterChannel("Inferno Squad", {
    Color = Color(190, 45, 45, 225),
    Categories = {
       "Inferno Squad",
    },
    NoRelay = true,
})

COMMS:RegisterChannel("Imperial Commandos", {
    Color = Color(175, 175, 185, 220),
    Categories = {
       "Imperial Commandos",
    },
    NoRelay = true,
})

COMMS:RegisterChannel("Imperial Death Trooper Detachment", {
    Color = Color(65, 65, 72, 220),
    Categories = {
         "Imperial Death Trooper Detachment",
    },
    NoRelay = true,
})

--[[---------------------------------------------
    Leadership Channels
-----------------------------------------------]]
COMMS:RegisterChannel("The Imperial Inquisitorious", {
    Color = Color(155, 20, 25, 230),
    Categories = {
         "The Imperial Inquisitorious",
    },
    NoRelay = true,
})

COMMS:RegisterChannel("Imperial High Command", {
    Color = Color(245, 245, 248, 235),
    Categories = {
        "Imperial High Command",
    },
    NoRelay = false,
})

COMMS:RegisterChannel("Emperors Inner Circle", {
    Color = Color(130, 15, 20, 230),
    Categories = {
       "Emperors Inner Circle",
    },
    NoRelay = true,
})
--[[---------------------------------------------
    Bounty Hunters
-----------------------------------------------]]
COMMS:RegisterChannel("Bounty Hunters", {
    Color = Color(150, 140, 125, 220),
    Categories = {
        "Bounty Hunters",
    },
    NoRelay = true,
})
