local PANEL = {}

function PANEL:Init()
    local T = NCS_COMMUNICATIONS.THEME
    self.NormalCol = T.Border
    self.HoverCol = T.AccentBright
    self.HOVERED = false
    self:SetFont("NCS_COMMS_ChannelTitle")
end

function PANEL:Paint(w, h)
    local T = NCS_COMMUNICATIONS.THEME
    local col = self.HOVERED and self.HoverCol or self.NormalCol

    if self.HOVERED then
        surface.SetDrawColor(T.AccentDim)
        surface.DrawRect(0, 0, w, h)
        self:SetTextColor(T.TextBright)
    else
        self:SetTextColor(T.Text)
    end

    surface.SetDrawColor(col)
    NCS_COMMUNICATIONS.DrawOutlinedRectangleFromTwoPoints(0, 0, w, h, PIXEL.Scale(1))
end

function PANEL:OnCursorEntered()
    surface.PlaySound("ncs/ui/slider.mp3")
    self.HOVERED = true
end

function PANEL:OnCursorExited()
    self.HOVERED = false
end

vgui.Register("NCS_COMMS_TextButton", PANEL, "DButton")
