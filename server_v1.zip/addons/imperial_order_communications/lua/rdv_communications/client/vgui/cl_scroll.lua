local PANEL = {}

function PANEL:Init()
    local VBAR = self:GetVBar()

    function VBAR:Paint(w, h)
        local T = NCS_COMMUNICATIONS.THEME
        surface.SetDrawColor(T.PanelAlt)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(T.BorderDim)
        surface.DrawOutlinedRect(0, 0, w, h)
    end

    local W = VBAR:GetWide()
    VBAR:SetWide(math.max(W * 0.5, PIXEL.Scale(4)))
    VBAR:SetHideButtons(true)

    local GRIP = VBAR:GetChildren()[3]
    function GRIP:Paint(w, h)
        local T = NCS_COMMUNICATIONS.THEME
        surface.SetDrawColor(self:IsHovered() and T.AccentBright or T.Accent)
        surface.DrawRect(0, 0, w, h)
    end
end

vgui.Register("NCS_COMMS_SCROLL", PANEL, "DScrollPanel")
