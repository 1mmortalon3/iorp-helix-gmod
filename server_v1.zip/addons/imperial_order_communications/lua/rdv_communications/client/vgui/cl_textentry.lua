surface.CreateFont("NCS_COMMS_textEntry", {
    font = "Montserrat Medium",
    extended = false,
    size = ScreenScale(5),
})

local PANEL = {}

function PANEL:Init()
    self:SetText("")
    self:SetFont("NCS_COMMS_textEntry")
    self:SetDrawLanguageID(false)
    self.placeholder = "ENTER TEXT..."
    self.isFocused = false
end

function PANEL:Paint(w, h)
    local T = NCS_COMMUNICATIONS.THEME
    surface.SetDrawColor(T.PanelAlt)
    surface.DrawRect(0, 0, w, h)
    surface.SetDrawColor(self.isFocused and T.AccentBright or T.Border)
    surface.DrawOutlinedRect(0, 0, w, h, PIXEL.Scale(1))

    if self:GetText() == "" and not self.isFocused then
        draw.SimpleText(self.placeholder, "NCS_COMMS_textEntry", PIXEL.Scale(5), h / 2, T.TextDim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    else
        self:DrawTextEntryText(T.TextBright, T.Accent, T.TextBright)
    end
end

function PANEL:OnFocusChanged(gained)
    self.isFocused = gained
    surface.PlaySound(gained and "buttons/button14.wav" or "buttons/button16.wav")
end

function PANEL:GetContentSize()
    surface.SetFont(self:GetFont())
    return surface.GetTextSize(self:GetText())
end

function PANEL:SetPlaceholderText(text)
    self.placeholder = text or ""
end

vgui.Register("NCS_COMMS_TextEntry", PANEL, "DTextEntry")
