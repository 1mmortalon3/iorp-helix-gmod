local PANEL = {
    Init = function(self)
        self.ACTIVE = false
        self.HOVERED = {}
        self.SELECTED = false

        local parent = self:GetParent()
        local w, h = parent:GetSize()

        self.SCROLL = vgui.Create("DScrollPanel", parent)
        self.SCROLL:Dock(LEFT)
        self.SCROLL:SetSize(w * 0.3, h)
        self.SCROLL:DockMargin(PIXEL.Scale(10), PIXEL.Scale(10), PIXEL.Scale(10), PIXEL.Scale(10))
        self.SCROLL.Paint = function(_, sw, sh)
            local T = NCS_COMMUNICATIONS.THEME
            surface.SetDrawColor(T.Panel)
            surface.DrawRect(0, 0, sw, sh)
            surface.SetDrawColor(T.Border)
            surface.DrawOutlinedRect(0, 0, sw, sh)
        end
    end,

    AddPage = function(self, title, icon, cb)
        self.PAGES = self.PAGES or {}

        local button = self.SCROLL:Add("DButton")
        button:SetText(title)
        button:Dock(TOP)
        button:SetHeight(self.SCROLL:GetTall() * 0.075)
        button:SetFont("NCS_COMMS_BUTTON")
        button:SetTextColor(NCS_COMMUNICATIONS.THEME.Text)

        button.Paint = function(btn, w, h)
            local T = NCS_COMMUNICATIONS.THEME
            local active = self.ACTIVE == title or self.HOVERED[btn]
            surface.SetDrawColor(active and T.AccentDim or T.PanelAlt)
            surface.DrawRect(0, 0, w, h)
            surface.SetDrawColor(active and T.AccentBright or T.BorderDim)
            surface.DrawOutlinedRect(0, 0, w, h)

            local imageSize = w * 0.075 + h * 0.1
            local imageOffset = (h - imageSize) / 2
            if icon then
                NCS_COMMUNICATIONS.DrawImgur(w * 0.05, imageOffset, imageSize, imageSize, icon, active and T.AccentBright or T.TextDim)
            end
        end

        button.DoClick = function(btn)
            if self.SELECTED and self.SELECTED ~= btn then
                self.HOVERED[self.SELECTED] = false
                self.SELECTED:SetTextColor(NCS_COMMUNICATIONS.THEME.Text)
            end

            self.SELECTED = btn
            surface.PlaySound("ncs/ui/activate.mp3")
            self:SelectPage(title)
        end

        button.OnCursorEntered = function(btn)
            surface.PlaySound("ncs/ui/slider.mp3")
            btn:SetTextColor(NCS_COMMUNICATIONS.THEME.TextBright)
            self.HOVERED[btn] = true
        end

        button.OnCursorExited = function(btn)
            if self.SELECTED == btn then return end
            btn:SetTextColor(NCS_COMMUNICATIONS.THEME.Text)
            self.HOVERED[btn] = nil
        end

        self.PAGES[title] = {
            BUTTON = button,
            CALLBACK = cb,
        }
    end,

    GetPage = function(self)
        self.ACTIVE = self.ACTIVE or false
        return self.ACTIVE
    end,

    SelectPage = function(self, title)
        local tab = self.PAGES[title]
        if not tab then return end

        if tab.CALLBACK then
            tab:CALLBACK()
        end

        self.ACTIVE = title
        self.SELECTED = tab.BUTTON
        self.SELECTED:SetTextColor(NCS_COMMUNICATIONS.THEME.AccentBright)
    end,
}

vgui.Register("NCS_COMMS_SIDEBAR", PANEL)
