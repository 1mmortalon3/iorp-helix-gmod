local PANEL = {}

function PANEL:Init()
    local CAT_LABEL = self:GetChildren()[1]
    CAT_LABEL:SetTextColor(NCS_COMMUNICATIONS.THEME.TextBright)
    CAT_LABEL:SetContentAlignment(5)
    CAT_LABEL:SetFont("NCS_COMMS_FRAME_TITLE")
    CAT_LABEL:SetTall(PIXEL.Scale(30))
    CAT_LABEL.Paint = function(label, w, h)
        local T = NCS_COMMUNICATIONS.THEME
        surface.SetDrawColor(label:IsHovered() and T.AccentDim or T.PanelAlt)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(label:IsHovered() and T.AccentBright or T.Border)
        surface.DrawOutlinedRect(0, 0, w, h)
    end
end

function PANEL:OnToggle(open)
    local label = self:GetChildren()[1]
    label:SetTextColor(open and NCS_COMMUNICATIONS.THEME.AccentBright or NCS_COMMUNICATIONS.THEME.Text)
end

function PANEL:Paint(w, h)
    local T = NCS_COMMUNICATIONS.THEME
    surface.SetDrawColor(T.Panel)
    surface.DrawRect(0, 0, w, h)
    surface.SetDrawColor(T.BorderDim)
    surface.DrawOutlinedRect(0, 0, w, h)
end

vgui.Register("NCS_COMMS_CollapsibleCategory", PANEL, "DCollapsibleCategory")
