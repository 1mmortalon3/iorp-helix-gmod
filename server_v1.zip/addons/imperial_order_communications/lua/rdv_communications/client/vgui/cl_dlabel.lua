local PANEL = {}

surface.CreateFont("DEF_labelMainFont", {
    font = "Montserrat Medium",
    size = ScreenScaleH(8),
})

function PANEL:Init()
    self:SetFont("DEF_labelMainFont")
    self:SetContentAlignment(4)
    self:SizeToContentsY(PIXEL.Scale(5))
end

vgui.Register("NCS_COMMS_TextLabel", PANEL, "DLabel")