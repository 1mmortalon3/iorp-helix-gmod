local blur = Material("pp/blurscreen")
local imperialLogo = Material("imperial_order/imperial_comms_logo.png", "smooth mips")

local function CreateFonts()
    surface.CreateFont("NCS_COMMS_FRAME_TITLE", {
        font = "Montserrat Medium",
        extended = false,
        size = ScreenScale(8),
        weight = 2000,
    })

    surface.CreateFont("NCS_COMMS_DESCRIPTION", {
        font = "Montserrat Medium",
        extended = false,
        size = ScreenScale(7),
        weight = 500,
    })

    surface.CreateFont("NCS_COMMS_BUTTON", {
        font = "Montserrat Medium",
        extended = false,
        size = ScreenScale(6),
        weight = 800,
    })

    surface.CreateFont("NCS_COMMS_CLOSE", {
        font = "Montserrat Medium",
        extended = false,
        size = ScreenScale(8),
        weight = 1000,
    })
end
hook.Add("OnScreenSizeChanged", "NCS_COMMS_UpdateFonts", CreateFonts)
CreateFonts()

local PANEL = {}

function PANEL:Init()
    self:SetTitle("")

    self.Header = vgui.Create("Panel", self)
    self.Header:Dock(TOP)
    self.Header:SetTall(PIXEL.Scale(34))
    self.Header.Paint = function(_, w, h)
        local T = NCS_COMMUNICATIONS.THEME
        surface.SetDrawColor(T.PanelAlt)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(T.Accent)
        surface.DrawRect(0, h - PIXEL.Scale(2), w, PIXEL.Scale(2))

        local logoSize = math.min(h - PIXEL.Scale(8), PIXEL.Scale(24))
        surface.SetMaterial(imperialLogo)
        surface.SetDrawColor(T.TextBright)
        surface.DrawTexturedRect(PIXEL.Scale(7), (h - logoSize) * 0.5, logoSize, logoSize)

        draw.SimpleText(self:GetTitle() or "", "NCS_COMMS_FRAME_TITLE", PIXEL.Scale(38), h * 0.5, T.TextBright, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    self.CloseButton = vgui.Create("DButton", self.Header)
    self.CloseButton:Dock(RIGHT)
    self.CloseButton:SetWide(PIXEL.Scale(34))
    self.CloseButton:SetText("X")
    self.CloseButton:SetFont("NCS_COMMS_CLOSE")
    self.CloseButton:SetTextColor(NCS_COMMUNICATIONS.THEME.Text)
    self.CloseButton.Paint = function(btn, w, h)
        local T = NCS_COMMUNICATIONS.THEME
        if btn:IsHovered() then
            surface.SetDrawColor(T.AccentDim)
            surface.DrawRect(0, 0, w, h)
            btn:SetTextColor(T.TextBright)
        else
            btn:SetTextColor(T.Text)
        end
    end
    self.CloseButton.DoClick = function()
        self:Remove()
    end
end

function PANEL:Paint(w, h)
    local T = NCS_COMMUNICATIONS.THEME
    local x, y = self:LocalToScreen(0, 0)
    local scrW, scrH = ScrW(), ScrH()

    surface.SetDrawColor(color_white)
    surface.SetMaterial(blur)
    for i = 1, 3 do
        blur:SetFloat("$blur", (i / 3) * 4)
        blur:Recompute()
        render.UpdateScreenEffectTexture()
        surface.DrawTexturedRect(-x, -y, scrW, scrH)
    end

    surface.SetDrawColor(T.Background)
    surface.DrawRect(0, 0, w, h)
    surface.SetDrawColor(T.Border)
    surface.DrawOutlinedRect(0, 0, w, h, PIXEL.Scale(1))
    surface.SetDrawColor(T.Accent)
    surface.DrawRect(0, 0, PIXEL.Scale(3), h)
end

function PANEL:ShowCloseButton(show)
    if IsValid(self.CloseButton) then
        self.CloseButton:SetVisible(show)
    end
end

AccessorFunc(PANEL, "m_rd_titletext", "Title", FORCE_STRING)
vgui.Register("NCS_COMMS_FRAME", PANEL, "EditablePanel")
