local materials = {}
local grabbingMaterials = {}
local fallbackMaterial = Material("imperial_order/imperial_comms_logo.png", "noclamp smooth mips")

local function UseFallback(id, callback)
    materials[id] = fallbackMaterial

    if callback then
        callback(fallbackMaterial)
    end
end

function NCS_COMMUNICATIONS.GetImgur(id, callback, useproxy, matSettings)
    if not isstring(id) or id == "" then
        return UseFallback(tostring(id or "imperial_order_fallback"), callback)
    end

    if materials[id] then
        return callback(materials[id])
    end

    file.CreateDir("rdv")

    if file.Exists("rdv/" .. id .. ".png", "DATA") then
        local cached = Material("../data/rdv/" .. id .. ".png", matSettings or "noclamp smooth mips")

        if cached and not cached:IsError() then
            materials[id] = cached
            return callback(cached)
        end
    end

    local imageURL = "https://i.imgur.com/" .. id .. ".png"
    local requestURL = useproxy
        and ("https://proxy.duckduckgo.com/iu/?u=" .. imageURL)
        or imageURL

    http.Fetch(requestURL,
        function(body, len, headers, code)
            if code ~= 200 or not body or body == "" or len > 2097152 then
                return UseFallback(id, callback)
            end

            file.Write("rdv/" .. id .. ".png", body)

            local downloaded = Material("../data/rdv/" .. id .. ".png", matSettings or "noclamp smooth mips")
            if not downloaded or downloaded:IsError() then
                return UseFallback(id, callback)
            end

            materials[id] = downloaded
            return callback(downloaded)
        end,
        function()
            if useproxy then
                return UseFallback(id, callback)
            end

            return NCS_COMMUNICATIONS.GetImgur(id, callback, true, matSettings)
        end
    )
end

function NCS_COMMUNICATIONS.DrawImgur(x, y, w, h, imgurId, col)
    col = col or color_white

    if not materials[imgurId] then
        if grabbingMaterials[imgurId] then return end
        grabbingMaterials[imgurId] = true

        NCS_COMMUNICATIONS.GetImgur(imgurId, function(mat)
            materials[imgurId] = mat or fallbackMaterial
            grabbingMaterials[imgurId] = nil
        end)

        return
    end

    local material = materials[imgurId]
    if not material or material:IsError() then
        material = fallbackMaterial
        materials[imgurId] = fallbackMaterial
    end

    surface.SetMaterial(material)
    surface.SetDrawColor(col.r, col.g, col.b, col.a)
    surface.DrawTexturedRect(x, y, w, h)
end
