surface.CreateFont("RD_FONTS_CORE_OVERHEAD", {
    font = "Bebas Neue",
    extended = false,
    size = 40,
    weight = 500,
    blursize = 0,
    scanlines = 0,
    antialias = true
})

surface.CreateFont("RD_FONTS_CORE_OVERHEAD_SMALL", {
    font = "Bebas Neue",
    extended = false,
    size = 20,
    weight = 500,
    blursize = 0,
    scanlines = 0,
    antialias = true
})

surface.CreateFont( "RD_FONTS_CORE_LABEL_LOWER", {
    font = "Bebas Neue",
    size = ScrW() * 0.012,
    weight = 0,
    blursize = 0,
    scanlines = 0,
    antialias = true,
    extended = true,
} )

surface.CreateFont("RD_FONTS_CORE_PROPERTY_TABS", {
    font = "Bebas Neue",
    size = ScrW() * 0.01,
    weight = 0,
    blursize = 0,
    scanlines = 0,
    antialias = true,
    extended = true,
})

surface.CreateFont( "RDV_LIB_FRAME_TITLE", {
	font = "Bebas Neue", --  Use the font-name which is shown to you by your operating system Font Viewer, not the file name
	extended = false,
	size = ScrW() * 0.0135,
} )




surface.CreateFont( "NCS_COMMS_ChannelTitle", {
	font = "Bebas Neue", --  Use the font-name which is shown to you by your operating system Font Viewer, not the file name
	extended = false,
	size = ScrW() * 0.012,
} )

surface.CreateFont( "NCS_COMMS_SubChannelTitle", {
	font = "Bebas Neue", --  Use the font-name which is shown to you by your operating system Font Viewer, not the file name
	extended = false,
	size = ScrW() * 0.010,
} )