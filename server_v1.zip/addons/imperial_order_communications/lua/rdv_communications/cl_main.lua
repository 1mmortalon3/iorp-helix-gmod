surface.CreateFont( "RDV_COMMUNICATIONS_FontSmall", {
	font = "Montserrat",
    size = ScrW() * 0.009,
    antialias = true,
    extended = true,
} )

surface.CreateFont("RDV_COMMUNICATIONS_LABEL", {
	font = "Bebas Neue",
	extended = false,
	size = ScrW() * 0.0135,
})

--[[
--  Local Vars
--]]

local MUTED = false
local COMPLETE = false
local WAITING = false

local THEME = NCS_COMMUNICATIONS.THEME
local COL_1 = THEME.Background
local COL_3 = THEME.AccentBright
local COL_RED = THEME.Bad
local COL_OUTLINE = THEME.Border

--[[
--  Local Materials
--]]

-- Imperial fallback icons. The original RDV archive did not include these three
-- materials, which caused purple/black missing-texture squares. All icon slots
-- deliberately use the supplied Imperial crest. The legacy files are also
-- included at their original paths for compatibility with cached/older code.
local IMPERIAL_ICON = Material("imperial_order/imperial_comms_logo.png", "smooth mips")
local MIC_ICON = IMPERIAL_ICON
local SPEAKER_ICON = IMPERIAL_ICON
local ICON = IMPERIAL_ICON

--[[
--  Local Functions
--]]


local function SendNotification(ply, msg)
    local CFG = NCS_COMMUNICATIONS.S_CFG
    local COL = Color(CFG.chatColor.r, CFG.chatColor.g, CFG.chatColor.b)

    NCS_SHARED.AddText(ply, COL, "["..CFG.chatPrefix.."] ", color_white, msg)
end

local blur = Material("pp/blurscreen")

function DrawBlur(panel, amount)
    local x, y = panel:LocalToScreen(0, 0)
    local scrW, scrH = ScrW(), ScrH()

    surface.SetDrawColor(255, 255, 255)

    surface.SetMaterial(blur)

    for i = 1, 3 do -- More passes = smoother blur
        blur:SetFloat("$blur", (i / 3) * (amount or 6))
        blur:Recompute()

        render.UpdateScreenEffectTexture()

        surface.DrawTexturedRect(-x, -y, scrW, scrH)
    end
end

function NCS_COMMUNICATIONS.DrawOutlinedRectangleFromTwoPoints(x1, y1, x2, y2, thickness)
    local startX = math.min(x1, x2)
    local startY = math.min(y1, y2)
    local rectWidth = math.abs(x2 - x1)
    local rectHeight = math.abs(y2 - y1)

    surface.DrawOutlinedRect(startX, startY, rectWidth, rectHeight, thickness)
end

function NCS_COMMUNICATIONS.Open(context)
    NCS_COMMUNICATIONS.OCCUPANTS = NCS_COMMUNICATIONS.OCCUPANTS or {}

    if IsValid(NCS_COMMUNICATIONS.PANEL) then
        NCS_COMMUNICATIONS.PANEL:Remove()
    end
    
    if context then
        if IsValid(NCS_COMMUNICATIONS.IDENT) then
            NCS_COMMUNICATIONS.IDENT:SetVisible(false)
        end
    end

    local w, h = ScrW(), ScrH()

    local COUNT = 0

    local commsLabel = NCS_SHARED.GetLang(nil, "COMMS_communicationsLabel")

    local PANEL = vgui.Create("NCS_COMMS_FRAME")
    if context then
        PANEL:SetParent(g_ContextMenu)
    end
    PANEL:SetSize(w * 0.175, h * 0.4)
    PANEL:SetTitle(string.upper(commsLabel))
    PANEL:SetPos(w * 0.82, h * 0.04)
    PANEL:SetMouseInputEnabled(true)

    NCS_COMMUNICATIONS.PANEL = PANEL

    local w, h = PANEL:GetSize()

    local noChannels = NCS_SHARED.GetLang(nil, "COMMS_noChannels")
    local arrayOffline = NCS_SHARED.GetLang(nil, "COMMS_arrayOffline")

    local SCROLL = vgui.Create("NCS_COMMS_SCROLL", PANEL)
    SCROLL:DockMargin(w * 0.02, h * 0.0125, w * 0.0225, h * 0.025)
    SCROLL:Dock(FILL)
    SCROLL.Paint = function(self, w, h)
        surface.SetDrawColor( COL_OUTLINE )
        surface.DrawOutlinedRect( 0, 0, w, h )
        
        if COUNT <= 0 and !NCS_COMMUNICATIONS.GetCommsEnabled(LocalPlayer()) then
            draw.SimpleText(arrayOffline, "RDV_LIB_FRAME_TITLE", w * 0.5, h * 0.4, COL_RED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        elseif COUNT <= 0 then
            draw.SimpleText(noChannels, "RDV_LIB_FRAME_TITLE", w * 0.5, h * 0.4, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end

    local MUTE = vgui.Create("NCS_COMMS_TextButton", PANEL)
    MUTE:Dock(BOTTOM)

    local TEXT = MUTED and NCS_SHARED.GetLang(nil, "COMMS_unmuteLabel") or NCS_SHARED.GetLang(nil, "COMMS_muteLabel")

    MUTE:SetText(TEXT)

    MUTE:DockMargin(0, 0, 0, h * 0.025)
    MUTE:SetFont("RDV_LIB_FRAME_TITLE")
    MUTE:SetTextColor(color_white)
    MUTE:SizeToContentsY()
    MUTE.DoClick = function()
        net.Start("RDV_COMMS_MUTE")
        net.SendToServer()

        MUTED = !MUTED

        local MUTED = MUTED
        local TEXT = MUTED and NCS_SHARED.GetLang(nil, "COMMS_unmuteLabel") or NCS_SHARED.GetLang(nil, "COMMS_muteLabel")

        MUTE:SetText(TEXT)

        if MUTED then
            SendNotification(LocalPlayer(), NCS_SHARED.GetLang(nil, "COMMS_mutedText"))
        else
            SendNotification(LocalPlayer(), NCS_SHARED.GetLang(nil, "COMMS_unmutedText"))
        end

        surface.PlaySound("reality_development/ui/ui_accept.ogg")
    end
    MUTE.Paint = function() end
    MUTE.OnCursorEntered = function(self)
        surface.PlaySound("reality_development/ui/ui_hover.ogg")

        self:SetTextColor(COL_3)
    end
    MUTE.OnCursorExited = function(self)
        self:SetTextColor(color_white)
    end

    local ROTATE = {
        [1] = THEME.Panel,
        [2] = THEME.PanelAlt,
    }

    local CURRENT = 1

    if !NCS_COMMUNICATIONS.LIST then
        return PANEL
    end

    local LActive = "("..NCS_SHARED.GetLang(nil, "COMMS_activeLabel")..")"
    local L_PASSIVE = "("..NCS_SHARED.GetLang(nil, "COMMS_passiveLabel")..")"

    for k, v in SortedPairs(NCS_COMMUNICATIONS.LIST) do
        local NAME = k
        
        if !NCS_COMMUNICATIONS.CanAccessChannel(LocalPlayer(), NAME) then
            continue
        end

        if ( !NCS_COMMUNICATIONS.GetCommsEnabled(LocalPlayer()) and !v.NoRelay ) then
            continue
        end

        local PASSIVE = NCS_COMMUNICATIONS.GetPassiveChannels(LocalPlayer()) or {}

        COUNT = COUNT + 1
                 
        local LabelColor = ROTATE[CURRENT]

        if CURRENT == 1 then
            CURRENT = 2
        else
            CURRENT = 1
        end

        local LColor = v.Color
        local labelMarginScale = PIXEL.Scale(5)

        local label = SCROLL:Add("DLabel")
        label:SetHeight(h * 0.1)
        label:Dock(TOP)
        label:DockMargin(labelMarginScale, labelMarginScale, labelMarginScale, 0)
        label:SetMouseInputEnabled(true)
        label:SetFont("RDV_LIB_FRAME_TITLE")
        label:SetText("")

        local scale = PIXEL.Scale(5)

        label.Paint = function(self, w, h)
            local OCCUPANTS = NCS_COMMUNICATIONS.GetMemberCount(NAME)

            draw.RoundedBox(0, 0, 0, w, h, LabelColor)
            PIXEL.DrawOutlinedBox(0, 0, w, h, PIXEL.Scale(1), THEME.BorderDim)

            if PASSIVE[NAME] then
                draw.SimpleText(NAME.." "..L_PASSIVE, "NCS_COMMS_ChannelTitle", w * 0.025, h * 0.04, LColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            elseif NCS_COMMUNICATIONS.GetActiveChannel(LocalPlayer()) == NAME then
                draw.SimpleText(NAME.." "..LActive, "NCS_COMMS_ChannelTitle", w * 0.025, h * 0.04, LColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            else
                draw.SimpleText(NAME, "NCS_COMMS_ChannelTitle", w * 0.025, h * 0.04, LColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            end

            PIXEL.DrawRoundedBox(PIXEL.Scale(5), w * 0.027, h * 0.52, w * 0.2, h * 0.4, THEME.PanelSoft)
            PIXEL.DrawOutlinedRoundedBox(PIXEL.Scale(5), w * 0.027, h * 0.52, w * 0.2, h * 0.4, THEME.BorderDim, PIXEL.Scale(1))

            surface.SetDrawColor(THEME.TextDim)
                surface.SetMaterial(ICON)
            surface.DrawTexturedRect(w * 0.035, h * 0.52, w * 0.0625, h * 0.4296875)

            draw.SimpleText(OCCUPANTS, "NCS_COMMS_SubChannelTitle", ((w * 0.135)), h * 0.52, THEME.TextBright, TEXT_ALIGN_CENTER)
        end

        local connectButton = vgui.Create("NCS_COMMS_TextButton", label)
        connectButton:Dock(RIGHT)
        connectButton:SetText(NCS_SHARED.GetLang(nil, "COMMS_viewLabel"))
        connectButton:SetMouseInputEnabled(true)
        connectButton:DockMargin(scale, scale, scale, scale)
        connectButton:SizeToContentsX(scale * 2)

        connectButton.DoClick = function(self)
            local MenuButtonOptions = DermaMenu() -- Creates the menu

            local ACTIVE = NCS_COMMUNICATIONS.GetActiveChannel(LocalPlayer())
            local PASSIVE = NCS_COMMUNICATIONS.GetPassiveChannels(LocalPlayer()) or {}
            
            if !PASSIVE[NAME] and ( ACTIVE ~= NAME ) then
                local CFG = NCS_COMMUNICATIONS.S_CFG

                if ( table.Count(PASSIVE) ) < CFG.passiveChannelCount then
                    MenuButtonOptions:AddOption(NCS_SHARED.GetLang(nil, "COMMS_setPassive"), function()
                        surface.PlaySound("buttons/blip1.wav")

                        net.Start("RDV_COMMS_SetPassive")
                            net.WriteString(k)
                            net.WriteBool(true)
                        net.SendToServer()
                    end)
                end
            elseif PASSIVE[NAME] and ( ACTIVE ~= NAME ) then 
                MenuButtonOptions:AddOption(NCS_SHARED.GetLang(nil, "COMMS_disconnectPassive"), function()
                    surface.PlaySound("buttons/blip1.wav")

                    net.Start("RDV_COMMS_SetPassive")
                        net.WriteString(k)
                        net.WriteBool(false)
                    net.SendToServer()
                end)
            end

            if !PASSIVE[NAME] then
                if ( ACTIVE ~= NAME ) then
                    MenuButtonOptions:AddOption(NCS_SHARED.GetLang(nil, "COMMS_connectLabel"), function()
                        surface.PlaySound("buttons/blip1.wav")

                        net.Start("RDV_COMMS_Connect")
                            net.WriteString(k)
                        net.SendToServer()
                    end)
                else
                    MenuButtonOptions:AddOption(NCS_SHARED.GetLang(nil, "COMMS_disconnectLabel"), function()
                        net.Start("RDV_COMMS_Disconnect")
                        net.SendToServer()

                        surface.PlaySound("reality_development/ui/ui_denied.ogg")
                    end)
                end
            end

            if NCS_COMMUNICATIONS.GetMemberCount(NAME) > 0 then
                MenuButtonOptions:AddOption(NCS_SHARED.GetLang(nil, "COMMS_viewOccupants"), function()
                    if NCS_COMMUNICATIONS.GetMemberCount(NAME) <= 0 then
                        return
                    end

                    local MLIST = {}
                    local LIST = {}

                    local LOccupants = NCS_SHARED.GetLang(nil, "COMMS_channelOccupantsTitle", {
                        NAME,
                    })

                    local FRAME = vgui.Create("NCS_COMMS_FRAME")
                    FRAME:SetSize(ScrW() * 0.3, ScrH() * 0.4)
                    FRAME:Center()
                    FRAME:SetTitle(LOccupants)
                    FRAME:MakePopup(true)

                    local DermaListView = vgui.Create("DListView", FRAME)
                    DermaListView:Dock(FILL)
                    DermaListView:SetMultiSelect(false)
                    DermaListView:AddColumn(NCS_SHARED.GetLang(nil, "COMMS_nameLabel"))
                    DermaListView:AddColumn(NCS_SHARED.GetLang(nil, "COMMS_factionLabel"))
                    DermaListView:AddColumn(NCS_SHARED.GetLang(nil, "COMMS_typeLabel"))

                    DermaListView.OnRowSelected = function(self, rowind, row)
                        table.insert(MLIST, LIST[rowind])
                    end

                    for k, v in pairs(NCS_COMMUNICATIONS.Players) do
                        local P = Entity(k)

                        if !IsValid(P) or (v ~= NAME) then
                            continue
                        end

                        DermaListView:AddLine(P:Name(), team.GetName(P:Team()), NCS_SHARED.GetLang(nil, "COMMS_activeLabel")) -- Add lines
                    end 

                    for k, v in pairs(NCS_COMMUNICATIONS.PASSIVE) do
                        if v[NAME] then
                            local P = Entity(k)

                            if !IsValid(P) then continue end

                            local LINE = DermaListView:AddLine(P:Name(), team.GetName(P:Team()), NCS_SHARED.GetLang(nil, "COMMS_passiveLabel")) -- Add lines
                        end
                    end
                end)
            end

            MenuButtonOptions:Open() -- Open the menu AFTER adding your options
        end
    end

    return PANEL
end

hook.Add("RDV_COMMS_PostChannelConnect", "RDV.StartMuted.Implement", function(ply)
    if !IsValid(ply) then return end
    
    local CFG = NCS_COMMUNICATIONS.S_CFG

    if CFG.startMuted and ( ply == LocalPlayer() ) then
        MUTED = true
    end
end )

net.Receive("RDV.COMMUNICATIONS.SendCommsMessage", function()
    local CLI = net.ReadUInt(8)

    CLI = Entity(CLI)

    if !IsValid(CLI) then
        return
    end

    local CHANNEL = NCS_COMMUNICATIONS.GetActiveChannel(CLI)

    if !CHANNEL then
        return
    end

    local MSG = net.ReadString()
    
    local COL = NCS_COMMUNICATIONS.LIST[CHANNEL].Color

    NCS_SHARED.AddText(LocalPlayer(), COL, "["..CHANNEL.."] ", team.GetColor(CLI:Team()), CLI:Name(), color_white, ": "..MSG)
end)

hook.Add("OnContextMenuClose", "RDV.COMMUNICATIONS.ContextMenuClose", function()
    if IsValid(NCS_COMMUNICATIONS.IDENT) then
        NCS_COMMUNICATIONS.IDENT:SetVisible(true)
    end
end)

hook.Add("OnContextMenuOpen", "RDV.COMMUNICATIONS.ContextMenuOpen", function(panel)
    local PANEL = NCS_COMMUNICATIONS.Open(true)

    if !IsValid(PANEL) then
        return
    end

    PANEL:ShowCloseButton(false)
end)

net.Receive("RDV_COMMS_Sync", function()
    local COUNT = net.ReadUInt(8)
    
    for i = 1, COUNT do
        local PLAYER = net.ReadUInt(8)
        
        if !IsValid(Entity(PLAYER)) then continue end

        local CHANNEL = net.ReadString()

        NCS_COMMUNICATIONS.Players[PLAYER] = CHANNEL

        NCS_COMMUNICATIONS.OCCUPANTS[CHANNEL] = NCS_COMMUNICATIONS.OCCUPANTS[CHANNEL] or 0
        NCS_COMMUNICATIONS.OCCUPANTS[CHANNEL] = NCS_COMMUNICATIONS.OCCUPANTS[CHANNEL] + 1

        hook.Run("RDV_COMMS_NetworkingComplete", Entity(PLAYER)) 
    end
end )

local function Disconnect(UID)
    local OLD = NCS_COMMUNICATIONS.Players[UID]

    if OLD then
        hook.Run("RDV_COMMS_PreChannelDisconnect", Entity(UID), OLD)


        NCS_COMMUNICATIONS.Players[UID] = false

        NCS_COMMUNICATIONS.OCCUPANTS[OLD] = NCS_COMMUNICATIONS.OCCUPANTS[OLD] or 1
        NCS_COMMUNICATIONS.OCCUPANTS[OLD] = NCS_COMMUNICATIONS.OCCUPANTS[OLD] - 1

        hook.Run("RDV_COMMS_PostChannelDisconnect", Entity(UID), OLD)
    end
end

net.Receive("RDV_COMMS_Disconnect", function()
    local PLAYER = net.ReadUInt(8)

    Disconnect(PLAYER)
end )

net.Receive("RDV_COMMS_Connect", function()
    local PLAYER = net.ReadUInt(8)

    Disconnect(PLAYER)

    local CHANNEL = net.ReadString()

    hook.Run("RDV_COMMS_PreChannelConnect", Entity(PLAYER), CHANNEL)

    NCS_COMMUNICATIONS.OCCUPANTS[CHANNEL] = NCS_COMMUNICATIONS.OCCUPANTS[CHANNEL] or 0
    NCS_COMMUNICATIONS.OCCUPANTS[CHANNEL] = NCS_COMMUNICATIONS.OCCUPANTS[CHANNEL] + 1

    NCS_COMMUNICATIONS.Players[PLAYER] = CHANNEL

    hook.Run("RDV_COMMS_PostChannelConnect", Entity(PLAYER), CHANNEL)
end )

NCS_COMMUNICATIONS.TemporaryChannels = {}

net.Receive("RDV.COMMUNICATIONS.CreateChannel", function()
    local TCOUNT = net.ReadUInt(8)
    local PCOUNT = net.ReadUInt(8)
    local NAME = net.ReadString()

    local TEAMS = {}
    local TEAMS_INT = {}

    local PLAYS = {}

    for i = 1, TCOUNT do
        local TEAM = net.ReadUInt(16)
        local TNAME = team.GetName(TEAM)

        table.insert(TEAMS, TNAME)
        table.insert(TEAMS_INT, TEAM)
    end

    for i = 1, PCOUNT do
        local PLAYER = net.ReadUInt(31)

        PLAYS[PLAYER] = true
    end
    
    local COMMS = NCS_COMMUNICATIONS

    COMMS:RegisterChannel(NAME, {
        Factions = TEAMS,
        Color = color_white,
        CustomCheck = function(ply)
            if !table.IsEmpty(PLAYS) and !PLAYS[ply:AccountID()] then
                return false
            end
        end,
    })

    local KEY = table.insert(NCS_COMMUNICATIONS.TemporaryChannels, {
        Name = NAME,
    })

    hook.Run("RDV_COMMS_ChannelCreated", KEY)
end)

net.Receive("RDV_COMMS_RemoveChannel", function()
    local CID = net.ReadUInt(8)

    local TEMP = NCS_COMMUNICATIONS.TemporaryChannels

    if TEMP and TEMP[CID] then
        local NAME = TEMP[CID].Name

        NCS_COMMUNICATIONS.TemporaryChannels[CID] = nil

        NCS_COMMUNICATIONS.LIST[NAME] = nil
    end
end)

hook.Add("RDV_COMMS_PostChannelDisconnect", "RDV.COMMUNICATIONS.ChannelLabel", function(ply, ACTIVE)
    if ply ~= LocalPlayer() then
        return
    end

    if IsValid(NCS_COMMUNICATIONS.VPANEL) then NCS_COMMUNICATIONS.VPANEL:Remove() end

    if IsValid(NCS_COMMUNICATIONS.IDENT) then
        NCS_COMMUNICATIONS.IDENT:Remove()
    end
end)

hook.Add("RDV_COMMS_PostChannelConnect", "RDV.COMMUNICATIONS.ChannelLabel", function(P, CHANNEL)
    if P ~= LocalPlayer() then
        return
    end

    local function Create()
        if !CHANNEL then
            return
        end

        local w, h = ScrW(), ScrH()
        local NAME = CHANNEL

        if !NCS_COMMUNICATIONS.LIST or !NCS_COMMUNICATIONS.LIST[NAME] then
            return
        end

        local VCOLOR = NCS_COMMUNICATIONS.GetChannelColor(NAME)
        
        local LDisconnected = NCS_SHARED.GetLang(nil, "COMMS_disconnectedLabel")

        local PANEL = vgui.Create("DPanel")
        PANEL:SetSize(w * 0.175, h * 0.05)

        local CFG = NCS_COMMUNICATIONS.S_CFG

        local LOCATION = CFG.HUDLocation

        if LOCATION then
            PANEL:SetPos(w * 0.82, h * 0.01)
        else
            PANEL:SetPos(w * 0.005, h * 0.01)
        end

        PANEL:SetMouseInputEnabled(true)
        PANEL.Paint = function(s, w, h)
            if !NAME then return end

            local COUNT = NCS_COMMUNICATIONS.GetMemberCount(NAME)
            local ENABLED = NCS_COMMUNICATIONS.GetCommsEnabled(LocalPlayer())

            DrawBlur( s, 4 )

            surface.SetDrawColor(THEME.PanelAlt)
            surface.DrawRect(0, 0, w, h)

            PIXEL.DrawOutlinedBox(0, 0, w, h, PIXEL.Scale(1), THEME.Border)

            surface.SetDrawColor(color_white)
                if NCS_COMMUNICATIONS.LIST[NAME].Speakers then
                    local SPEAKERS = NCS_COMMUNICATIONS.LIST[NAME].Speakers

                    if !SPEAKERS[tostring(LocalPlayer():SteamID64())] and !SPEAKERS[team.GetName(LocalPlayer():Team())] then
                        surface.SetDrawColor(Color(255,0,0))
                    end
                end
                surface.SetMaterial(MIC_ICON)
            surface.DrawTexturedRect(w * 0.025, h * 0.175, w * 0.13, h * 0.675)
            
            local LOccupants

            if ENABLED or NCS_COMMUNICATIONS.LIST[NAME].NoRelay then
                LOccupants = NCS_SHARED.GetLang(nil, "COMMS_occupantsLabel", {
                    COUNT,
                })

                local LMuted = NCS_SHARED.GetLang(nil, "COMMS_mutedLabel")

                if MUTED then
                    draw.SimpleText(NAME.." "..LMuted, "NCS_COMMS_ChannelTitle", w * 0.18, h * 0.35, VCOLOR, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                else
                    draw.SimpleText(NAME, "NCS_COMMS_ChannelTitle", w * 0.18, h * 0.35, VCOLOR, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                end
                    draw.SimpleText(LOccupants, "NCS_COMMS_SubChannelTitle", w * 0.18, h * 0.65, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                else

                LOccupants = NCS_SHARED.GetLang(nil, "COMMS_occupantsLabel", {
                    "(N/A)",
                })

                draw.SimpleText(LDisconnected, "RDV_LIB_FRAME_TITLE", w * 0.18, h * 0.35, COL_RED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                draw.SimpleText(LOccupants, "NCS_COMMS_SubChannelTitle", w * 0.18, h * 0.65, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            end
        end

        NCS_COMMUNICATIONS.IDENT = PANEL
    end

    Create() 
end)

local lastShuffle
local SHUFFLE

hook.Add("PlayerStartVoice", "RDV_COMMUNICATIONS_VoiceIndicator2", function(ply)
    if ply == LocalPlayer() and MUTED then return end

    local CFG = NCS_COMMUNICATIONS.S_CFG

    if CFG.speakBindEnabled and !input.IsKeyDown(CFG.speakBindValue) then return end

    local PACTIVE = NCS_COMMUNICATIONS.GetActiveChannel(ply)
    local LACTIVE = NCS_COMMUNICATIONS.GetActiveChannel(LocalPlayer())

    if LACTIVE and PACTIVE and ( PACTIVE == LACTIVE ) then
        local VCOLOR = NCS_COMMUNICATIONS.LIST[PACTIVE].Color

        local w, h = ScrW(), ScrH()

        if IsValid(g_VoicePanelList) then
            g_VoicePanelList:SetVisible(false)   
        end   

        -- DEVELOPMENT ONLY (REMOVE)
        --if IsValid(NCS_COMMUNICATIONS.VPANEL) then NCS_COMMUNICATIONS.VPANEL:Remove() end
        --

        if !IsValid(NCS_COMMUNICATIONS.VPANEL) then
            local PANEL = vgui.Create("DPanel")
            PANEL:SetSize(w * 0.16, h * 0.5)

            local CFG = NCS_COMMUNICATIONS.S_CFG

            local LOCATION = CFG.HUDLocation

            if LOCATION then
                PANEL:SetPos(w * 0.835, h * 0.065)
            else
                PANEL:SetPos(w * 0.005, h * 0.065)
            end

            
            PANEL.Paint = function(self, w, h)
            end
        
            local w, h = PANEL:GetSize()
    
            NCS_COMMUNICATIONS.VPANEL = PANEL
        end

        local LText = NCS_SHARED.GetLang(nil, "COMMS_connectionLost")
        local TEXT = LText

        local LAST = CurTime()
        local TCOLOR = team.GetColor(ply:Team())

        local SCROLL = NCS_COMMUNICATIONS.VPANEL

        if NCS_COMMUNICATIONS.LIST[PACTIVE].Speakers then
            local SPEAKERS = NCS_COMMUNICATIONS.LIST[PACTIVE].Speakers

            if !SPEAKERS[tostring(ply:SteamID64())] and !SPEAKERS[team.GetName(ply:Team())] then
                return
            end
        end

        local label = vgui.Create("DLabel", SCROLL)
        label:SetHeight(h * 0.045)
        label:SetFont("RDV_LIB_FRAME_TITLE")
        label:SetText("")
        label:Dock(TOP)

        label.Paint = function(self, w, h)
            if !IsValid(ply) then
                self:Remove()
                return
            end

            local ENABLED = NCS_COMMUNICATIONS.GetCommsEnabled(LocalPlayer())

            if ENABLED or ( !ENABLED and NCS_COMMUNICATIONS.LIST[PACTIVE].NoRelay ) then
                DrawBlur( self, 4 )
                
                surface.SetDrawColor(THEME.PanelAlt)
                surface.DrawRect(0, 0, w, h)

                PIXEL.DrawOutlinedBox(0, 0, w, h, PIXEL.Scale(1), THEME.Border)
                
                draw.SimpleText(ply:Name(), "NCS_COMMS_ChannelTitle", w * 0.2, h * 0.325, TCOLOR, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                draw.SimpleText(PACTIVE, "NCS_COMMS_SubChannelTitle", w * 0.2, h * 0.675, VCOLOR, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                surface.SetDrawColor(color_white)
                    surface.SetMaterial(SPEAKER_ICON)
                surface.DrawTexturedRect(w * 0.05, h * 0.253125, w * 0.0975, h * 0.50625)
            else
                self:Remove()
                return
            end
        end

        NCS_COMMUNICATIONS.VSCROLL_LABELS = NCS_COMMUNICATIONS.VSCROLL_LABELS or {}

        NCS_COMMUNICATIONS.VSCROLL_LABELS[ply] = label
    end
end)

hook.Add("PlayerEndVoice", "RDV.COMMUNICATIONS.VoiceIndicator", function(ply)
    NCS_COMMUNICATIONS.VSCROLL_LABELS = NCS_COMMUNICATIONS.VSCROLL_LABELS or {}

    local LABEL = NCS_COMMUNICATIONS.VSCROLL_LABELS[ply]

    if IsValid(LABEL) then
        LABEL:Remove()

        if !IsValid(g_VoicePanelList) then
            return
        end

        g_VoicePanelList:SetVisible(true)
    end
end)

local talking = false
net.Receive("RDV_COMMUNICATIONS_Talking", function(len, ply)
    if permissions.EnableVoiceChat and !permissions.IsGranted("voicerecord") then
        permissions.EnableVoiceChat(true)

        return
    end

    if !talking then
        talking = true

        if permissions.EnableVoiceChat then
            permissions.EnableVoiceChat(true)
        else
            RunConsoleCommand("+voicerecord")
        end
    else
        talking = false

        if permissions.EnableVoiceChat then
            permissions.EnableVoiceChat(false)
        else
            RunConsoleCommand("-voicerecord")
        end
    end
end)

--[[---------------------------------]]--
--  Halo Implementation
--[[---------------------------------]]--

hook.Add( "PreDrawHalos", "RDV.HALOS", function()
    local CFG = NCS_COMMUNICATIONS.S_CFG

    if !CFG.haloEnabled then return end

    local ID = NCS_COMMUNICATIONS.GetActiveChannel(LocalPlayer())

    if !ID then return end

    local TAB = {}

    for k, v in ipairs(player.GetAll()) do
        local C = NCS_COMMUNICATIONS.GetActiveChannel(v)

        if ( ID == C ) then
            table.insert(TAB, v)
        end
    end

    local COL = NCS_COMMUNICATIONS.GetChannelColor(ID)

    halo.Add( TAB, COL, 2, 2, 1, true, true )
end )