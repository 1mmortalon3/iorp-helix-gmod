ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Imperial Communications Relay"
ENT.Category = "[IMPERIAL_ORDER] Imperial Systems"
ENT.AuthorName = "Imperial Order"
ENT.Spawnable = false
ENT.RenderGroup = RENDERGROUP_BOTH

function ENT:SetupDataTables()
    self:NetworkVar("String", 0, "RelayName")
    self:NetworkVar("Bool", 0, "RelayEnabled")
    self:SetRelayEnabled(true)
end
