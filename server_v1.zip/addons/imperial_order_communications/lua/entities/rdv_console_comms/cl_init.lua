include("shared.lua")
AddCSLuaFile()

local COL_GREEN = Color(120, 205, 145)
local COL_RED = Color(230, 45, 45)
local COL_OVERHEAD = Color(190, 25, 30)
local COL_BG = Color(4, 4, 6, 225)
local COL_BORDER = Color(225, 225, 232, 90)

local w, h = 0, 0
local W2, H2 = 0, 0

function ENT:Draw()
    self:DrawModel()

    if self:GetPos():DistToSqr(LocalPlayer():GetPos()) > 200000 then
        return
    end

    local enabled = self:GetRelayEnabled()
    local col = enabled and COL_GREEN or COL_RED
    local CFG = NCS_COMMUNICATIONS.S_CFG

    local ang = self:LocalToWorldAngles(Angle(0, 90, 90))
    local center = self:OBBCenter()

    cam.Start3D2D(self:LocalToWorld(Vector(0, center.y, self:OBBMaxs().z)) + Vector(0, 0, 10), ang, 0.1)
        draw.RoundedBox(0, -(w / 2), 0, w, h, COL_BG)
        surface.SetDrawColor(COL_BORDER)
        surface.DrawOutlinedRect(-(w / 2), 0, w, h)
        draw.RoundedBox(0, -(w / 2), h - (h / 12), w, (h / 12), COL_OVERHEAD)

        w, h = draw.SimpleText(NCS_SHARED.GetLang(nil, "COMMS_overheadName"), "RD_FONTS_CORE_OVERHEAD", 0, 0, color_white, TEXT_ALIGN_CENTER)

        if CFG.consoleHealthEnabled and self:Health() <= 0 then
            W2, H2 = draw.SimpleText("(" .. NCS_SHARED.GetLang(nil, "COMMS_damagedLabel") .. ")", "RD_FONTS_CORE_OVERHEAD", 0, 30, COL_RED, TEXT_ALIGN_CENTER)
        else
            local txt = enabled and NCS_SHARED.GetLang(nil, "COMMS_enabledLabel") or NCS_SHARED.GetLang(nil, "COMMS_disabledLabel")
            W2, H2 = draw.SimpleText("(" .. txt .. ")", "RD_FONTS_CORE_OVERHEAD", 0, 30, col, TEXT_ALIGN_CENTER)
        end
    cam.End3D2D()

    w = w + W2 + 10
    h = h + H2 + 10
end
