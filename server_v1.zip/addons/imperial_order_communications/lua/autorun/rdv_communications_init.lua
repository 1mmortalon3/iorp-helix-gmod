-- Microphone: https://www.flaticon.com/free-icon/microphone_709682
-- Person: https://icon-icons.com/icon/person/110935

if SERVER then
    -- Ship the crest plus compatibility copies for every material path used by
    -- the communications UI. This prevents purple/black missing textures on
    -- clients that do not have the original RDV asset pack.
    resource.AddFile("materials/imperial_order/imperial_comms_logo.png")
    resource.AddFile("materials/rdv/communications/rdv_microphone.png")
    resource.AddFile("materials/rdv/communications/speaker.png")
    resource.AddFile("materials/rdv/communications/rdv_person.png")
end

timer.Simple(0, function()    
    NCS_COMMUNICATIONS = NCS_COMMUNICATIONS or {
        RelayEnabled = true,
        LIST = {},
        OCCUPANTS = {},
        Players = {},
        TemporaryChannels = {},
        PASSIVE = {},
        SPASSIVE = {},
        MUTED = {},
        ACTIVE = {},
        RELAYS = {},
        RelayChannels = {},
        CFG = {},
    }

    -- Shared Imperial Order palette. Keeping this centralized makes
    -- every menu, relay label and button follow the same red/black/steel theme.
    NCS_COMMUNICATIONS.THEME = NCS_COMMUNICATIONS.THEME or {
        Background = Color(4, 4, 6, 248),
        Panel = Color(13, 13, 17, 242),
        PanelAlt = Color(22, 22, 27, 236),
        PanelSoft = Color(30, 30, 36, 220),
        Accent = Color(190, 25, 30, 255),
        AccentBright = Color(235, 45, 50, 255),
        AccentDim = Color(105, 15, 20, 170),
        Border = Color(92, 94, 104, 185),
        BorderDim = Color(65, 67, 75, 145),
        Text = Color(225, 225, 232, 255),
        TextBright = Color(248, 248, 250, 255),
        TextDim = Color(145, 148, 158, 230),
        Good = Color(120, 205, 145, 255),
        Warning = Color(215, 115, 45, 255),
        Bad = Color(230, 45, 45, 255),
        Black = Color(0, 0, 0, 235),
    }

    local rootDir = "rdv_communications"

    local function AddFile(File, dir)
        local fileSide = string.lower(string.Left(File , 3))

        if SERVER and fileSide == "sv_" then
            include(dir..File)
        elseif fileSide == "sh_" then
            if SERVER then 
                AddCSLuaFile(dir..File)
            end
            include(dir..File)
        elseif fileSide == "cl_" then
            if SERVER then 
                AddCSLuaFile(dir..File)
            elseif CLIENT then
                include(dir..File)
            end
        end
    end

    local function IncludeDir(dir)
        dir = dir .. "/"
        local File, Directory = file.Find(dir.."*", "LUA")

        for k, v in ipairs(File) do
            if string.EndsWith(v, ".lua") then
                AddFile(v, dir)
            end
        end
        
        for k, v in ipairs(Directory) do
            IncludeDir(dir..v)
        end
    end
    IncludeDir(rootDir)

    
    NCS_COMMUNICATIONS.LOADED = true
    
    hook.Run("RDV_COMMS_Loaded")
end)