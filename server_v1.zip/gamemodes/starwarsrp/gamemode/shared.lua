-- Compatibility metadata file. Helix is derived in init.lua and cl_init.lua.
GM.Name = "Imperial Order"
GM.Author = "1mmortalon3"
GM.Email = ""
GM.Website = ""

function GM:GetGameDescription()
    return "Imperial Order"
end
