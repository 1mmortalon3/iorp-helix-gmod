-- Imperial Order early client compatibility bootstrap.
-- This file intentionally has no Helix dependencies. It is included before
-- DeriveGamemode("helix") so Sandbox captures a complete gamemode_base table.

IMPERIAL_ORDER = IMPERIAL_ORDER or {}

local function neutralCalcView(_, client, origin, angles, fov, znear, zfar)
    return {
        origin = origin,
        angles = angles,
        fov = fov,
        znear = znear,
        zfar = zfar,
        drawviewer = false
    }
end

local function noPostRenderVGUI()
end

local function ensureMethod(target, name, fallback)
    if not istable(target) then return false end

    if not isfunction(target[name]) then
        target[name] = fallback
    end

    return isfunction(target[name])
end

local function getBase(name)
    if not baseclass or not isfunction(baseclass.Get) then return nil end
    return baseclass.Get(name)
end

function IMPERIAL_ORDER.RepairGamemodeInheritance(stage)
    local base = getBase("gamemode_base") or getBase("base")

    -- Sandbox stores a local reference to gamemode_base when its cl_init.lua is
    -- executed. These methods therefore must exist before Helix derives it.
    if istable(base) then
        ensureMethod(base, "CalcView", neutralCalcView)
        ensureMethod(base, "PostRenderVGUI", noPostRenderVGUI)
    end

    local sandbox = getBase("sandbox")
    if istable(sandbox) then
        if not istable(sandbox.BaseClass) and istable(base) then
            sandbox.BaseClass = base
        end

        -- Assign direct fallbacks as well. This avoids relying on a damaged or
        -- incomplete metatable chain when Helix calls its Sandbox base.
        ensureMethod(sandbox, "CalcView", (istable(base) and base.CalcView) or neutralCalcView)
        ensureMethod(sandbox, "PostRenderVGUI", (istable(base) and base.PostRenderVGUI) or noPostRenderVGUI)
    end

    local helix = getBase("helix")
    if istable(helix) then
        if not istable(helix.BaseClass) and istable(sandbox) then
            helix.BaseClass = sandbox
        end

        -- Helix's GM:CalcView calls self.BaseClass:CalcView. Guarantee that the
        -- table immediately below Helix has a callable method.
        local helixBase = helix.BaseClass
        if istable(helixBase) then
            ensureMethod(helixBase, "CalcView", (istable(sandbox) and sandbox.CalcView) or neutralCalcView)
            ensureMethod(helixBase, "PostRenderVGUI", (istable(sandbox) and sandbox.PostRenderVGUI) or noPostRenderVGUI)
        end
    end

    local active = GM or GAMEMODE
    if istable(active) then
        local activeBase = active.BaseClass

        if not istable(activeBase) and istable(helix) then
            active.BaseClass = helix
            activeBase = helix
        end

        if istable(activeBase) then
            ensureMethod(activeBase, "CalcView", (istable(helix) and helix.CalcView) or neutralCalcView)
            ensureMethod(activeBase, "PostRenderVGUI", (istable(helix) and helix.PostRenderVGUI) or noPostRenderVGUI)
        end
    end

    IMPERIAL_ORDER.LastInheritanceRepairStage = tostring(stage or "unknown")
    return true
end

local function installPlayerTraceFallback()
    local playerMeta = FindMetaTable and FindMetaTable("Player") or nil
    if not istable(playerMeta) then return false end

    if not isfunction(playerMeta.GetEyeTrace) then
        function playerMeta:GetEyeTrace()
            local startPosition = self:EyePos()

            return util.TraceLine({
                start = startPosition,
                endpos = startPosition + self:GetAimVector() * 32768,
                filter = self,
                mask = MASK_SHOT
            })
        end
    end

    if not isfunction(playerMeta.GetEyeTraceNoCursor) then
        playerMeta.GetEyeTraceNoCursor = playerMeta.GetEyeTrace
    end

    return true
end

IMPERIAL_ORDER.InstallPlayerTraceFallback = installPlayerTraceFallback

-- First pass: base gamemode has loaded, but Sandbox/Helix have not yet been
-- derived for this schema.
IMPERIAL_ORDER.RepairGamemodeInheritance("pre-helix")
installPlayerTraceFallback()

concommand.Add("imperial_order_debug_inheritance", function()
    local function report(name, target)
        print(string.format(
            "[IMPERIAL_ORDER] %-14s table=%s CalcView=%s PostRenderVGUI=%s BaseClass=%s",
            name,
            tostring(istable(target)),
            tostring(istable(target) and isfunction(target.CalcView) or false),
            tostring(istable(target) and isfunction(target.PostRenderVGUI) or false),
            tostring(istable(target) and istable(target.BaseClass) or false)
        ))
    end

    report("gamemode_base", getBase("gamemode_base") or getBase("base"))
    report("sandbox", getBase("sandbox"))
    report("helix", getBase("helix"))
    report("active", GM or GAMEMODE)

    local playerMeta = FindMetaTable and FindMetaTable("Player") or nil
    print("[IMPERIAL_ORDER] Player.GetEyeTrace=" .. tostring(istable(playerMeta) and isfunction(playerMeta.GetEyeTrace) or false))
    print("[IMPERIAL_ORDER] Last repair stage=" .. tostring(IMPERIAL_ORDER.LastInheritanceRepairStage))
end)

-- V242: Helix UI boot guards.
-- The character menu can begin painting while its Init function is still
-- constructing child controls. If a child throws (for example because a Derma
-- skin font is nil), Helix never reaches the later currentAlpha assignment.
-- Install the font and panel safeguards before any character menu is created.

local function installFontArgumentFallbacks()
    if draw and isfunction(draw.GetFontHeight) and not IMPERIAL_ORDER.__originalGetFontHeight then
        IMPERIAL_ORDER.__originalGetFontHeight = draw.GetFontHeight

        draw.GetFontHeight = function(fontName)
            if not isstring(fontName) or fontName == "" then
                fontName = "DermaDefault"
            end

            return IMPERIAL_ORDER.__originalGetFontHeight(fontName)
        end
    end

    if surface and isfunction(surface.SetFont) and not IMPERIAL_ORDER.__originalSurfaceSetFont then
        IMPERIAL_ORDER.__originalSurfaceSetFont = surface.SetFont

        surface.SetFont = function(fontName)
            if not isstring(fontName) or fontName == "" then
                fontName = "DermaDefault"
            end

            return IMPERIAL_ORDER.__originalSurfaceSetFont(fontName)
        end
    end

    return true
end

local function ensureSkinFontFields()
    if not derma or not istable(derma.SkinList) then return false end

    local fallbacks = {
        fontCategory = "ixMediumLightFont",
        fontCategoryBlur = "ixMediumLightBlurFont",
        fontSegmentedProgress = "ixMediumLightFont"
    }

    for _, skin in pairs(derma.SkinList) do
        if istable(skin) then
            for key, value in pairs(fallbacks) do
                if not isstring(skin[key]) or skin[key] == "" then
                    skin[key] = value
                end
            end
        end
    end

    return true
end

local function initializeCharacterAnimationState(panel)
    if not IsValid(panel) then return false end

    panel.currentAlpha = tonumber(panel.currentAlpha) or tonumber(panel.GetAlpha and panel:GetAlpha()) or 255
    panel.currentDimAmount = tonumber(panel.currentDimAmount) or 0
    panel.currentY = tonumber(panel.currentY) or 0
    panel.currentScale = tonumber(panel.currentScale) or 1
    panel.targetDimAmount = tonumber(panel.targetDimAmount) or 255
    panel.targetScale = tonumber(panel.targetScale) or 0.9
    panel.volume = tonumber(panel.volume) or 0

    return true
end

local function installSegmentedProgressGuard()
    if not vgui or not isfunction(vgui.GetControlTable) then return false end

    local control = vgui.GetControlTable("ixSegmentedProgress")
    if not istable(control) then return false end
    if control.__imperial_orderV242FontGuard then return true end

    local originalSizeToContents = control.SizeToContents
    if not isfunction(originalSizeToContents) then return false end

    control.SizeToContents = function(panel, ...)
        if not isstring(panel.font) or panel.font == "" then
            panel.font = "ixMediumLightFont"
        end

        local skin = panel.GetSkin and panel:GetSkin() or nil
        if istable(skin) and (not isstring(skin.fontSegmentedProgress) or skin.fontSegmentedProgress == "") then
            skin.fontSegmentedProgress = "ixMediumLightFont"
        end

        return originalSizeToContents(panel, ...)
    end

    control.__imperial_orderV242FontGuard = true
    return true
end

local function installCharacterMenuGuard()
    if not vgui or not isfunction(vgui.GetControlTable) then return false end

    local control = vgui.GetControlTable("ixCharMenu")
    if not istable(control) then return false end
    if control.__imperial_orderV242CharacterGuard then return true end

    local originalInit = control.Init
    if isfunction(originalInit) then
        control.Init = function(panel, ...)
            initializeCharacterAnimationState(panel)
            return originalInit(panel, ...)
        end
    end

    local originalPaint = control.Paint
    if isfunction(originalPaint) then
        control.Paint = function(panel, width, height)
            initializeCharacterAnimationState(panel)
            return originalPaint(panel, width, height)
        end
    end

    control.__imperial_orderV242CharacterGuard = true
    return true
end

function IMPERIAL_ORDER.InstallHelixUIBootstrap(stage)
    installFontArgumentFallbacks()
    ensureSkinFontFields()

    local active = GM or GAMEMODE
    if istable(active) then
        -- The schema does not define a separate Derma skin. Force Helix's skin
        -- directly so controls never fall back to a skin without Helix fields.
        active.ForceDermaSkin = function()
            return "helix"
        end
    end

    local progressReady = installSegmentedProgressGuard()
    local characterReady = installCharacterMenuGuard()

    IMPERIAL_ORDER.LastUIBootstrapStage = tostring(stage or "unknown")
    IMPERIAL_ORDER.UIBootstrapProgressReady = progressReady
    IMPERIAL_ORDER.UIBootstrapCharacterReady = characterReady

    return progressReady and characterReady
end

IMPERIAL_ORDER.InitializeCharacterAnimationState = initializeCharacterAnimationState

-- These two do not require Helix and should exist before DeriveGamemode.
installFontArgumentFallbacks()
ensureSkinFontFields()

hook.Add("OnCharacterMenuCreated", "IMPERIAL_ORDER.V242.CharacterAnimationState", function(panel)
    initializeCharacterAnimationState(panel)
end)

hook.Add("OnReloaded", "IMPERIAL_ORDER.V242.ReinstallHelixUIGuards", function()
    timer.Simple(0, function()
        if IMPERIAL_ORDER and isfunction(IMPERIAL_ORDER.InstallHelixUIBootstrap) then
            IMPERIAL_ORDER.InstallHelixUIBootstrap("lua-reload")
        end
    end)
end)

concommand.Add("imperial_order_debug_ui_bootstrap", function()
    local defaultSkin = derma and derma.SkinList and derma.SkinList.Default or nil
    local helixSkin = derma and derma.SkinList and derma.SkinList.helix or nil
    local progress = vgui and vgui.GetControlTable and vgui.GetControlTable("ixSegmentedProgress") or nil
    local charMenu = vgui and vgui.GetControlTable and vgui.GetControlTable("ixCharMenu") or nil

    print("[IMPERIAL_ORDER] UI bootstrap stage=" .. tostring(IMPERIAL_ORDER.LastUIBootstrapStage))
    print("[IMPERIAL_ORDER] Default segmented font=" .. tostring(istable(defaultSkin) and defaultSkin.fontSegmentedProgress or nil))
    print("[IMPERIAL_ORDER] Helix segmented font=" .. tostring(istable(helixSkin) and helixSkin.fontSegmentedProgress or nil))
    print("[IMPERIAL_ORDER] Progress guard=" .. tostring(istable(progress) and progress.__imperial_orderV242FontGuard == true))
    print("[IMPERIAL_ORDER] Character guard=" .. tostring(istable(charMenu) and charMenu.__imperial_orderV242CharacterGuard == true))
end)
