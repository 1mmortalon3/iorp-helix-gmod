-- Client entry point for the Imperial Order Helix schema.
-- The bootstrap must run before Helix is derived because Sandbox captures a
-- local reference to gamemode_base during its own cl_init.lua.
include("cl_bootstrap.lua")

DeriveGamemode("helix")

-- V242: Helix controls and skins are registered after DeriveGamemode returns.
-- Patch them immediately, before GM:Initialize loads plugins or a character
-- synchronization packet can create ixCharMenu.
if IMPERIAL_ORDER and isfunction(IMPERIAL_ORDER.InstallHelixUIBootstrap) then
    IMPERIAL_ORDER.InstallHelixUIBootstrap("post-helix-immediate")
end

-- Complete the Sandbox -> Helix -> schema chain now that all three tables exist.
if IMPERIAL_ORDER and isfunction(IMPERIAL_ORDER.RepairGamemodeInheritance) then
    IMPERIAL_ORDER.RepairGamemodeInheritance("post-helix")

    timer.Simple(0, function()
        if IMPERIAL_ORDER and isfunction(IMPERIAL_ORDER.RepairGamemodeInheritance) then
            IMPERIAL_ORDER.RepairGamemodeInheritance("post-gamemode-load")
        end

        if IMPERIAL_ORDER and isfunction(IMPERIAL_ORDER.InstallPlayerTraceFallback) then
            IMPERIAL_ORDER.InstallPlayerTraceFallback()
        end

        if IMPERIAL_ORDER and isfunction(IMPERIAL_ORDER.InstallHelixUIBootstrap) then
            IMPERIAL_ORDER.InstallHelixUIBootstrap("post-gamemode-load")
        end
    end)
end
