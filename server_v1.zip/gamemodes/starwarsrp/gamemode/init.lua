-- Server entry point for the Imperial Order Helix schema.
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("cl_bootstrap.lua")
DeriveGamemode("helix")
