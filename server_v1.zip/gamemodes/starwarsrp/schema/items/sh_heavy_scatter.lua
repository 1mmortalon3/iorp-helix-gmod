ITEM.name        = "Imperial Breacher Shotgun"
ITEM.description = "Close-range breaching weapon issued to Imperial assault teams."
ITEM.model       = "models/weapons/w_shotgun.mdl"
ITEM.weaponClass = "weapon_shotgun"
ITEM.category    = "Weapons"
ITEM.price       = 280
ITEM.width       = 2
ITEM.height      = 1

ITEM.functions = ITEM.functions or {}

ITEM.functions.Equip = {
    name = "Equip",
    OnRun = function(item)
        local client = item.player

        if item.weaponClass then
            client:Give(item.weaponClass)
            client:SelectWeapon(item.weaponClass)
        end

        return false
    end
}

ITEM.functions.Unequip = {
    name = "Unequip",
    OnRun = function(item)
        local client = item.player

        if item.weaponClass then
            client:StripWeapon(item.weaponClass)
        end

        return false
    end
}
