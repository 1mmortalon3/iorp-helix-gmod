ITEM.name        = "E-11 Training Rifle"
ITEM.description = "Standard Imperial training rifle slot using the configured weapon class."
ITEM.model       = "models/weapons/w_smg1.mdl"
ITEM.weaponClass = "weapon_smg1"
ITEM.category    = "Weapons"
ITEM.price       = 350
ITEM.width       = 2
ITEM.height      = 1

ITEM.functions = ITEM.functions or {}

ITEM.functions.Equip = {
    name = "Equip",
    OnRun = function(item)
        local client = item.player

        if item.weaponClass then
            client:Give(item.weaponClass)
            client:SelectWeapon(item.weaponClass)
        end

        return false
    end
}

ITEM.functions.Unequip = {
    name = "Unequip",
    OnRun = function(item)
        local client = item.player

        if item.weaponClass then
            client:StripWeapon(item.weaponClass)
        end

        return false
    end
}
