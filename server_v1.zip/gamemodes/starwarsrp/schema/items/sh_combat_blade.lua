ITEM.name        = "Combat Blade"
ITEM.description = "Reliable close-quarters blade issued for Imperial field operations."
ITEM.model       = "models/weapons/w_crowbar.mdl"
ITEM.weaponClass = "weapon_crowbar"
ITEM.category    = "Weapons"
ITEM.price       = 80
ITEM.width       = 1
ITEM.height      = 1

ITEM.functions = ITEM.functions or {}

ITEM.functions.Equip = {
    name = "Equip",
    OnRun = function(item)
        local client = item.player

        if item.weaponClass then
            client:Give(item.weaponClass)
            client:SelectWeapon(item.weaponClass)
        end

        return false
    end
}

ITEM.functions.Unequip = {
    name = "Unequip",
    OnRun = function(item)
        local client = item.player

        if item.weaponClass then
            client:StripWeapon(item.weaponClass)
        end

        return false
    end
}
