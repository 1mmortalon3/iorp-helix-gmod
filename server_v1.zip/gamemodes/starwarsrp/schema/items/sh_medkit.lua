ITEM.name        = "Imperial Medkit"
ITEM.description = "Restores 50 HP when used."
ITEM.model       = "models/props_lab/jar01.mdl"
ITEM.category    = "Consumables"
ITEM.price       = 60
ITEM.width       = 1
ITEM.height      = 1

ITEM.functions = ITEM.functions or {}

ITEM.functions.Use = {
    name = "Use",
    OnRun = function(item)
        local client = item.player
        local hp = client:Health()
        local max = client:GetMaxHealth()

        if hp >= max then
            client:Notify("Already at full health.")
            return false
        end

        client:SetHealth(math.min(hp + 50, max))
        client:Notify("Imperial Medkit applied. +" .. math.min(50, max - hp) .. " HP")
    end
}
