ITEM.name        = "ISB Compliance Sidearm"
ITEM.description = "Non-lethal compliance sidearm used by security personnel."
ITEM.model       = "models/weapons/w_pistol.mdl"
ITEM.weaponClass = "weapon_pistol"
ITEM.category    = "Weapons"
ITEM.price       = 200
ITEM.width       = 1
ITEM.height      = 1

ITEM.functions = ITEM.functions or {}

ITEM.functions.Equip = {
    name = "Equip",
    OnRun = function(item)
        local client = item.player

        if item.weaponClass then
            client:Give(item.weaponClass)
            client:SelectWeapon(item.weaponClass)
        end

        return false
    end
}

ITEM.functions.Unequip = {
    name = "Unequip",
    OnRun = function(item)
        local client = item.player

        if item.weaponClass then
            client:StripWeapon(item.weaponClass)
        end

        return false
    end
}
