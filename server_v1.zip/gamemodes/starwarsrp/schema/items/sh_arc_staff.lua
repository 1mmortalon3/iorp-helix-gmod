ITEM.name        = "Inquisitor Training Staff"
ITEM.description = "Training staff used by the Inquisitorius."
ITEM.model       = "models/weapons/w_crowbar.mdl"
ITEM.weaponClass = "weapon_crowbar"
ITEM.category    = "Weapons"
ITEM.price       = 500
ITEM.width       = 1
ITEM.height      = 2

ITEM.functions = ITEM.functions or {}

ITEM.functions.Equip = {
    name = "Equip",
    OnRun = function(item)
        local client = item.player

        if item.weaponClass then
            client:Give(item.weaponClass)
            client:SelectWeapon(item.weaponClass)
        end

        return false
    end
}

ITEM.functions.Unequip = {
    name = "Unequip",
    OnRun = function(item)
        local client = item.player

        if item.weaponClass then
            client:StripWeapon(item.weaponClass)
        end

        return false
    end
}
