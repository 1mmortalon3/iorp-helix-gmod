ITEM.name        = "Combat Stimulant"
ITEM.description = "Temporarily reinforces armour by 25 points."
ITEM.model       = "models/props_lab/jar01.mdl"
ITEM.category    = "Consumables"
ITEM.price       = 120
ITEM.width       = 1
ITEM.height      = 1

ITEM.functions = ITEM.functions or {}

ITEM.functions.Use = {
    name = "Use",
    OnRun = function(item)
        local client = item.player
        local armour = client:Armor()

        if armour >= 100 then
            client:Notify("Armour is already full.")
            return false
        end

        client:SetArmor(math.min(armour + 25, 100))
        client:Notify("Stimulant applied. Armour increased.")
    end
}
