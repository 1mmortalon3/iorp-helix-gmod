ITEM.name        = "Command Sidearm"
ITEM.description = "Officer-grade sidearm. Precise and reliable."
ITEM.model       = "models/weapons/w_pistol.mdl"
ITEM.weaponClass = "weapon_pistol"
ITEM.category    = "Weapons"
ITEM.price       = 150
ITEM.width       = 1
ITEM.height      = 1

ITEM.functions = ITEM.functions or {}

ITEM.functions.Equip = {
    name = "Equip",
    OnRun = function(item)
        local client = item.player

        if item.weaponClass then
            client:Give(item.weaponClass)
            client:SelectWeapon(item.weaponClass)
        end

        return false
    end
}

ITEM.functions.Unequip = {
    name = "Unequip",
    OnRun = function(item)
        local client = item.player

        if item.weaponClass then
            client:StripWeapon(item.weaponClass)
        end

        return false
    end
}
