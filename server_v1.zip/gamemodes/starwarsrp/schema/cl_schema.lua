IMPERIAL_ORDER_UI_LOADED = IMPERIAL_ORDER_UI_LOADED or {}
concommand.Add("imperial_order_v235_status", function()
    print("[IMPERIAL_ORDER] Release: " .. tostring(IMPERIAL_ORDER_RELEASE or "unknown"))
    print("[IMPERIAL_ORDER] Imperial UI loaded: " .. tostring(ImperialUI ~= nil))
    print("[IMPERIAL_ORDER] Character sync loaded: " .. tostring(IMPERIAL_ORDER_UI_LOADED.character_sync_v235 == true))
    print("[IMPERIAL_ORDER] Whitelist core loaded: " .. tostring(IMPERIAL_ORDER_UI_LOADED.whitelist_core_v235 == true))
end)
