FACTION.name      = "Imperial Death Trooper Detachment"
FACTION.desc      = "Elite black-armor security and special operations detachment."
FACTION.color     = Color(200, 200, 200)
FACTION.isDefault = false
FACTION.pay       = 480
FACTION.models    = { "models/nada/ghosttrooper.mdl", "models/nada/deathtrooper.mdl", "models/nada/orsonkrennic.mdl" }
FACTION.departmentCode = "DTH"

FACTION_IMPERIAL_DEATH_TROOPER_DETACHMENT = FACTION.index

FACTION.noCreationSelect = true
