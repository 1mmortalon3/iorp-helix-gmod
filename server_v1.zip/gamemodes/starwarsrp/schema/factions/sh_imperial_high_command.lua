FACTION.name      = "Imperial High Command"
FACTION.desc      = "Senior command officials and directors with sector-wide authority."
FACTION.color     = Color(200, 200, 200)
FACTION.isDefault = false
FACTION.pay       = 400
FACTION.models    = { "models/nada/maximilianveers.mdl", "models/nada/alexsandrkallus.mdl", "models/nada/wullfyularen.mdl" }
FACTION.departmentCode = "HICOM"

FACTION_IMPERIAL_HIGH_COMMAND = FACTION.index

FACTION.noCreationSelect = true
