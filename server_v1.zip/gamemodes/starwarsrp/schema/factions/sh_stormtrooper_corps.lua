FACTION.name      = "Stormtrooper Corps"
FACTION.desc      = "Line infantry and command staff responsible for Imperial ground security."
FACTION.color     = Color(200, 200, 200)
FACTION.isDefault = false
FACTION.pay       = 181
FACTION.models    = { "models/nada/rogueonetk.mdl", "models/nada/pms/male/trooper.mdl", "models/nada/pms/male/army.mdl" }
FACTION.departmentCode = "STC"

FACTION_STORMTROOPER_CORPS = FACTION.index

FACTION.noCreationSelect = true
