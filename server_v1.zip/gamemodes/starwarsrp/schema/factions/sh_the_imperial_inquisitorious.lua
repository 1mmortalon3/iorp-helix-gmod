FACTION.name      = "The Imperial Inquisitorious"
FACTION.desc      = "Force-sensitive hunters and dark-side agents serving the Inquisitorius."
FACTION.color     = Color(200, 200, 200)
FACTION.isDefault = false
FACTION.pay       = 500
FACTION.models    = { "models/ethli/characters/inquisitorrebel/inquisitorrebel.mdl", "models/egbanks/characters/eginquisitor/eighth_brother.mdl", "models/player/sample/sister/test/sister.mdl", "models/egbanks/characters/eginquisitor/inquisitor_seventhsister.mdl", "models/ninth_sister1.mdl", "models/egbanks/characters/eginquisitor/inquis_fifthbrother.mdl" }
FACTION.departmentCode = "INQ"

FACTION_THE_IMPERIAL_INQUISITORIOUS = FACTION.index

FACTION.noCreationSelect = true
