FACTION.name      = "Emperors Inner Circle"
FACTION.desc      = "The highest-ranking Imperial leadership and personal advisors to the Emperor."
FACTION.color     = Color(200, 200, 200)
FACTION.isDefault = false
FACTION.pay       = 500
FACTION.models    = { "models/player/emperor_palpatine.mdl", "models/nanb_darth_vader.mdl", "models/nada/wilhufftarkin.mdl", "models/nada/thrawn.mdl" }
FACTION.departmentCode = "CIR"

FACTION_EMPERORS_INNER_CIRCLE = FACTION.index

FACTION.noCreationSelect = true
