FACTION.name      = "Imperial Shock Regiment"
FACTION.desc      = "Security, detainment, and enforcement troops assigned to Imperial command operations."
FACTION.color     = Color(200, 200, 200)
FACTION.isDefault = false
FACTION.pay       = 275
FACTION.models    = { "models/nada/rogueoneshock.mdl", "models/nada/pms/male/trooper.mdl", "models/nada/pms/male/army.mdl" }
FACTION.departmentCode = "SHK"

FACTION_IMPERIAL_SHOCK_REGIMENT = FACTION.index

FACTION.noCreationSelect = true
