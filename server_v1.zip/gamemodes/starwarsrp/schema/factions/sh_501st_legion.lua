FACTION.name      = "501st Legion"
FACTION.desc      = "Vader's Fist, an elite Imperial stormtrooper formation used for high-priority combat operations."
FACTION.color     = Color(60, 95, 160)
FACTION.isDefault = false
FACTION.pay       = 200
FACTION.models    = {
    "models/nada/rogueonetk.mdl",
    "models/nada/pms/male/trooper.mdl",
    "models/nada/pms/male/army.mdl"
}
FACTION.departmentCode = "501"

FACTION_501ST_LEGION = FACTION.index

FACTION.noCreationSelect = true
