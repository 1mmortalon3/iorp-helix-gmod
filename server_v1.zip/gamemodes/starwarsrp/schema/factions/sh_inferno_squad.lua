FACTION.name      = "Inferno Squad"
FACTION.desc      = "Special forces operatives assigned to classified Imperial operations."
FACTION.color     = Color(200, 200, 200)
FACTION.isDefault = false
FACTION.pay       = 181
FACTION.models    = { "models/nada/delmeeko.mdl", "models/nada/gideonhask.mdl", "models/nada/seynmarana.mdl", "models/nada/idenversio.mdl" }
FACTION.departmentCode = "INF"

FACTION_INFERNO_SQUAD = FACTION.index

FACTION.noCreationSelect = true
