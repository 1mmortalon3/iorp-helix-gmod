FACTION.name      = "Imperial Cadets"
FACTION.desc      = "New Imperial personnel awaiting assignment, evaluation, and basic training."
FACTION.color     = Color(200, 200, 200)
FACTION.isDefault = true
FACTION.pay       = 100
FACTION.models    = { "models/nada/imperialcadet_male.mdl", "models/nada/imperialcadet_female.mdl" }
FACTION.departmentCode = "CAD"

FACTION_IMPERIAL_CADETS = FACTION.index

FACTION.noCreationSelect = false
