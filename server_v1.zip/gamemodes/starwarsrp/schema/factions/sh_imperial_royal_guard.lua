IMPERIAL_ORDER_ROYAL_GUARD_MODELS = IMPERIAL_ORDER_ROYAL_GUARD_MODELS or {
    "models/nada/royalguard.mdl",
    "models/nada/pms/male/royalguard.mdl",
    "models/player/royal_guard.mdl",
    "models/player/royalguard.mdl",
    "models/nada/rogueoneshock.mdl"
}

IMPERIAL_ORDER_SHADOW_GUARD_MODELS = IMPERIAL_ORDER_SHADOW_GUARD_MODELS or {
    "models/nada/shadowguard.mdl",
    "models/nada/pms/male/shadowguard.mdl",
    "models/player/shadow_guard.mdl",
    "models/player/shadowguard.mdl",
    "models/nada/rogueoneshock.mdl"
}

local models = {}
local seen = {}
for _, list in ipairs({IMPERIAL_ORDER_ROYAL_GUARD_MODELS, IMPERIAL_ORDER_SHADOW_GUARD_MODELS}) do
    for _, model in ipairs(list) do
        if isstring(model) and model ~= "" and not seen[model] then
            seen[model] = true
            models[#models + 1] = model
        end
    end
end

FACTION.name      = "Imperial Royal Guard"
FACTION.desc      = "The Emperor's crimson protectors, sovereign defenders, and Force-sensitive Shadow Guard operatives."
FACTION.color     = Color(165, 18, 26)
FACTION.isDefault = false
FACTION.pay       = 400
FACTION.models    = models
FACTION.departmentCode = "IRG"
FACTION.noCreationSelect = true

FACTION_IMPERIAL_ROYAL_GUARD = FACTION.index
