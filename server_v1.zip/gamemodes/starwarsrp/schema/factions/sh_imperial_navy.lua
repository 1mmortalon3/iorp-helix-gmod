FACTION.name      = "Imperial Navy"
FACTION.desc      = "Naval crew, pilots, engineers, medics, and intelligence personnel."
FACTION.color     = Color(200, 200, 200)
FACTION.isDefault = false
FACTION.pay       = 209
FACTION.models    = { "models/nada/pms/male/navy_trooper.mdl", "models/nada/pms/male/scanner.mdl", "models/nada/pms/male/medic.mdl", "models/nada/tiepilotcommander_male.mdl", "models/nada/tiepilot_male.mdl", "models/player/bbt/isb_agent/isb_agent.mdl" }
FACTION.departmentCode = "NAV"

FACTION_IMPERIAL_NAVY = FACTION.index

FACTION.noCreationSelect = true
