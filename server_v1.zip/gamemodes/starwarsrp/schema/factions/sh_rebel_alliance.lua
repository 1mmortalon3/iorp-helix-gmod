FACTION.name = "Rebel Alliance"
FACTION.desc = "Alliance personnel opposing the Galactic Empire."
FACTION.color = Color(50, 115, 210)
FACTION.isDefault = false
FACTION.pay = 100
FACTION.models = {
    "models/player/group03/male_01.mdl",
    "models/player/group03/male_02.mdl",
    "models/player/group03/male_03.mdl",
    "models/player/group03/male_04.mdl",
    "models/player/group03/male_05.mdl",
    "models/player/group03/male_06.mdl",
    "models/player/group03/male_07.mdl",
    "models/player/group03/male_08.mdl",
    "models/player/group03/male_09.mdl",
    "models/player/group03/female_01.mdl",
    "models/player/group03/female_02.mdl",
    "models/player/group03/female_03.mdl",
    "models/player/group03/female_04.mdl",
    "models/player/group03/female_05.mdl",
    "models/player/group03/female_06.mdl"
}
FACTION.departmentCode = "REB"
FACTION.noCreationSelect = true

FACTION_REBEL_ALLIANCE = FACTION.index
FACTION_THE_REBELS = FACTION.index
