FACTION.name      = "Imperial Commandos"
FACTION.desc      = "Elite special operations personnel assigned to high-risk missions."
FACTION.color     = Color(200, 200, 200)
FACTION.isDefault = false
FACTION.pay       = 181
FACTION.models    = { "models/nada/imperialcommandoscorch.mdl", "models/nada/imperialcommandosev.mdl", "models/nada/imperialcommandoboss.mdl", "models/nada/imperialcommandofixer.mdl" }
FACTION.departmentCode = "CMD"

FACTION_IMPERIAL_COMMANDOS = FACTION.index

FACTION.noCreationSelect = true
