FACTION.name      = "Purge Troopers"
FACTION.desc      = "Elite Imperial soldiers assigned to hunt Force-sensitive targets and support the Inquisitorius."
FACTION.color     = Color(45, 45, 45)
FACTION.isDefault = false
FACTION.pay       = 250
FACTION.models    = {
    "models/nada/pms/male/shadowguard.mdl",
    "models/nada/shadowguard.mdl",
    "models/player/shadow_guard.mdl",
    "models/player/shadowguard.mdl"
}
FACTION.departmentCode = "PURG"

FACTION_PURGE_TROOPERS = FACTION.index

FACTION.noCreationSelect = true
