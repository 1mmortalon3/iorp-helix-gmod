FACTION.name      = "Bounty Hunters"
FACTION.desc      = "Licensed outside assets working under Imperial contract."
FACTION.color     = Color(200, 200, 200)
FACTION.isDefault = false
FACTION.pay       = 400
FACTION.models    = { "models/nada/esb_bobafett.mdl" }
FACTION.departmentCode = "BHY"

FACTION_BOUNTY_HUNTERS = FACTION.index

FACTION.noCreationSelect = true
