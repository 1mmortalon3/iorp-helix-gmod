CLASS.name        = "Wilhuff Tarkin"
CLASS.faction     = FACTION_EMPERORS_INNER_CIRCLE

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become The Grand Moff and Imperial Advisor"
CLASS.limit       = 1
CLASS.salary      = 500
CLASS.models      = { "models/nada/wilhufftarkin.mdl" }
CLASS.weapons     = { "arccw_k_e11", "arccw_k_nade_thermal", "arccw_k_tl50", "arccw_k_se14" }
CLASS.command     = "tarkin"
CLASS.department  = "Emperors Inner Circle"
CLASS.departmentCode = "CIR"
CLASS.roleLabel   = "Officer"
CLASS.health      = 600
CLASS.maxHealth   = 600
CLASS.armor       = 300
CLASS.maxArmor    = 300
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 10
CLASS.attribs     = { ["diplomacy"] = 20, ["intellect"] = 15 }
