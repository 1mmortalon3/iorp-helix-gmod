CLASS.name        = "Imperial Royal Guard"
CLASS.faction     = FACTION_IMPERIAL_ROYAL_GUARD

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "An elite crimson-clad guardian trusted with the direct protection of the Emperor."
CLASS.limit       = 8
CLASS.salary      = 450
CLASS.models      = {
    "models/epangelmatikes/royalguard/royal_guard.mdl"
}
CLASS.weapons     = { "weapon_lightsaber_personal", "wos_inventory", "arccw_sops_empire_ee4", "arccw_cr2" }
CLASS.command     = "royalguard"
CLASS.department  = "Imperial Royal Guard"
CLASS.departmentCode = "IRG"
CLASS.roleLabel   = "Royal Guard"
CLASS.health      = 1500
CLASS.maxHealth   = 1500
CLASS.armor      = 600
CLASS.maxArmor   = 600
CLASS.ammoAR2     = 450
CLASS.sortOrder   = 21
CLASS.attribs     = { ["diplomacy"] = 5 }
