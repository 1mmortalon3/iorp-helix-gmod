CLASS.name        = "Death Trooper"
CLASS.faction     = FACTION_IMPERIAL_DEATH_TROOPER_DETACHMENT

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become A Death Trooper"
CLASS.limit       = 1
CLASS.salary      = 500
CLASS.models      = { "models/nada/deathtrooper.mdl" }
CLASS.weapons     = { "arccw_k_e11d", "arccw_k_nade_thermal", "arccw_k_tl50", "arccw_k_se14", "arccw_k_sx21", "arccw_k_nade_thermalimploder" }
CLASS.command     = "DTH1"
CLASS.department  = "Imperial Death Trooper Detachment"
CLASS.departmentCode = "DTH"
CLASS.roleLabel   = "Specialist"
CLASS.health      = 900
CLASS.maxHealth   = 900
CLASS.armor      = 500
CLASS.maxArmor   = 500
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 11
CLASS.attribs     = { ["agility"] = 15, ["spirit"] = 10 }
