CLASS.name        = "Shocktrooper"
CLASS.faction     = FACTION_IMPERIAL_SHOCK_REGIMENT

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become a Shocktrooper"
CLASS.limit       = 0
CLASS.salary      = 200
CLASS.models      = { "models/nada/rogueoneshock.mdl" }
CLASS.weapons     = { "arccw_k_e11_stun", "arccw_k_e11", "arccw_k_ec17", "weapon_cuff_police" }
CLASS.command     = "skpvt"
CLASS.department  = "Imperial Shock Regiment"
CLASS.departmentCode = "SHK"
CLASS.roleLabel   = "Trooper"
CLASS.health      = 600
CLASS.maxHealth   = 600
CLASS.armor       = 300
CLASS.maxArmor    = 300
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 2
CLASS.attribs     = { ["agility"] = 15, ["spirit"] = 10 }
