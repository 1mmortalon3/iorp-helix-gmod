CLASS.name        = "Captain of The Guardsman"
CLASS.faction     = FACTION_IMPERIAL_ROYAL_GUARD
CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "Command the Imperial Royal Guard, approve protective deployments, and control access to the Emperor."
CLASS.limit       = 0
CLASS.salary      = 500
CLASS.models      = {
     "models/epangelmatikes/royalguard/sovereign_protector.mdl"
}
CLASS.weapons     = {"weapon_lightsaber_personal", "wos_inventory", "arccw_sops_empire_ee4", "arccw_cr2"}
CLASS.command     = "rgcpt"
CLASS.department  = "Imperial Royal Guard"
CLASS.departmentCode = "IRG"
CLASS.roleLabel   = "Captain of The Guardsman"
CLASS.health      = 375
CLASS.maxHealth   = 375
CLASS.ammoAR2     = 550
CLASS.sortOrder   = 8
CLASS.attribs     = {["diplomacy"] = 20, ["intellect"] = 15, ["spirit"] = 25}
