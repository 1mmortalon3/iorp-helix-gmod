CLASS.name        = "Stormtrooper Squad Commander"
CLASS.faction     = FACTION_STORMTROOPER_CORPS

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become a storm trooper Commander"
CLASS.limit       = 0
CLASS.salary      = 250
CLASS.models      = { "models/nada/rogueonetk.mdl", "models/nada/pms/male/army.mdl" }
CLASS.weapons     = { "arccw_k_ec17", "arccw_k_e11", "arccw_k_t21", "arccw_k_nade_impact", "arccw_k_nade_thermal" }
CLASS.command     = "stbattcom"
CLASS.department  = "Stormtrooper Corps"
CLASS.departmentCode = "STC"
CLASS.roleLabel   = "Officer"
CLASS.health      = 600
CLASS.maxHealth   = 600
CLASS.armor       = 300
CLASS.maxArmor    = 300
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 1
CLASS.attribs     = { ["diplomacy"] = 20, ["intellect"] = 15 }
