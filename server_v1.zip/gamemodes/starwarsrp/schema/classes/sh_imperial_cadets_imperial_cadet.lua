CLASS.name        = "Imperial Cadet"
CLASS.faction     = FACTION_IMPERIAL_CADETS

CLASS.isDefault   = true
CLASS.whitelist   = false
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "Stormtrooper Cadet"
CLASS.limit       = 0
CLASS.salary      = 100
CLASS.models      = { "models/nada/imperialcadet_male.mdl", "models/nada/imperialcadet_female.mdl" }
CLASS.weapons     = { "arccw_k_e11_training", "arccw_k_rk3_training", "arccw_k_nade_decoy" }
CLASS.command     = "IC"
CLASS.department  = "Imperial Cadets"
CLASS.departmentCode = "CAD"
CLASS.roleLabel   = "Cadet"
CLASS.health      = 600
CLASS.maxHealth   = 600
CLASS.armor       = 300
CLASS.maxArmor    = 300
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 0
CLASS.attribs     = { ["diplomacy"] = 10 }
