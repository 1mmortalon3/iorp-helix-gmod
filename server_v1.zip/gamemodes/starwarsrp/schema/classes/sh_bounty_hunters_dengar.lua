local function SelectInstalledModel(candidates)
    for _, modelPath in ipairs(candidates) do
        if util.IsValidModel(modelPath) then
            return modelPath
        end
    end

    return "models/nada/esb_bobafett.mdl"
end

CLASS.name        = "Dengar"
CLASS.faction     = FACTION_BOUNTY_HUNTERS

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "A heavily armed veteran bounty hunter contracted by the Empire."
CLASS.limit       = 1
CLASS.salary      = 400
CLASS.models      = {
    SelectInstalledModel({
        "models/player/dengar.mdl",
        "models/nada/dengar.mdl",
        "models/kriegsyntax/sw_752/dengar.mdl",
        "models/imperial/dengar.mdl"
    })
}
CLASS.weapons     = { "arccw_sops_vibroknife", "arccw_k_ee3", "arccw_k_se14", "realistic_hook" }
CLASS.command     = "dengar"
CLASS.department  = "Bounty Hunters"
CLASS.departmentCode = "BHY"
CLASS.roleLabel   = "Heavy Contractor"
CLASS.health      = 1050
CLASS.maxHealth   = 1050
CLASS.armor       = 600
CLASS.maxArmor    = 600
CLASS.ammoAR2     = 650
CLASS.sortOrder   = 12
CLASS.attribs     = { ["diplomacy"] = 6 }
