CLASS.name        = "Purge Trooper Officer"
CLASS.faction     = FACTION_PURGE_TROOPERS

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become a Purge Trooper Officer"
CLASS.limit       = 0
CLASS.salary      = 325
CLASS.models      = { "models/player/sample/purge/officer/officer.mdl" }
CLASS.weapons     = { "arccw_k_e11", "arccw_k_dlt19", "arccw_k_ec17", "arccw_k_nade_impact", "arccw_k_nade_thermal", "arccw_k_melee_staff" }
CLASS.command     = "pgoff"
CLASS.department  = "Purge Troopers"
CLASS.departmentCode = "PURG"
CLASS.roleLabel   = "Officer"
CLASS.health      = 900
CLASS.maxHealth   = 900
CLASS.armor       = 450
CLASS.maxArmor    = 450
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 3
CLASS.attribs     = { ["diplomacy"] = 15, ["intellect"] = 20, ["spirit"] = 15 }
