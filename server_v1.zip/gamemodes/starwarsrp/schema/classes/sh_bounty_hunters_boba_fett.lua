CLASS.name        = "Boba Fett"
CLASS.faction     = FACTION_BOUNTY_HUNTERS

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "Be boba fett, a bounty hunter for the empire"
CLASS.limit       = 1
CLASS.salary      = 400
CLASS.models      = { "models/nada/esb_bobafett.mdl" }
CLASS.weapons     = { "arccw_sops_vibroknife", "arccw_k_ee3", "arccw_k_se14", "realistic_hook", "jet_mk5", "rw_sw_wristrocket", "rw_sw_wristflame" }
CLASS.command     = "boba"
CLASS.department  = "Bounty Hunters"
CLASS.departmentCode = "BHY"
CLASS.roleLabel   = "Contractor"
CLASS.health      = 900
CLASS.maxHealth   = 900
CLASS.armor       = 450
CLASS.maxArmor    = 450
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 11
CLASS.attribs     = { ["diplomacy"] = 10 }
