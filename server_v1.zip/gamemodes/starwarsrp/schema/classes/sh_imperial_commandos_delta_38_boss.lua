CLASS.name        = "Delta-38 Boss"
CLASS.faction     = FACTION_IMPERIAL_COMMANDOS

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become Delta 38"
CLASS.limit       = 1
CLASS.salary      = 250
CLASS.models      = { "models/nada/imperialcommandoboss.mdl" }
CLASS.weapons     = { "arccw_k_dc17m_rifle", "arccw_sops_vibroknife", "realistic_hook", "arccw_k_nade_impact", "arccw_k_nade_thermal", "arccw_k_nade_stun" }
CLASS.command     = "delta38"
CLASS.department  = "Imperial Commandos"
CLASS.departmentCode = "CMD"
CLASS.roleLabel   = "Specialist"
CLASS.health      = 600
CLASS.maxHealth   = 600
CLASS.armor       = 300
CLASS.maxArmor    = 300
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 6
CLASS.attribs     = { ["agility"] = 15, ["spirit"] = 10 }
