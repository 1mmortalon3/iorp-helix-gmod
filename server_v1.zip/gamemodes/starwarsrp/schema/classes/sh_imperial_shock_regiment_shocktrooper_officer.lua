CLASS.name        = "Shocktrooper Officer"
CLASS.faction     = FACTION_IMPERIAL_SHOCK_REGIMENT

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become a shock trooper officer"
CLASS.limit       = 0
CLASS.salary      = 300
CLASS.models      = { "models/nada/rogueoneshock.mdl", "models/nada/pms/male/trooper.mdl" }
CLASS.weapons     = { "arccw_k_e11_stun", "arccw_k_e11", "arccw_k_ec17", "weapon_cuff_police" }
CLASS.command     = "skoff"
CLASS.department  = "Imperial Shock Regiment"
CLASS.departmentCode = "SHK"
CLASS.roleLabel   = "Officer"
CLASS.health      = 600
CLASS.maxHealth   = 600
CLASS.armor       = 300
CLASS.maxArmor    = 300
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 2
CLASS.attribs     = { ["diplomacy"] = 20, ["intellect"] = 15 }
