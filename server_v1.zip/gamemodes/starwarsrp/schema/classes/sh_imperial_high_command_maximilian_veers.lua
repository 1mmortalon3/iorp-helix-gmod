CLASS.name        = "Maximilian Veers"
CLASS.faction     = FACTION_IMPERIAL_HIGH_COMMAND

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become The Army General"
CLASS.limit       = 1
CLASS.salary      = 400
CLASS.models      = { "models/nada/maximilianveers.mdl" }
CLASS.weapons     = { "arccw_k_e11", "arccw_k_nade_thermal", "arccw_k_tl50", "arccw_k_se14" }
CLASS.command     = "veers"
CLASS.department  = "Imperial High Command"
CLASS.departmentCode = "HICOM"
CLASS.roleLabel   = "Officer"
CLASS.health      = 600
CLASS.maxHealth   = 600
CLASS.armor       = 300
CLASS.maxArmor    = 300
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 9
CLASS.attribs     = { ["diplomacy"] = 20, ["intellect"] = 15 }
