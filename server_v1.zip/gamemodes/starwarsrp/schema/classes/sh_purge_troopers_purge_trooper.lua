CLASS.name        = "Purge Trooper"
CLASS.faction     = FACTION_PURGE_TROOPERS

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become a Purge Trooper"
CLASS.limit       = 0
CLASS.salary      = 225
CLASS.models      = { "models/player/sample/purge/trooper/trooper.mdl" }
CLASS.weapons     = { "arccw_k_e11", "arccw_k_ec17", "arccw_k_nade_impact", "arccw_k_nade_thermal", "arccw_k_melee_staff" }
CLASS.command     = "pgtrooper"
CLASS.department  = "Purge Troopers"
CLASS.departmentCode = "PURG"
CLASS.roleLabel   = "Trooper"
CLASS.health      = 800
CLASS.maxHealth   = 800
CLASS.armor       = 400
CLASS.maxArmor    = 400
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 1
CLASS.attribs     = { ["agility"] = 20, ["spirit"] = 15 }
