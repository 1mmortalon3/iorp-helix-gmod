local function SelectInstalledModel(candidates)
    for _, modelPath in ipairs(candidates) do
        if util.IsValidModel(modelPath) then
            return modelPath
        end
    end

    return "models/nada/esb_bobafett.mdl"
end

CLASS.name        = "Bossk"
CLASS.faction     = FACTION_BOUNTY_HUNTERS

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "A Trandoshan tracker specializing in pursuit, capture, and close combat."
CLASS.limit       = 1
CLASS.salary      = 400
CLASS.models      = {
    SelectInstalledModel({
        "models/player/bossk.mdl",
        "models/nada/bossk.mdl",
        "models/kriegsyntax/sw_752/bossk.mdl",
        "models/imperial/bossk.mdl"
    })
}
CLASS.weapons     = { "arccw_sops_vibroknife", "arccw_k_ee3", "arccw_k_se14", "realistic_hook" }
CLASS.command     = "bossk"
CLASS.department  = "Bounty Hunters"
CLASS.departmentCode = "BHY"
CLASS.roleLabel   = "Tracker Contractor"
CLASS.health      = 1200
CLASS.maxHealth   = 1200
CLASS.armor       = 600
CLASS.maxArmor    = 600
CLASS.ammoAR2     = 550
CLASS.sortOrder   = 13
CLASS.attribs     = { ["diplomacy"] = 4 }
