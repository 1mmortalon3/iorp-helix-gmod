CLASS.name        = "Imperial Navy ISB Agent"
CLASS.faction     = FACTION_IMPERIAL_NAVY

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become a ISB Agent"
CLASS.limit       = 0
CLASS.salary      = 45
CLASS.models      = { "models/player/bbt/isb_agent/isb_agent.mdl" }
CLASS.weapons     = { "arccw_k_ec17", "arccw_k_e11", "arccw_k_sx21", "alydus_fusioncutter" }
CLASS.command     = "navyisb"
CLASS.department  = "Imperial Navy"
CLASS.departmentCode = "NAV"
CLASS.roleLabel   = "ISB Agent"
CLASS.health      = 600
CLASS.maxHealth   = 600
CLASS.armor       = 300
CLASS.maxArmor    = 300
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 5
CLASS.attribs     = { ["diplomacy"] = 20, ["intellect"] = 15 }
