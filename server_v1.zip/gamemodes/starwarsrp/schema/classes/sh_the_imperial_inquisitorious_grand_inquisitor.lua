CLASS.name        = "Grand Inquisitor"
CLASS.faction     = FACTION_THE_IMPERIAL_INQUISITORIOUS

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become The Grand Inquisitor"
CLASS.limit       = 1
CLASS.salary      = 500
CLASS.models      = { "models/lucky/grand_inquisitor.mdl" }
CLASS.weapons     = { "weapon_lightsaber_inquisitor", "wos_inventory" }
CLASS.command     = "grand"
CLASS.department  = "The Imperial Inquisitorious"
CLASS.departmentCode = "INQ"
CLASS.roleLabel   = "Inquisitor"
CLASS.health      = 1200
CLASS.maxHealth   = 1200
CLASS.armor       = 600
CLASS.maxArmor    = 600
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 10
CLASS.attribs     = { ["spirit"] = 35, ["intellect"] = 15 }
