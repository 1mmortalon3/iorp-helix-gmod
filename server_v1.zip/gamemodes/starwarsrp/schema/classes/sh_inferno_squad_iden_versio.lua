CLASS.name        = "Iden Versio"
CLASS.faction     = FACTION_INFERNO_SQUAD

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become Inferno Squad"
CLASS.limit       = 1
CLASS.salary      = 150
CLASS.models      = { "models/nada/idenversio.mdl" }
CLASS.weapons     = { "arccw_k_e11", "arccw_k_rk3", "arccw_k_nade_impact", "arccw_k_nade_thermal", "arccw_k_tl50", "rw_sw_bino_dark", "realistic_hook" }
CLASS.command     = "versio"
CLASS.department  = "Inferno Squad"
CLASS.departmentCode = "INF"
CLASS.roleLabel   = "Specialist"
CLASS.health      = 600
CLASS.maxHealth   = 600
CLASS.armor       = 300
CLASS.maxArmor    = 300
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 7
CLASS.attribs     = { ["agility"] = 15, ["spirit"] = 10 }
