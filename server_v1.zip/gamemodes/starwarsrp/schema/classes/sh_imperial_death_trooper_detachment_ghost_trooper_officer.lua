CLASS.name        = "Ghost Trooper Officer"
CLASS.faction     = FACTION_IMPERIAL_DEATH_TROOPER_DETACHMENT

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become A Ghost Trooper Officer"
CLASS.limit       = 1
CLASS.salary      = 500
CLASS.models      = { "models/nada/ghosttrooper.mdl" }
CLASS.weapons     = { "arccw_k_e11d", "arccw_k_nade_thermal", "arccw_k_tl50", "arccw_k_se14", "arccw_k_dlt19x", "arccw_sops_vibroknife" }
CLASS.command     = "GHO2"
CLASS.department  = "Imperial Death Trooper Detachment"
CLASS.departmentCode = "DTH"
CLASS.roleLabel   = "Officer"
CLASS.health      = 600
CLASS.maxHealth   = 600
CLASS.armor       = 300
CLASS.maxArmor    = 300
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 11
CLASS.attribs     = { ["diplomacy"] = 20, ["intellect"] = 15 }
