CLASS.name        = "Shocktrooper Battalion Commander"
CLASS.faction     = FACTION_IMPERIAL_SHOCK_REGIMENT

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become a shock trooper Commander"
CLASS.limit       = 1
CLASS.salary      = 350
CLASS.models      = { "models/nada/rogueoneshock.mdl", "models/nada/pms/male/army.mdl" }
CLASS.weapons     = { "arccw_k_e11_stun", "arccw_k_e11", "arccw_k_ec17", "weapon_cuff_police" }
CLASS.command     = "skbattcom"
CLASS.department  = "Imperial Shock Regiment"
CLASS.departmentCode = "SHK"
CLASS.roleLabel   = "Officer"
CLASS.health      = 600
CLASS.maxHealth   = 600
CLASS.armor       = 300
CLASS.maxArmor    = 300
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 2
CLASS.attribs     = { ["diplomacy"] = 20, ["intellect"] = 15 }
