local function SelectInstalledModel(candidates)
    for _, modelPath in ipairs(candidates) do
        if util.IsValidModel(modelPath) then
            return modelPath
        end
    end

    return "models/nada/esb_bobafett.mdl"
end

CLASS.name        = "IG-88"
CLASS.faction     = FACTION_BOUNTY_HUNTERS

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "An assassin droid programmed for precision hunting and Imperial contracts."
CLASS.limit       = 1
CLASS.salary      = 400
CLASS.models      = {
    SelectInstalledModel({
        "models/kryptonite/ig88/ig88.mdl",
    })
}
CLASS.weapons     = { "arccw_k_ee3", "arccw_k_se14" }
CLASS.command     = "ig88"
CLASS.department  = "Bounty Hunters"
CLASS.departmentCode = "BHY"
CLASS.roleLabel   = "Assassin Droid"
CLASS.health      = 1350
CLASS.maxHealth   = 1350
CLASS.armor       = 600
CLASS.maxArmor    = 600
CLASS.ammoAR2     = 800
CLASS.sortOrder   = 14
CLASS.attribs     = { ["diplomacy"] = 2 }
