CLASS.name        = "501st Trooper"
CLASS.faction     = FACTION_501ST_LEGION

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become a 501st Legion Trooper"
CLASS.limit       = 0
CLASS.salary      = 150
CLASS.models      = { "models/player/bunny/imperial_501_revision/501_trooper.mdl" }
CLASS.weapons     = { "arccw_k_e11", "arccw_k_ec17", "arccw_k_nade_impact", "arccw_k_nade_thermal" }
CLASS.command     = "501pvt"
CLASS.department  = "501st Legion"
CLASS.departmentCode = "501"
CLASS.roleLabel   = "Trooper"
CLASS.health      = 650
CLASS.maxHealth   = 650
CLASS.armor       = 350
CLASS.maxArmor    = 350
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 1
CLASS.attribs     = { ["agility"] = 15, ["spirit"] = 10 }
