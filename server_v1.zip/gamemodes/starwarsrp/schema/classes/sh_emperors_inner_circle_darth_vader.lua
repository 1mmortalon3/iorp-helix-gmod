CLASS.name        = "Darth Vader"
CLASS.faction     = FACTION_EMPERORS_INNER_CIRCLE

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become The Emperors Right Hand"
CLASS.limit       = 1
CLASS.salary      = 500
CLASS.models      = { "models/nanb_darth_vader.mdl" }
CLASS.weapons     = { "weapon_lightsaber_vader", "wos_inventory" }
CLASS.command     = "vader"
CLASS.department  = "Emperors Inner Circle"
CLASS.departmentCode = "CIR"
CLASS.roleLabel   = "Sith"
CLASS.health      = 12500
CLASS.maxHealth   = 12500
CLASS.armor       = 3000
CLASS.maxArmor    = 3000
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 10
CLASS.attribs     = { ["agility"] = 15, ["spirit"] = 10 }
