CLASS.name        = "Purge Trooper Commander"
CLASS.faction     = FACTION_PURGE_TROOPERS

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become the Purge Trooper Commander"
CLASS.limit       = 1
CLASS.salary      = 375
CLASS.models      = { "models/nada/purgetroopercommander.mdl" }
CLASS.weapons     = { "arccw_k_e11", "arccw_k_dlt19", "arccw_k_ec17", "weapon_cuff_standard", "rw_sw_nade_thermal", "rw_sw_nade_impact", "arccw_k_melee_staff", "arccw_k_melee_dagger" }
CLASS.command     = "pgcmd"
CLASS.department  = "Purge Troopers"
CLASS.departmentCode = "PURG"
CLASS.roleLabel   = "Commander"
CLASS.health      = 950
CLASS.maxHealth   = 950
CLASS.armor       = 500
CLASS.maxArmor    = 500
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 4
CLASS.attribs     = { ["diplomacy"] = 20, ["intellect"] = 20, ["spirit"] = 20 }
