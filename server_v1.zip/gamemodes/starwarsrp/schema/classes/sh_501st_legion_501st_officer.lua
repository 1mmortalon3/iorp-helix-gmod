CLASS.name        = "501st Officer"
CLASS.faction     = FACTION_501ST_LEGION

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become a 501st Legion Officer"
CLASS.limit       = 0
CLASS.salary      = 225
CLASS.models      = { "models/player/bunny/imperial_501_revision/501_officer.mdl", "models/nada/pms/male/trooper.mdl" }
CLASS.weapons     = { "arccw_k_dlt19", "arccw_k_e11", "arccw_k_ec17", "arccw_k_nade_thermal", "arccw_k_nade_impact" }
CLASS.command     = "501off"
CLASS.department  = "501st Legion"
CLASS.departmentCode = "501"
CLASS.roleLabel   = "Officer"
CLASS.health      = 700
CLASS.maxHealth   = 700
CLASS.armor       = 400
CLASS.maxArmor    = 400
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 3
CLASS.attribs     = { ["diplomacy"] = 20, ["intellect"] = 15 }
