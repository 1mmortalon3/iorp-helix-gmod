CLASS.name        = "Purge Trooper NCO"
CLASS.faction     = FACTION_PURGE_TROOPERS

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become a Purge Trooper NCO"
CLASS.limit       = 0
CLASS.salary      = 275
CLASS.models      = { "models/player/sample/purge/sgt/sgt.mdl" }
CLASS.weapons     = { "arccw_k_e11", "arccw_k_dlt19", "arccw_k_ec17", "weapon_cuff_standard", "rw_sw_nade_thermal", "rw_sw_nade_impact", "arccw_k_melee_staff" }
CLASS.command     = "pgnco"
CLASS.department  = "Purge Troopers"
CLASS.departmentCode = "PURG"
CLASS.roleLabel   = "NCO"
CLASS.health      = 850
CLASS.maxHealth   = 850
CLASS.armor       = 425
CLASS.maxArmor    = 425
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 2
CLASS.attribs     = { ["agility"] = 20, ["spirit"] = 15, ["intellect"] = 10 }
