CLASS.name        = "Royal Guard Trainee"
CLASS.faction     = FACTION_IMPERIAL_ROYAL_GUARD

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "A hand-selected initiate undergoing final training for service within the Imperial Royal Guard."
CLASS.limit       = 8
CLASS.salary      = 350
CLASS.models      = {
    "models/epangelmatikes/royalguard/player_guard.mdl"
}
CLASS.weapons     = { "weapon_lightsaber_personal", "wos_inventory", "arccw_sops_empire_ee4", "arccw_cr2" }
CLASS.command     = "rginitiate"
CLASS.department  = "Imperial Royal Guard"
CLASS.departmentCode = "IRG"
CLASS.roleLabel   = "Guard Initiate"
CLASS.health      = 1500
CLASS.maxHealth   = 1500
CLASS.armor      = 600
CLASS.maxArmor   = 600
CLASS.ammoAR2     = 350
CLASS.sortOrder   = 20
CLASS.attribs     = { ["diplomacy"] = 3 }
