CLASS.name        = "Imperal Shadow Guard"
CLASS.faction     = FACTION_IMPERIAL_ROYAL_GUARD

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "A veteran Shadow Guard assigned to secure restricted Imperial facilities and high-value personnel."
CLASS.limit       = 4
CLASS.salary      = 525
CLASS.models      = {
    "models/epangelmatikes/royalguard/shawod_guard.mdl"
}
CLASS.weapons     = { "weapon_lightsaber_personal", "wos_inventory", "arccw_sops_empire_ee4", "arccw_cr2" }
CLASS.command     = "rgsentinel"
CLASS.department  = "Imperial Royal Guard"
CLASS.departmentCode = "IRG"
CLASS.roleLabel   = "Shadow Guard"
CLASS.health      = 1500
CLASS.maxHealth   = 1500
CLASS.armor      = 600
CLASS.maxArmor   = 600
CLASS.ammoAR2     = 550
CLASS.sortOrder   = 22
CLASS.attribs     = { ["diplomacy"] = 6 }
