CLASS.name        = "Del Meeko"
CLASS.faction     = FACTION_INFERNO_SQUAD

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become Inferno Squad"
CLASS.limit       = 1
CLASS.salary      = 125
CLASS.models      = { "models/nada/delmeeko.mdl" }
CLASS.weapons     = { "arccw_k_e11", "arccw_k_t21", "alydus_fusioncutter", "realistic_hook", "arccw_k_rk3" }
CLASS.command     = "meeko"
CLASS.department  = "Inferno Squad"
CLASS.departmentCode = "INF"
CLASS.roleLabel   = "Specialist"
CLASS.health      = 600
CLASS.maxHealth   = 600
CLASS.armor       = 300
CLASS.maxArmor    = 300
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 7
CLASS.attribs     = { ["agility"] = 15, ["spirit"] = 10 }
