CLASS.name        = "Delta-40 Fixer"
CLASS.faction     = FACTION_IMPERIAL_COMMANDOS

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become Delta 40"
CLASS.limit       = 1
CLASS.salary      = 150
CLASS.models      = { "models/nada/imperialcommandofixer.mdl" }
CLASS.weapons     = { "arccw_k_dc17m_rifle", "arccw_sops_vibroknife", "arccw_k_nade_thermite", "arccw_k_nade_thermal", "rw_sw_nade_impact" }
CLASS.command     = "delta40"
CLASS.department  = "Imperial Commandos"
CLASS.departmentCode = "CMD"
CLASS.roleLabel   = "Specialist"
CLASS.health      = 600
CLASS.maxHealth   = 600
CLASS.armor       = 300
CLASS.maxArmor    = 300
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 6
CLASS.attribs     = { ["agility"] = 15, ["spirit"] = 10 }
