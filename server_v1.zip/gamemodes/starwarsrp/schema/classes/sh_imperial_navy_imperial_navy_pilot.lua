CLASS.name        = "Imperial Navy Pilot"
CLASS.faction     = FACTION_IMPERIAL_NAVY

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "You are a Naval Tie Pilot"
CLASS.limit       = 1
CLASS.salary      = 250
CLASS.models      = { "models/nada/tiepilotcommander_male.mdl", "models/nada/tiepilot_male.mdl" }
CLASS.weapons     = { "arccw_k_ec17", "arccw_k_e11", "arccw_k_sx21", "alydus_fusioncutter" }
CLASS.command     = "navaltp"
CLASS.department  = "Imperial Navy"
CLASS.departmentCode = "NAV"
CLASS.roleLabel   = "Naval"
CLASS.health      = 600
CLASS.maxHealth   = 600
CLASS.armor       = 300
CLASS.maxArmor    = 300
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 5
CLASS.attribs     = { ["intellect"] = 20, ["agility"] = 10 }
