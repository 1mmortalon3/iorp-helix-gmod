CLASS.name        = "501st Legion Commander"
CLASS.faction     = FACTION_501ST_LEGION

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become the 501st Legion Commander"
CLASS.limit       = 1
CLASS.salary      = 300
CLASS.models      = { "models/player/bunny/imperial_501_revision/501_commander.mdl", "models/nada/pms/male/army.mdl" }
CLASS.weapons     = { "arccw_k_ec17", "arccw_k_e11", "arccw_k_t21", "weapon_cuff_standard", "arccw_k_nade_impact", "arccw_k_nade_thermal" }
CLASS.command     = "501cmd"
CLASS.department  = "501st Legion"
CLASS.departmentCode = "501"
CLASS.roleLabel   = "Commander"
CLASS.health      = 750
CLASS.maxHealth   = 750
CLASS.armor       = 425
CLASS.maxArmor    = 425
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 4
CLASS.attribs     = { ["diplomacy"] = 20, ["intellect"] = 20, ["spirit"] = 10 }
