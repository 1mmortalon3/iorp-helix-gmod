CLASS.name        = "501st NCO"
CLASS.faction     = FACTION_501ST_LEGION

CLASS.isDefault   = false
CLASS.whitelist   = true
function CLASS:CanSwitchTo(client) if IMPERIAL_ORDER_CanUseClassV58 then return IMPERIAL_ORDER_CanUseClassV58(client, self) end return self.isDefault == true end
CLASS.description = "become a 501st Legion NCO"
CLASS.limit       = 0
CLASS.salary      = 185
CLASS.models      = { "models/player/bunny/imperial_501_revision/501_sergeant.mdl", "models/nada/pms/male/trooper.mdl" }
CLASS.weapons     = { "arccw_k_rk3", "arccw_k_e11", "arccw_k_dlt19", "weapon_cuff_standard", "rw_sw_nade_thermal", "rw_sw_nade_impact" }
CLASS.command     = "501nco"
CLASS.department  = "501st Legion"
CLASS.departmentCode = "501"
CLASS.roleLabel   = "NCO"
CLASS.health      = 675
CLASS.maxHealth   = 675
CLASS.armor       = 375
CLASS.maxArmor    = 375
CLASS.ammoAR2     = 500
CLASS.sortOrder   = 2
CLASS.attribs     = { ["agility"] = 15, ["spirit"] = 10, ["intellect"] = 10 }
