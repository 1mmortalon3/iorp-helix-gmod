PLUGIN.name        = "Imperial Order Chat"
PLUGIN.author      = "Imperial Order"
PLUGIN.description = "Custom chat commands including /laws"

ix.util.Include("cl_chat.lua")
ix.util.Include("sv_chat.lua")
