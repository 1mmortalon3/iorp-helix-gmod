IMPERIAL_ORDER_FILE_GUARDS = IMPERIAL_ORDER_FILE_GUARDS or {}
if IMPERIAL_ORDER_FILE_GUARDS["schema.plugins.chat.sv_chat.lua"] then return end
IMPERIAL_ORDER_FILE_GUARDS["schema.plugins.chat.sv_chat.lua"] = true

util.AddNetworkString("IMPERIAL_ORDER.SyncLaws")

IMPERIAL_ORDER_SERVER_LAWS = IMPERIAL_ORDER_SERVER_LAWS or {
    "No RDM.",
    "No NLR.",
    "Follow faction orders.",
    "Stay IC.",
    "No prop abuse.",
    "Respect the chain of command."
}

local function SyncLaws(target)
    net.Start("IMPERIAL_ORDER.SyncLaws")
    net.WriteTable(IMPERIAL_ORDER_SERVER_LAWS)

    if target then
        net.Send(target)
    else
        net.Broadcast()
    end
end

hook.Add("PlayerInitialSpawn", "IMPERIAL_ORDER.SyncLawsOnJoin", function(ply)
    timer.Simple(3, function()
        if IsValid(ply) then
            SyncLaws(ply)
        end
    end)
end)

concommand.Add("imperial_order_admin_setlaws", function(admin, _, args)
    if IsValid(admin) and not admin:IsAdmin() then return end

    local laws = util.JSONToTable(table.concat(args, " "))
    if istable(laws) then
        IMPERIAL_ORDER_SERVER_LAWS = laws
        SyncLaws()
    end
end)
