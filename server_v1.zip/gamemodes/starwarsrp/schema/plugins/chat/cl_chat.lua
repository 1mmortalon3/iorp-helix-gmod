IMPERIAL_ORDER_FILE_GUARDS = IMPERIAL_ORDER_FILE_GUARDS or {}
if IMPERIAL_ORDER_FILE_GUARDS["schema.plugins.chat.cl_chat.lua"] then return end
IMPERIAL_ORDER_FILE_GUARDS["schema.plugins.chat.cl_chat.lua"] = true

IMPERIAL_ORDER_UI_LOADED = IMPERIAL_ORDER_UI_LOADED or {}
IMPERIAL_ORDER_UI_LOADED["chat"] = true
IMPERIAL_ORDER_SERVER_LAWS = IMPERIAL_ORDER_SERVER_LAWS or {}

net.Receive("IMPERIAL_ORDER.SyncLaws", function()
    IMPERIAL_ORDER_SERVER_LAWS = net.ReadTable() or {}
end)

hook.Add("OnPlayerChat", "IMPERIAL_ORDER.LawsCommand", function(ply, text)
    if string.lower(text or "") == "/laws" then
        if IMPERIAL_ORDER_CHATBOX_AddSystem then
            IMPERIAL_ORDER_CHATBOX_AddSystem("=== Server Laws ===", Color(246, 247, 250))
            for i, law in ipairs(IMPERIAL_ORDER_SERVER_LAWS or {}) do
                IMPERIAL_ORDER_CHATBOX_AddLine("LAW " .. i, law, Color(80, 200, 220))
            end
        else
            chat.AddText(Color(246, 247, 250), "=== Server Laws ===")
            for i, law in ipairs(IMPERIAL_ORDER_SERVER_LAWS or {}) do
                chat.AddText(Color(80, 200, 220), i .. ". ", Color(220, 218, 235), law)
            end
        end

        return true
    end
end)
