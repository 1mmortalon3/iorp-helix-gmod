PLUGIN.name = "Imperial Order Certifications"
PLUGIN.author = "1mmortalon3"
PLUGIN.description = "Earned certifications with overhead badges, staff awarding, and a per-character record."

ix.util.Include("sh_config.lua")
ix.util.Include("sv_certifications.lua")
ix.util.Include("cl_certifications.lua")
