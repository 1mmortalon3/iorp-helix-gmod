--[[
    Imperial Order - Certifications (client)

    Exposes IMPERIAL_ORDER_GetOverheadCertifications(ply), which the overhead
    nameplate in imperial_order_core/cl_overhead_ui.lua calls once per cache
    cycle. It reads a networked string rather than requesting anything, so
    drawing badges costs nothing per frame.

    If this plugin is removed the provider simply stops existing and the
    nameplate falls back to name + role with no errors.
]]

if (SERVER) then return end

local CERT = IMPERIAL_ORDER_CERTS
if (not CERT) then return end

local NET_SYNC    = "IMPERIAL_ORDER.Certifications.Sync"
local NET_REQUEST = "IMPERIAL_ORDER.Certifications.Request"
local NET_OPEN    = "IMPERIAL_ORDER.Certifications.Open"

local NW_BADGES = "imperial_orderCertBadges"
local NW_COUNT  = "imperial_orderCertCount"

local showBadges = CreateClientConVar("imperial_order_certs_overhead", "1", true, false,
    "Show certification badges on the overhead nameplate.")

surface.CreateFont("IMPERIAL_ORDER.Cert.Badge", {
    font = "Trebuchet MS", size = 11, weight = 900, antialias = true, extended = true
})

surface.CreateFont("IMPERIAL_ORDER.Cert.Title", {
    font = "Trebuchet MS", size = 21, weight = 900, antialias = true, extended = true
})

surface.CreateFont("IMPERIAL_ORDER.Cert.Body", {
    font = "Trebuchet MS", size = 15, weight = 600, antialias = true, extended = true
})

surface.CreateFont("IMPERIAL_ORDER.Cert.Small", {
    font = "Trebuchet MS", size = 13, weight = 700, antialias = true, extended = true
})

--[[ ------------------------------------------------------------------------
    Overhead badge provider
--------------------------------------------------------------------------- ]]

--- Returns an array of {text, color} for the nameplate, or nil.
-- Resolving abbreviation back to a definition gives us the category colour
-- without networking it per player.
function IMPERIAL_ORDER_GetOverheadCertifications(ply)
    if (not showBadges:GetBool()) then return nil end
    if (not IsValid(ply)) then return nil end

    local packed = ply:GetNW2String(NW_BADGES, "")
    if (packed == "") then return nil end

    local out = {}
    for _, badge in ipairs(string.Explode("|", packed)) do
        badge = string.Trim(badge)
        if (badge ~= "") then
            -- "EOD II" -> match on the abbreviation ahead of the numeral.
            local abbr = string.match(badge, "^(%S+)") or badge
            local color

            for _, def in pairs(CERT.List) do
                if (def.abbr == abbr) then color = def.color break end
            end

            out[#out + 1] = {text = badge, color = color or Color(134, 139, 145)}
        end
    end

    if (#out == 0) then return nil end

    return out
end

--[[ ------------------------------------------------------------------------
    Certifications menu
--------------------------------------------------------------------------- ]]

local function Col(name, fallback)
    if (IU and IU.Colors and IU.Colors[name]) then return IU.Colors[name] end
    return fallback
end

local activeFrame

local function BuildFrame(targetName, entries)
    if (IsValid(activeFrame)) then activeFrame:Remove() end
    local red = Col("red", Color(174, 8, 15))
    local panel = Col("panel", Color(12, 14, 17, 250))
    local text = Col("text", Color(228, 230, 233))
    local dim = Col("textDim", Color(151, 156, 165))
    local width, height = math.min(1040, ScrW() - 32), math.min(760, ScrH() - 32)
    local frame = vgui.Create("DFrame")
    activeFrame = frame
    frame:SetSize(width, height)
    frame:Center()
    frame:SetTitle("")
    frame:ShowCloseButton(false)
    frame:SetDraggable(false)
    frame:DockPadding(20, 100, 20, 40)
    frame:MakePopup()
    frame.Paint = function(_, w, h)
        draw.RoundedBox(2, 0, 0, w, h, panel)
        surface.SetDrawColor(52, 55, 62)
        surface.DrawOutlinedRect(0, 0, w, h)
        surface.SetDrawColor(red)
        surface.DrawRect(0, 0, w, 3)
        surface.DrawRect(20, 24, 4, 47)
        draw.SimpleText("IMPERIAL ORDER", "IMPERIAL_ORDER.Cert.Small", 38, 25, red)
        draw.SimpleText("CERTIFICATION RECORD", "IMPERIAL_ORDER.Cert.Title", 38, 44, text)
        surface.SetDrawColor(45, 48, 54)
        surface.DrawLine(20, 85, w - 20, 85)
        draw.SimpleText("PERSONNEL RECORD  /  " .. #entries .. " CERTIFICATIONS",
            "IMPERIAL_ORDER.Cert.Small", 20, h - 24, dim)
        draw.SimpleText("F9  /  CLOSE", "IMPERIAL_ORDER.Cert.Small",
            w - 20, h - 24, dim, TEXT_ALIGN_RIGHT)
    end

    local function Button(parent, caption)
        local button = vgui.Create("DButton", parent)
        button:SetText("")
        button.Paint = function(self, w, h)
            draw.RoundedBox(2, 0, 0, w, h, self:IsHovered() and red
                or Color(red.r, red.g, red.b, 70))
            surface.SetDrawColor(red)
            surface.DrawOutlinedRect(0, 0, w, h)
            draw.SimpleText(self.Caption or caption, "IMPERIAL_ORDER.Cert.Small",
                w / 2, h / 2, text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        return button
    end
    local close = Button(frame, "X")
    close:SetPos(width - 54, 25)
    close:SetSize(34, 34)
    close.DoClick = function() frame:Remove() end

    local function Line(parent, value, font, color)
        local label = vgui.Create("DLabel", parent)
        label:Dock(TOP)
        label:DockMargin(0, 0, 0, 10)
        label:SetFont(font or "IMPERIAL_ORDER.Cert.Body")
        label:SetTextColor(color or text)
        label:SetText(value)
        label:SetWrap(true)
        label:SetAutoStretchVertical(true)
        return label
    end
    Line(frame, string.upper(targetName), "IMPERIAL_ORDER.Cert.Title")

    local toolbar = vgui.Create("DPanel", frame)
    toolbar:Dock(TOP)
    toolbar:SetTall(36)
    toolbar:DockMargin(0, 4, 0, 16)
    toolbar.Paint = function() end
    local toggle = Button(toolbar, "OVERHEAD BADGES")
    toggle:Dock(RIGHT)
    toggle:SetWide(192)
    toggle.Think = function(self)
        self.Caption = showBadges:GetBool() and "OVERHEAD BADGES: ON" or "OVERHEAD BADGES: OFF"
    end
    toggle.DoClick = function()
        RunConsoleCommand("imperial_order_certs_overhead", showBadges:GetBool() and "0" or "1")
    end
    local search = vgui.Create("DTextEntry", toolbar)
    search:Dock(FILL)
    search:DockMargin(0, 0, 14, 0)
    search:SetFont("IMPERIAL_ORDER.Cert.Body")
    search:SetUpdateOnType(true)
    search.Paint = function(self, w, h)
        draw.RoundedBox(2, 0, 0, w, h, Color(22, 24, 29))
        surface.SetDrawColor(self:HasFocus() and red or Color(52, 55, 62))
        surface.DrawOutlinedRect(0, 0, w, h)
        self:DrawTextEntryText(text, red, text)
        if (self:GetValue() == "" and not self:HasFocus()) then
            draw.SimpleText("Search certifications...", "IMPERIAL_ORDER.Cert.Body",
                10, h / 2, dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
    end

    local scroll = vgui.Create("DScrollPanel", frame)
    scroll:Dock(FILL)
    local bar = scroll:GetVBar()
    bar:SetWide(5)
    bar.Paint = function() end
    bar.btnUp.Paint = function() end
    bar.btnDown.Paint = function() end
    bar.btnGrip.Paint = function(_, w, h) draw.RoundedBox(0, 0, 0, w, h, red) end

    local function Populate()
        scroll:Clear()
        local query = string.lower(string.Trim(search:GetValue()))
        local shown = 0
        for _, entry in ipairs(entries) do
            local def = CERT.Get(entry.id)
            if (def) then
                local category = CERT.Categories[def.category]
                local categoryName = category and category.name or def.category
                local name = CERT.FormatName(entry.id, entry.tier) or def.name or entry.id
                local haystack = string.lower(name .. " " .. entry.id .. " " .. categoryName)
                if (query == "" or string.find(haystack, query, 1, true)) then
                    shown = shown + 1
                    local card = scroll:Add("DPanel")
                    card:Dock(TOP)
                    card:DockMargin(0, 0, 10, 14)
                    card:DockPadding(20, 18, 20, 16)
                    card:SetTall(174)
                    card.Paint = function(_, w, h)
                        draw.RoundedBox(2, 0, 0, w, h, Color(22, 24, 29))
                        surface.SetDrawColor(43, 46, 53)
                        surface.DrawOutlinedRect(0, 0, w, h)
                        surface.SetDrawColor(red)
                        surface.DrawRect(0, 0, 3, h)
                    end
                    Line(card, string.upper(categoryName) .. "  /  "
                        .. (CERT.FormatBadge(entry.id, entry.tier) or def.abbr),
                        "IMPERIAL_ORDER.Cert.Small", dim)
                    Line(card, name, "IMPERIAL_ORDER.Cert.Title")
                    Line(card, def.description or "", nil, text)
                    local stamp = entry.at > 0 and os.date("%d %b %Y", entry.at) or "Unknown date"
                    Line(card, "ISSUED  /  " .. stamp .. "    |    AUTHORIZED BY  /  "
                        .. entry.by, "IMPERIAL_ORDER.Cert.Small", dim)
                    card.Think = function(self)
                        local total = 34
                        for _, child in ipairs(self:GetChildren()) do
                            local _, top, _, bottom = child:GetDockMargin()
                            total = total + child:GetTall() + top + bottom
                        end
                        if (math.abs(self:GetTall() - total) > 1) then self:SetTall(total) end
                    end
                end
            end
        end
        if (shown == 0) then
            Line(scroll:GetCanvas(), #entries == 0 and "No certifications on record."
                or "No certifications match your search.", nil, dim)
        end
    end
    search.OnValueChange = Populate
    Populate()
end

-- Rising-edge polling works even when the Derma window owns keyboard focus.
local f9Held = false
hook.Add("Think", "IMPERIAL_ORDER.Certifications.F9Menu", function()
    local down = input.IsKeyDown(KEY_F9)
    local pressed = down and not f9Held
    f9Held = down
    if (not pressed or gui.IsGameUIVisible()) then return end
    local client = LocalPlayer()
    if (not IsValid(client) or not client:GetCharacter()) then return end
    if (IsValid(activeFrame)) then
        activeFrame:Remove()
        return
    end
    net.Start(NET_REQUEST)
        net.WriteEntity(client)
    net.SendToServer()
end)

net.Receive(NET_SYNC, function()
    local target = net.ReadEntity()
    local name = net.ReadString()
    local count = net.ReadUInt(8)

    local entries = {}
    for _ = 1, count do
        entries[#entries + 1] = {
            id = net.ReadString(),
            tier = net.ReadUInt(4),
            at = net.ReadUInt(32),
            by = net.ReadString()
        }
    end

    -- Preserve the server's category ordering rather than re-sorting here.
    BuildFrame(name, entries)
end)

net.Receive(NET_OPEN, function()
    local target = net.ReadEntity()

    net.Start(NET_REQUEST)
        net.WriteEntity(target)
    net.SendToServer()
end)

concommand.Add("imperial_order_certs", function()
    net.Start(NET_REQUEST)
        net.WriteEntity(LocalPlayer())
    net.SendToServer()
end)

concommand.Add("imperial_order_certs_status", function()
    local ply = LocalPlayer()
    print("[Imperial Order] Overhead badges enabled: " .. tostring(showBadges:GetBool()))
    print("[Imperial Order] Your badge string: '" .. ply:GetNW2String(NW_BADGES, "") .. "'")
    print("[Imperial Order] Certifications held: " .. ply:GetNW2Int(NW_COUNT, 0))
    print("[Imperial Order] Registered definitions: " .. table.Count(CERT.List))
end)
