--[[
    Imperial Order - Certifications

    Shared definitions. Loaded on both realms so the client can render badges
    without asking the server what a certification means.

    Adding a certification:
        CERT.Register("eod", {
            name       = "Explosive Ordnance Disposal",
            abbr       = "EOD",          -- shown on the overhead badge
            category   = "combat",
            color      = Color(226, 169, 60),
            description = "Cleared to disarm and dispose of explosive devices.",
            overhead   = true,           -- false = earned but not shown above head
            tiers      = 3               -- 1 = binary, >1 = enables tier numerals
        })

    IDs are lowercase, no spaces. Never reuse an ID for a different meaning;
    characters store the ID, so recycling one silently rewrites earned history.
]]

IMPERIAL_ORDER_CERTS = IMPERIAL_ORDER_CERTS or {}
local CERT = IMPERIAL_ORDER_CERTS

CERT.List = {}
CERT.Order = {}

-- Max badges drawn above a player's head. Extras are held but not rendered,
-- highest priority first, so a veteran with twelve certs stays readable.
CERT.MaxOverhead = 4

-- Roman numerals for tiered certifications.
CERT.Numerals = {"I", "II", "III", "IV", "V"}

CERT.Categories = {
    combat    = {name = "Combat",     color = Color(174, 8, 15),    priority = 1},
    support   = {name = "Support",    color = Color(85, 184, 112),  priority = 2},
    vehicle   = {name = "Vehicle",    color = Color(70, 165, 214),  priority = 3},
    specialist= {name = "Specialist", color = Color(226, 169, 60),  priority = 4},
    command   = {name = "Command",    color = Color(198, 170, 96),  priority = 5}
}

function CERT.Register(id, data)
    id = string.lower(string.Trim(tostring(id or "")))
    if (id == "") then return end

    data = data or {}
    data.id = id
    data.name = tostring(data.name or id)
    data.abbr = string.upper(tostring(data.abbr or string.sub(id, 1, 3)))
    data.category = data.category or "specialist"
    data.description = tostring(data.description or "")
    data.tiers = math.Clamp(math.floor(tonumber(data.tiers) or 1), 1, #CERT.Numerals)
    data.priority = tonumber(data.priority) or 100

    if (data.overhead == nil) then data.overhead = true end

    if (not data.color) then
        local category = CERT.Categories[data.category]
        data.color = category and category.color or Color(134, 139, 145)
    end

    CERT.List[id] = data
    CERT.Order[#CERT.Order + 1] = id

    return data
end

function CERT.Get(id)
    if (not id) then return nil end
    return CERT.List[string.lower(string.Trim(tostring(id)))]
end

--- Returns definitions sorted by category priority, then own priority, then name.
function CERT.GetSorted()
    local out = {}
    for _, id in ipairs(CERT.Order) do
        local def = CERT.List[id]
        if (def) then out[#out + 1] = def end
    end

    table.sort(out, function(a, b)
        local ca = CERT.Categories[a.category] or {priority = 99}
        local cb = CERT.Categories[b.category] or {priority = 99}
        if (ca.priority ~= cb.priority) then return ca.priority < cb.priority end
        if (a.priority ~= b.priority) then return a.priority < b.priority end
        return a.name < b.name
    end)

    return out
end

--- "EOD" or "EOD II" depending on tier.
function CERT.FormatBadge(id, tier)
    local def = CERT.Get(id)
    if (not def) then return nil end

    tier = math.Clamp(math.floor(tonumber(tier) or 1), 1, def.tiers)
    if (def.tiers > 1 and tier > 1) then
        return def.abbr .. " " .. (CERT.Numerals[tier] or tostring(tier))
    end

    return def.abbr
end

function CERT.FormatName(id, tier)
    local def = CERT.Get(id)
    if (not def) then return tostring(id) end

    tier = math.Clamp(math.floor(tonumber(tier) or 1), 1, def.tiers)
    if (def.tiers > 1) then
        return def.name .. " " .. (CERT.Numerals[tier] or tostring(tier))
    end

    return def.name
end

--[[ ------------------------------------------------------------------------
    Default certifications. Edit freely - nothing below is load-bearing.
--------------------------------------------------------------------------- ]]

-- Combat
CERT.Register("marksman", {
    name = "Marksman", abbr = "MRK", category = "combat", tiers = 3, priority = 1,
    description = "Qualified on long-range precision weapons and observation duty."
})

CERT.Register("heavy", {
    name = "Heavy Weapons", abbr = "HW", category = "combat", tiers = 2, priority = 2,
    description = "Cleared to deploy squad support and anti-armour weaponry."
})

CERT.Register("eod", {
    name = "Explosive Ordnance Disposal", abbr = "EOD", category = "combat", tiers = 3, priority = 3,
    description = "Cleared to arm, disarm and dispose of explosive ordnance."
})

CERT.Register("cqc", {
    name = "Close Quarters Combat", abbr = "CQC", category = "combat", tiers = 2, priority = 4,
    description = "Certified in breaching and confined-space engagement doctrine."
})

-- Support
CERT.Register("medic", {
    name = "Field Medic", abbr = "MED", category = "support", tiers = 3, priority = 1,
    description = "Authorised to perform battlefield triage and casualty evacuation."
})

CERT.Register("engineer", {
    name = "Combat Engineer", abbr = "ENG", category = "support", tiers = 3, priority = 2,
    description = "Certified in fortification, repair and field construction."
})

CERT.Register("comms", {
    name = "Communications Technician", abbr = "COM", category = "support", tiers = 2, priority = 3,
    description = "Cleared to operate and maintain secure Imperial comms equipment."
})

CERT.Register("slicer", {
    name = "Systems Slicer", abbr = "SLC", category = "support", tiers = 2, priority = 4,
    description = "Authorised for electronic intrusion and counter-intrusion work."
})

-- Vehicle
CERT.Register("pilot", {
    name = "Flight Certified", abbr = "PLT", category = "vehicle", tiers = 3, priority = 1,
    description = "Rated to pilot Imperial atmospheric and void-capable craft."
})

CERT.Register("armor", {
    name = "Armour Operator", abbr = "ARM", category = "vehicle", tiers = 2, priority = 2,
    description = "Rated to crew and command Imperial ground armour."
})

-- Specialist
CERT.Register("interrogation", {
    name = "Interrogation Specialist", abbr = "INT", category = "specialist", tiers = 2, priority = 1,
    description = "Authorised to conduct sanctioned interrogation of detainees."
})

CERT.Register("riot", {
    name = "Riot Control", abbr = "RIOT", category = "specialist", tiers = 2, priority = 2,
    description = "Certified in crowd suppression and civil disorder response."
})

CERT.Register("recon", {
    name = "Reconnaissance", abbr = "RCN", category = "specialist", tiers = 2, priority = 3,
    description = "Trained in forward observation and long-duration scouting."
})

-- Command
CERT.Register("instructor", {
    name = "Certified Instructor", abbr = "INS", category = "command", tiers = 2, priority = 1,
    description = "Authorised to train and certify other Imperial personnel."
})

CERT.Register("command", {
    name = "Command Qualified", abbr = "CMD", category = "command", tiers = 3, priority = 2,
    description = "Cleared to assume field command of Imperial detachments."
})
