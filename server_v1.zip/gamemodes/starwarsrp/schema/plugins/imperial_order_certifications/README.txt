IMPERIAL ORDER - CERTIFICATIONS
===============================

Players earn certifications; the ones flagged for overhead display appear as
coloured badges on the nameplate above their head.


COMMANDS
--------
  F9                                  Toggle your certification record.

THEMED MENU: Imperial red/charcoal cards matching the assignments board,
IU.Colors support, wrapped text, search, and overhead badge display toggle.
Replace your existing imperial_order_certifications folder in the schema's
plugins directory, then restart the server. Do not install duplicate copies.
Server permissions, certification data, and overhead badge colors are unchanged.

  /CertGrant <player> <certID> [tier]   Award a certification.      (staff)
  /CertRevoke <player> <certID>         Strip a certification.      (staff)
  /Certs [player]                       Open the record. Own record is
                                        public; others are staff-only.
  /CertList                             Print every valid cert ID.

Examples:
  /CertGrant "TK-421" eod 2
  /CertGrant "Lt. Vane" pilot
  /CertRevoke "TK-421" eod

Console:
  imperial_order_certs            Open your own record.
  imperial_order_certs_status     Print badge string and definition count.
  imperial_order_certs_overhead   Client toggle, 0/1. Default 1.


SHIPPED CERTIFICATIONS
----------------------
  Combat      marksman (MRK, 3)   heavy (HW, 2)    eod (EOD, 3)   cqc (CQC, 2)
  Support     medic (MED, 3)      engineer (ENG, 3) comms (COM, 2) slicer (SLC, 2)
  Vehicle     pilot (PLT, 3)      armor (ARM, 2)
  Specialist  interrogation (INT, 2)  riot (RIOT, 2)  recon (RCN, 2)
  Command     instructor (INS, 2) command (CMD, 3)

The number is how many tiers that certification supports. Tier 1 shows as a
plain abbreviation; tier 2+ appends a Roman numeral, e.g. "EOD II".


ADDING YOUR OWN
---------------
Edit sh_config.lua:

    CERT.Register("sapper", {
        name        = "Sapper",
        abbr        = "SAP",          -- keep abbreviations UNIQUE, see below
        category    = "combat",       -- combat, support, vehicle, specialist, command
        tiers       = 2,              -- 1 = binary, up to 5
        priority    = 5,              -- ordering within the category
        overhead    = true,           -- false = earned but never shown above head
        description = "Certified in field demolition and obstacle breaching."
    })

Two rules:

  1. Abbreviations must be unique. The client resolves a badge's colour by
     matching the leading token back to a definition, so two certs sharing an
     abbreviation would make one adopt the other's colour.

  2. Never reuse an ID for a different meaning. Characters store the ID, so
     recycling one silently rewrites what people already earned. Retire the old
     ID instead and add a new one.

Deleting a certification is safe. Stored entries pointing at an ID that no
longer exists are dropped on read, not left as broken badges.


HOW IT'S STORED
---------------
On the character, so certifications follow the character rather than the
player, and don't leak between someone's alts:

    character:GetData("imperial_orderCertifications")
        -> { {id = "eod", tier = 2, at = 1717000000, by = "Moff Trelayne"} }

This is a normal Helix character data key. It persists through the usual save
path and needs no schema change or migration.

The overhead HUD must not run a net request per player per frame, so the
render-ready badge string is mirrored onto a networked var:

    ply:GetNW2String("imperial_orderCertBadges")   -> "EOD II|MED|PLT III"
    ply:GetNW2Int("imperial_orderCertCount")       -> 5

Only the badge text crosses the wire during normal play. The full record with
timestamps and awarding officer is sent only when someone opens the menu.

CERT.MaxOverhead (default 4) caps how many badges draw at once. Extras are kept
on the record but not rendered, so a veteran with twelve certifications still
has a readable nameplate. Which four show is deterministic: category priority,
then the cert's own priority.


OVERHEAD INTEGRATION
--------------------
This plugin does not draw the nameplate. It exposes:

    IMPERIAL_ORDER_GetOverheadCertifications(ply) -> { {text, color}, ... }

...which imperial_order_core/cl_overhead_ui.lua calls inside its existing
1.25s player-data cache. That file was modified in two places: the cache now
resolves badges, and DrawNameplate grows by 18px to fit the chip row and shifts
the health bar down.

The call is guarded with isfunction and pcall. Remove this plugin and the
nameplate silently returns to name + role with no errors.


HOOK
----
Fires server-side on every change, for logging or integration with the service
record system:

    hook.Add("ImperialOrderCertificationChanged", "MyLogger",
    function(client, character, certID, newTier, oldTier)
        -- newTier nil  = revoked
        -- oldTier nil  = newly granted
        -- both present = tier change
    end)
