--[[
    Imperial Order - Certifications (server)

    Storage lives on the character, not the player, so certifications follow the
    character across sessions and do not leak between a player's characters:

        character:GetData("imperial_orderCertifications")
            -> { {id = "eod", tier = 2, at = 1717000000, by = "Moff Trelayne"}, ... }

    The overhead HUD must not run a net request per player per frame, so the
    render-ready badge string is mirrored onto a networked var instead:

        ply:GetNW2String("imperial_orderCertBadges")   -> "EOD II|MED|PLT III"

    Anything the badge needs is in that one string. The full record is only sent
    on demand when someone opens the certifications menu.
]]

if (CLIENT) then return end

local CERT = IMPERIAL_ORDER_CERTS
if (not CERT) then return end

local NET_SYNC    = "IMPERIAL_ORDER.Certifications.Sync"
local NET_REQUEST = "IMPERIAL_ORDER.Certifications.Request"
local NET_OPEN    = "IMPERIAL_ORDER.Certifications.Open"

util.AddNetworkString(NET_SYNC)
util.AddNetworkString(NET_REQUEST)
util.AddNetworkString(NET_OPEN)

local DATA_KEY = "imperial_orderCertifications"
local NW_BADGES = "imperial_orderCertBadges"
local NW_COUNT  = "imperial_orderCertCount"

local requestCooldown = {}

local function notify(client, message, kind)
    if (not IsValid(client)) then return end

    if (isfunction(IMPERIAL_ORDER_Notify)) then
        local color = kind == "success" and Color(85, 184, 112)
            or kind == "warning" and Color(226, 169, 60)
            or Color(215, 42, 42)
        IMPERIAL_ORDER_Notify(client, message, color, 5)
    elseif (isfunction(client.Notify)) then
        client:Notify(message)
    else
        client:ChatPrint("[Imperial Order] " .. message)
    end
end

local function canAdmin(client)
    if (not IsValid(client) or not client:IsPlayer()) then return false end

    if (isfunction(IMPERIAL_ORDER_CanAccessAdminUI)) then
        local ok, allowed = pcall(IMPERIAL_ORDER_CanAccessAdminUI, client)
        if (ok) then return allowed == true end
    end

    return client:IsSuperAdmin() or client:IsAdmin()
end

local function getCharacter(client)
    if (not IsValid(client) or not isfunction(client.GetCharacter)) then return nil end

    local ok, character = pcall(client.GetCharacter, client)
    if (ok and character and isfunction(character.GetData)) then return character end

    return nil
end

--- Drops malformed entries and unknown IDs rather than trusting stored data.
-- Old saves, hand-edited databases and removed certifications all land here.
local function sanitize(raw)
    local out, seen = {}, {}
    if (not istable(raw)) then return out end

    for _, entry in ipairs(raw) do
        if (istable(entry)) then
            local id = string.lower(string.Trim(tostring(entry.id or "")))
            local def = CERT.Get(id)

            if (def and not seen[id]) then
                seen[id] = true
                out[#out + 1] = {
                    id = id,
                    tier = math.Clamp(math.floor(tonumber(entry.tier) or 1), 1, def.tiers),
                    at = math.max(0, math.floor(tonumber(entry.at) or 0)),
                    by = string.sub(tostring(entry.by or "System"), 1, 64)
                }
            end
        end
    end

    return out
end

function CERT.GetCharacterCertifications(character)
    if (not character or not isfunction(character.GetData)) then return {} end
    return sanitize(character:GetData(DATA_KEY, {}))
end

--- Rebuilds the networked badge string. Called after every change and on spawn.
function CERT.SyncPlayer(client)
    if (not IsValid(client)) then return end

    local character = getCharacter(client)
    if (not character) then
        client:SetNW2String(NW_BADGES, "")
        client:SetNW2Int(NW_COUNT, 0)
        return
    end

    local list = CERT.GetCharacterCertifications(character)

    -- Only overhead-flagged certifications compete for badge space, ordered by
    -- category then priority so the same cert always sits in the same slot.
    local visible = {}
    for _, entry in ipairs(list) do
        local def = CERT.Get(entry.id)
        if (def and def.overhead) then
            visible[#visible + 1] = {entry = entry, def = def}
        end
    end

    table.sort(visible, function(a, b)
        local ca = CERT.Categories[a.def.category] or {priority = 99}
        local cb = CERT.Categories[b.def.category] or {priority = 99}
        if (ca.priority ~= cb.priority) then return ca.priority < cb.priority end
        if (a.def.priority ~= b.def.priority) then return a.def.priority < b.def.priority end
        return a.def.name < b.def.name
    end)

    local badges = {}
    for index = 1, math.min(#visible, CERT.MaxOverhead) do
        local item = visible[index]
        badges[#badges + 1] = CERT.FormatBadge(item.entry.id, item.entry.tier) or item.def.abbr
    end

    client:SetNW2String(NW_BADGES, table.concat(badges, "|"))
    client:SetNW2Int(NW_COUNT, #list)
end

--- Grants a certification, or upgrades its tier if already held.
-- Returns success, message.
function CERT.Grant(client, id, tier, awardedBy)
    local def = CERT.Get(id)
    if (not def) then return false, "Unknown certification." end

    local character = getCharacter(client)
    if (not character or not isfunction(character.SetData)) then
        return false, "Target has no active character."
    end

    tier = math.Clamp(math.floor(tonumber(tier) or 1), 1, def.tiers)

    local list = CERT.GetCharacterCertifications(character)
    for _, entry in ipairs(list) do
        if (entry.id == def.id) then
            if (entry.tier == tier) then
                return false, character:GetName() .. " already holds " .. CERT.FormatName(def.id, tier) .. "."
            end

            local previous = entry.tier
            entry.tier = tier
            entry.at = os.time()
            entry.by = tostring(awardedBy or "System")
            character:SetData(DATA_KEY, list)
            CERT.SyncPlayer(client)

            hook.Run("ImperialOrderCertificationChanged", client, character, def.id, tier, previous)

            return true, string.format("%s: %s -> %s.", character:GetName(),
                CERT.FormatName(def.id, previous), CERT.FormatName(def.id, tier))
        end
    end

    list[#list + 1] = {
        id = def.id,
        tier = tier,
        at = os.time(),
        by = tostring(awardedBy or "System")
    }

    character:SetData(DATA_KEY, list)
    CERT.SyncPlayer(client)

    hook.Run("ImperialOrderCertificationChanged", client, character, def.id, tier, nil)

    return true, character:GetName() .. " awarded " .. CERT.FormatName(def.id, tier) .. "."
end

function CERT.Revoke(client, id)
    local def = CERT.Get(id)
    if (not def) then return false, "Unknown certification." end

    local character = getCharacter(client)
    if (not character or not isfunction(character.SetData)) then
        return false, "Target has no active character."
    end

    local list = CERT.GetCharacterCertifications(character)
    for index, entry in ipairs(list) do
        if (entry.id == def.id) then
            table.remove(list, index)
            character:SetData(DATA_KEY, list)
            CERT.SyncPlayer(client)

            hook.Run("ImperialOrderCertificationChanged", client, character, def.id, nil, entry.tier)

            return true, character:GetName() .. " stripped of " .. def.name .. "."
        end
    end

    return false, character:GetName() .. " does not hold " .. def.name .. "."
end

--[[ ------------------------------------------------------------------------
    Networking
--------------------------------------------------------------------------- ]]

local function sendProfile(client, target)
    local character = getCharacter(target)
    if (not character) then return end

    local list = CERT.GetCharacterCertifications(character)

    net.Start(NET_SYNC)
        net.WriteEntity(target)
        net.WriteString(character:GetName() or "Unknown")
        net.WriteUInt(#list, 8)

        for _, entry in ipairs(list) do
            net.WriteString(entry.id)
            net.WriteUInt(entry.tier, 4)
            net.WriteUInt(entry.at, 32)
            net.WriteString(entry.by)
        end
    net.Send(client)
end

net.Receive(NET_REQUEST, function(_, client)
    if (not IsValid(client)) then return end

    local now = CurTime()
    if ((requestCooldown[client] or 0) > now) then return end
    requestCooldown[client] = now + 0.5

    local target = net.ReadEntity()
    if (not IsValid(target) or not target:IsPlayer()) then target = client end

    -- Anyone may inspect their own record; inspecting others is staff-only,
    -- otherwise the menu becomes a roster scraper for the whole server.
    if (target ~= client and not canAdmin(client)) then return end

    sendProfile(client, target)
end)

hook.Add("PlayerDisconnected", "IMPERIAL_ORDER.Certifications.Cleanup", function(client)
    requestCooldown[client] = nil
end)

--[[ ------------------------------------------------------------------------
    Sync triggers
--------------------------------------------------------------------------- ]]

hook.Add("PlayerLoadedCharacter", "IMPERIAL_ORDER.Certifications.Loaded", function(client)
    timer.Simple(0.5, function()
        if (IsValid(client)) then CERT.SyncPlayer(client) end
    end)
end)

hook.Add("PlayerSpawn", "IMPERIAL_ORDER.Certifications.Spawn", function(client)
    timer.Simple(0.5, function()
        if (IsValid(client)) then CERT.SyncPlayer(client) end
    end)
end)

--[[ ------------------------------------------------------------------------
    Commands
--------------------------------------------------------------------------- ]]

ix.command.Add("CertGrant", {
    description = "Award a certification to a player. Tier is optional.",
    adminOnly = true,
    arguments = {
        ix.type.player,
        ix.type.string,
        bit.bor(ix.type.number, ix.type.optional)
    },
    OnRun = function(self, client, target, id, tier)
        if (not canAdmin(client)) then
            return "You are not cleared to award certifications."
        end

        local success, message = CERT.Grant(target, id, tier or 1, client:GetName())

        if (success) then
            notify(target, "Certification awarded: " .. CERT.FormatName(id, tier or 1), "success")
            return message
        end

        return message
    end
})

ix.command.Add("CertRevoke", {
    description = "Strip a certification from a player.",
    adminOnly = true,
    arguments = {
        ix.type.player,
        ix.type.string
    },
    OnRun = function(self, client, target, id)
        if (not canAdmin(client)) then
            return "You are not cleared to revoke certifications."
        end

        local success, message = CERT.Revoke(target, id)

        if (success) then
            local def = CERT.Get(id)
            notify(target, "Certification revoked: " .. (def and def.name or id), "warning")
        end

        return message
    end
})

ix.command.Add("Certs", {
    description = "View your certifications, or another player's if you are staff.",
    arguments = {
        bit.bor(ix.type.player, ix.type.optional)
    },
    OnRun = function(self, client, target)
        target = IsValid(target) and target or client

        if (target ~= client and not canAdmin(client)) then
            return "You are not cleared to inspect other personnel."
        end

        net.Start(NET_OPEN)
            net.WriteEntity(target)
        net.Send(client)
    end
})

ix.command.Add("CertList", {
    description = "List every certification ID available on this server.",
    OnRun = function(self, client)
        local lines = {}

        for _, def in ipairs(CERT.GetSorted()) do
            local category = CERT.Categories[def.category]
            lines[#lines + 1] = string.format("%s  (%s)  %s%s",
                def.id,
                def.abbr,
                category and category.name or def.category,
                def.tiers > 1 and (", tiers 1-" .. def.tiers) or "")
        end

        client:ChatPrint("[Imperial Order] Available certifications:")
        for _, line in ipairs(lines) do client:ChatPrint("  " .. line) end
    end
})
