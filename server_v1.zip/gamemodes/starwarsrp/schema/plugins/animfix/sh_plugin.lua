local PLUGIN = PLUGIN

PLUGIN.name = "Imperial Order Universal Playermodel Animation Repair"
PLUGIN.description = "Detects a compatible Helix animation class for every playermodel at runtime, with a generated sequence fallback for models that do not match a built-in class."
PLUGIN.author = "Imperial Order"

IMPERIAL_ORDER = IMPERIAL_ORDER or {}
IMPERIAL_ORDER_LOADED = IMPERIAL_ORDER_LOADED or {}
IMPERIAL_ORDER_LOADED.animfix_v262 = true

local BUILTIN_CLASSES = {
    "player",
    "citizen_male",
    "citizen_female",
    "metrocop",
    "overwatch",
    "vortigaunt",
    "zombie",
    "fastZombie"
}

local HOLDTYPE_TRANSLATOR = {
    [""] = "normal",
    physgun = "smg",
    ar2 = "smg",
    crossbow = "shotgun",
    rpg = "shotgun",
    slam = "normal",
    grenade = "grenade",
    fist = "normal",
    melee2 = "melee",
    passive = "normal",
    knife = "melee",
    duel = "pistol",
    camera = "smg",
    magic = "normal",
    revolver = "pistol"
}

local MOVEMENT_ACTIVITIES = {
    {name = "idle", activity = ACT_MP_STAND_IDLE, weight = 5},
    {name = "walk", activity = ACT_MP_WALK, weight = 5},
    {name = "run", activity = ACT_MP_RUN, weight = 5},
    {name = "crouchIdle", activity = ACT_MP_CROUCH_IDLE, weight = 3},
    {name = "crouchWalk", activity = ACT_MP_CROUCHWALK, weight = 3}
}

local RESOLUTION_CACHE = {}
local OVERRIDES = IMPERIAL_ORDER.AnimationClassOverridesV262 or {}
IMPERIAL_ORDER.AnimationClassOverridesV262 = OVERRIDES

local function NormalizeModel(model)
    return string.lower(string.Trim(tostring(model or "")))
end

local function IsBadSequenceName(name)
    name = string.lower(tostring(name or ""))

    return name == ""
        or string.find(name, "reference", 1, true) ~= nil
        or string.find(name, "ragdoll", 1, true) ~= nil
        or string.find(name, "death", 1, true) ~= nil
        or string.find(name, "die", 1, true) ~= nil
        or string.find(name, "flinch", 1, true) ~= nil
end

local function SequenceInfo(client, value)
    if not IsValid(client) then
        return false, -1, ""
    end

    local sequence = -1

    if isstring(value) then
        sequence = client:LookupSequence(value)
    elseif isnumber(value) then
        sequence = client:SelectWeightedSequence(value)
    end

    if not isnumber(sequence) or sequence <= 0 then
        return false, sequence or -1, ""
    end

    local name = isfunction(client.GetSequenceName) and client:GetSequenceName(sequence) or ""
    if IsBadSequenceName(name) then
        return false, sequence, tostring(name or "")
    end

    return true, sequence, tostring(name or "")
end

local function ScoreMapping(client, mapping, weight)
    if istable(mapping) then
        local lowered = SequenceInfo(client, mapping[1])
        local raised = SequenceInfo(client, mapping[2])

        if lowered and raised then
            return weight
        elseif lowered or raised then
            return weight * 0.55
        end

        return 0
    end

    local valid = SequenceInfo(client, mapping)
    return valid and weight or 0
end

local function ScorePlayerClass(client)
    local score = 0

    local activityTests = {
        {ACT_HL2MP_IDLE, 5},
        {ACT_HL2MP_WALK, 5},
        {ACT_HL2MP_RUN, 5},
        {ACT_HL2MP_IDLE_CROUCH, 3},
        {ACT_HL2MP_WALK_CROUCH, 3},
        {ACT_HL2MP_IDLE_PISTOL, 1},
        {ACT_HL2MP_WALK_PISTOL, 1},
        {ACT_HL2MP_IDLE_SMG1, 1},
        {ACT_HL2MP_WALK_SMG1, 1},
        {ACT_HL2MP_IDLE_AR2, 1},
        {ACT_HL2MP_WALK_AR2, 1}
    }

    for _, test in ipairs(activityTests) do
        if isnumber(test[1]) then
            local valid = SequenceInfo(client, test[1])
            if valid then
                score = score + test[2]
            end
        end
    end

    return score
end

local function ScoreTranslatedClass(client, className)
    if not ix or not ix.anim then
        return -1
    end

    local classTable = ix.anim[className]
    if not istable(classTable) then
        return -1
    end

    -- Zombie-style classes are a direct activity table rather than a
    -- hold-type table.
    if not istable(classTable.normal) then
        local score = 0

        for _, test in ipairs(MOVEMENT_ACTIVITIES) do
            score = score + ScoreMapping(client, classTable[test.activity], test.weight)
        end

        return score
    end

    local score = 0
    local holdTypes = {
        {name = "normal", multiplier = 1.0},
        {name = "pistol", multiplier = 0.25},
        {name = "smg", multiplier = 0.25},
        {name = "shotgun", multiplier = 0.2},
        {name = "melee", multiplier = 0.15},
        {name = "grenade", multiplier = 0.1}
    }

    for _, holdData in ipairs(holdTypes) do
        local animationTable = classTable[holdData.name]

        if istable(animationTable) then
            for _, test in ipairs(MOVEMENT_ACTIVITIES) do
                score = score + ScoreMapping(
                    client,
                    animationTable[test.activity],
                    test.weight * holdData.multiplier
                )
            end
        end
    end

    return score
end

local function PathPreference(model, className)
    local bonus = 0

    if className == "player" and string.find(model, "/player/", 1, true) then
        bonus = bonus + 2
    end

    if className == "citizen_female" and (
        string.find(model, "female", 1, true)
        or string.find(model, "alyx", 1, true)
        or string.find(model, "mossman", 1, true)
        or string.find(model, "sister", 1, true)
    ) then
        bonus = bonus + 2
    end

    if className == "metrocop" and (
        string.find(model, "police", 1, true)
        or string.find(model, "metrocop", 1, true)
        or string.find(model, "civil_protection", 1, true)
    ) then
        bonus = bonus + 2
    end

    if className == "overwatch" and (
        string.find(model, "combine", 1, true)
        or string.find(model, "overwatch", 1, true)
        or string.find(model, "trooper", 1, true)
        or string.find(model, "commando", 1, true)
        or string.find(model, "soldier", 1, true)
    ) then
        bonus = bonus + 1.5
    end

    if className == "vortigaunt" and string.find(model, "vort", 1, true) then
        bonus = bonus + 5
    end

    if className == "zombie" and string.find(model, "zombie", 1, true) then
        bonus = bonus + 5
    end

    if className == "fastZombie" and (
        string.find(model, "fastzombie", 1, true)
        or string.find(model, "fast_zombie", 1, true)
    ) then
        bonus = bonus + 7
    end

    return bonus
end

local function GetSequenceLookup(client)
    local lookup = {}
    local ordered = {}

    if not IsValid(client) or not isfunction(client.GetSequenceList) then
        return lookup, ordered
    end

    for _, name in ipairs(client:GetSequenceList() or {}) do
        local lowered = string.lower(tostring(name or ""))

        if lowered ~= "" and not IsBadSequenceName(lowered) then
            lookup[lowered] = tostring(name)
            ordered[#ordered + 1] = {
                lower = lowered,
                actual = tostring(name)
            }
        end
    end

    return lookup, ordered
end

local function FindSequence(lookup, ordered, exactNames, requiredWords, forbiddenWords)
    for _, name in ipairs(exactNames or {}) do
        local match = lookup[string.lower(name)]
        if match then
            return match
        end
    end

    local bestName
    local bestScore = -math.huge

    for _, entry in ipairs(ordered) do
        local name = entry.lower
        local rejected = false

        for _, word in ipairs(forbiddenWords or {}) do
            if string.find(name, word, 1, true) then
                rejected = true
                break
            end
        end

        if not rejected then
            local score = 0
            local matchedRequired = true

            for _, word in ipairs(requiredWords or {}) do
                if string.find(name, word, 1, true) then
                    score = score + 5
                else
                    matchedRequired = false
                    break
                end
            end

            if matchedRequired then
                if string.find(name, "all", 1, true) then score = score + 2 end
                if string.find(name, "unarmed", 1, true) then score = score + 2 end
                if string.find(name, "rifle", 1, true) then score = score + 1 end
                if string.find(name, "loop", 1, true) then score = score + 1 end

                if score > bestScore then
                    bestScore = score
                    bestName = entry.actual
                end
            end
        end
    end

    return bestName
end

local function BuildGeneratedClass(client, model)
    if not ix or not ix.anim then
        return nil, 0
    end

    local lookup, ordered = GetSequenceLookup(client)
    if #ordered == 0 then
        return nil, 0
    end

    local movementForbidden = {
        "attack", "reload", "gesture", "shoot", "fire", "draw", "holster",
        "death", "die", "flinch", "ragdoll", "reference", "turn", "swim"
    }

    local idle = FindSequence(lookup, ordered, {
        "idle_all_01", "idle_all", "idle_unarmed", "idle", "idle01",
        "stand_idle", "idle_subtle", "idle_relaxed"
    }, {"idle"}, movementForbidden)

    local raisedIdle = FindSequence(lookup, ordered, {
        "idle_ar2", "idle_smg1", "idle_rifle", "idle_aiming", "idle_angry",
        "idle_all_01", "idle_unarmed"
    }, {"idle"}, movementForbidden) or idle

    local walk = FindSequence(lookup, ordered, {
        "walk_all", "walkunarmed_all", "walk_unarmed", "walk", "walk_all_moderate"
    }, {"walk"}, movementForbidden)

    local raisedWalk = FindSequence(lookup, ordered, {
        "walk_ar2", "walk_rifle", "walk_aiming", "walk_all", "walkunarmed_all"
    }, {"walk"}, movementForbidden) or walk

    local run = FindSequence(lookup, ordered, {
        "run_all", "run_unarmed", "run", "run_all_01"
    }, {"run"}, movementForbidden)

    local raisedRun = FindSequence(lookup, ordered, {
        "run_ar2", "run_rifle", "run_aiming", "run_all", "run_unarmed"
    }, {"run"}, movementForbidden) or run

    local crouchIdle = FindSequence(lookup, ordered, {
        "cidle_all", "crouch_idle", "crouchidle", "idle_crouch", "crouch_idle_all"
    }, {"crouch", "idle"}, movementForbidden)

    local crouchWalk = FindSequence(lookup, ordered, {
        "cwalk_all", "crouch_walk", "crouchwalk", "walk_crouch", "crouch_walk_all"
    }, {"crouch", "walk"}, movementForbidden)

    local glide = FindSequence(lookup, ordered, {
        "jump_holding_glide", "jump_glide", "jump", "fall", "airwalk"
    }, {"jump"}, {"attack", "death", "flinch", "gesture"})

    idle = idle or raisedIdle
    walk = walk or raisedWalk or idle
    run = run or raisedRun or walk
    crouchIdle = crouchIdle or idle
    crouchWalk = crouchWalk or walk
    raisedIdle = raisedIdle or idle
    raisedWalk = raisedWalk or walk
    raisedRun = raisedRun or run

    if not idle or not walk or not run then
        return nil, 0
    end

    local normal = {
        [ACT_MP_STAND_IDLE] = {idle, raisedIdle},
        [ACT_MP_CROUCH_IDLE] = {crouchIdle, crouchIdle},
        [ACT_MP_WALK] = {walk, raisedWalk},
        [ACT_MP_CROUCHWALK] = {crouchWalk, crouchWalk},
        [ACT_MP_RUN] = {run, raisedRun},
        [ACT_LAND] = {ACT_RESET, ACT_RESET},
        attack = ACT_GESTURE_RANGE_ATTACK_SMG1,
        reload = ACT_GESTURE_RELOAD_SMG1
    }

    local className = "imperial_order_auto_" .. string.lower(util.CRC(model))

    ix.anim[className] = {
        normal = normal,
        pistol = normal,
        smg = normal,
        shotgun = normal,
        grenade = normal,
        melee = normal,
        glide = glide or ACT_GLIDE
    }

    return className, 12
end

local function ResolveBestClass(client, model, force)
    model = NormalizeModel(model)

    local override = OVERRIDES[model]
    if override and ix and ix.anim and ix.anim[override] then
        return override, math.huge, "manual-override", {}
    end

    if not force then
        local cached = RESOLUTION_CACHE[model]
        if cached and ix and ix.anim and ix.anim[cached.class] then
            return cached.class, cached.score, cached.source, cached.scores or {}
        end
    end

    local scores = {}
    local bestClass
    local bestScore = -math.huge
    local existingClass = ix and ix.anim and isfunction(ix.anim.GetModelClass)
        and ix.anim.GetModelClass(model)
        or nil

    for _, className in ipairs(BUILTIN_CLASSES) do
        if ix and ix.anim and ix.anim[className] then
            local rawScore = className == "player"
                and ScorePlayerClass(client)
                or ScoreTranslatedClass(client, className)

            local score = rawScore + PathPreference(model, className)

            if className == existingClass then
                score = score + 0.5
            end

            scores[className] = score

            if score > bestScore then
                bestClass = className
                bestScore = score
            end
        end
    end

    local source = "built-in"

    -- A weak built-in result usually means the model uses custom sequence
    -- names. Generate a model-specific translation table from those names.
    if not bestClass or bestScore < 11 then
        local generatedClass, generatedScore = BuildGeneratedClass(client, model)

        if generatedClass then
            bestClass = generatedClass
            bestScore = math.max(bestScore, generatedScore)
            source = "generated-sequences"
            scores[generatedClass] = generatedScore
        end
    end

    if not bestClass then
        bestClass = existingClass or "player"
        bestScore = -1
        source = "safe-fallback"
    end

    RESOLUTION_CACHE[model] = {
        class = bestClass,
        score = bestScore,
        source = source,
        scores = scores
    }

    return bestClass, bestScore, source, scores
end

local function GetHoldType(client)
    local weapon = IsValid(client) and client:GetActiveWeapon() or nil
    local holdType = "normal"

    if IsValid(weapon) then
        holdType = weapon.HoldType or (isfunction(weapon.GetHoldType) and weapon:GetHoldType()) or "normal"
    end

    return HOLDTYPE_TRANSLATOR[tostring(holdType or "")] or tostring(holdType or "normal")
end

local function RefreshAnimationCache(client, reason, force)
    if not IsValid(client) or not client:IsPlayer() then
        return false
    end

    if not ix or not ix.anim or not isfunction(ix.anim.SetModelClass) then
        return false
    end

    local model = NormalizeModel(client:GetModel())
    if model == "" then
        return false
    end

    local resolvedClass, score, source, scores = ResolveBestClass(client, model, force)
    if not resolvedClass or not ix.anim[resolvedClass] then
        return false
    end

    ix.anim.SetModelClass(model, resolvedClass)

    client.ixAnimModelClass = resolvedClass
    client.ixAnimHoldType = GetHoldType(client)

    local baseTable = ix.anim[resolvedClass] or {}

    if resolvedClass == "player" then
        client.ixAnimTable = nil
        client.ixAnimGlide = nil
    elseif istable(baseTable.normal) then
        client.ixAnimTable = baseTable[client.ixAnimHoldType] or baseTable.normal
        client.ixAnimGlide = baseTable.glide
    else
        client.ixAnimTable = baseTable
        client.ixAnimGlide = baseTable.glide
    end

    client.CalcSeqOverride = -1
    client.imperial_orderAnimClassV262 = resolvedClass
    client.imperial_orderAnimClassScoreV262 = score
    client.imperial_orderAnimClassSourceV262 = source
    client.imperial_orderAnimClassScoresV262 = scores
    client.imperial_orderAnimRefreshReasonV262 = tostring(reason or "unknown")
    client.imperial_orderAnimModelV262 = model

    local activeWeapon = client:GetActiveWeapon()
    client.imperial_orderAnimWeaponV262 = IsValid(activeWeapon) and activeWeapon:GetClass() or ""

    if isfunction(client.AnimRestartMainSequence) then
        client:AnimRestartMainSequence()
    end

    return true
end

local function RefreshAll(reason, force)
    for _, client in ipairs(player.GetAll()) do
        RefreshAnimationCache(client, reason, force)
    end
end

function IMPERIAL_ORDER.RegisterUniversalAnimationOverrideV262(model, className)
    model = NormalizeModel(model)

    if model == "" then
        return false, "invalid model"
    end

    if not ix or not ix.anim or not ix.anim[className] then
        return false, "invalid animation class"
    end

    OVERRIDES[model] = className
    RESOLUTION_CACHE[model] = nil

    for _, client in ipairs(player.GetAll()) do
        if NormalizeModel(client:GetModel()) == model then
            RefreshAnimationCache(client, "manual-override", true)
        end
    end

    return true
end

IMPERIAL_ORDER.RefreshUniversalAnimationV262 = RefreshAnimationCache
IMPERIAL_ORDER.RefreshAllUniversalAnimationsV262 = RefreshAll
IMPERIAL_ORDER.UniversalAnimationResolutionCacheV262 = RESOLUTION_CACHE

-- Remove previous targeted animation owners when updating without a clean Lua
-- state. A complete restart is still required after replacing the schema.
for _, timerName in ipairs({
    "IMPERIAL_ORDER.AnimFixV153.Startup",
    "IMPERIAL_ORDER.AnimFixV153.LateStartup",
    "IMPERIAL_ORDER.AnimFixV260.Register",
    "IMPERIAL_ORDER.AnimFixV261.Register",
    "IMPERIAL_ORDER.AnimFixV262.Register"
}) do
    timer.Remove(timerName)
end

for _, data in ipairs({
    {"InitializedPlugins", "IMPERIAL_ORDER.AnimFixV153.InitializedPlugins"},
    {"InitPostEntity", "IMPERIAL_ORDER.AnimFixV153.InitPostEntity"},
    {"OnReloaded", "IMPERIAL_ORDER.AnimFixV153.Reloaded"},
    {"InitializedPlugins", "IMPERIAL_ORDER.AnimFixV260.InitializedPlugins"},
    {"InitPostEntity", "IMPERIAL_ORDER.AnimFixV260.InitPostEntity"},
    {"OnReloaded", "IMPERIAL_ORDER.AnimFixV260.Reloaded"},
    {"PlayerModelChanged", "IMPERIAL_ORDER.AnimFixV260.PlayerModelChanged"},
    {"InitializedPlugins", "IMPERIAL_ORDER.AnimFixV261.InitializedPlugins"},
    {"InitPostEntity", "IMPERIAL_ORDER.AnimFixV261.InitPostEntity"},
    {"OnReloaded", "IMPERIAL_ORDER.AnimFixV261.Reloaded"},
    {"PlayerModelChanged", "IMPERIAL_ORDER.AnimFixV261.PlayerModelChanged"},
    {"PlayerWeaponChanged", "IMPERIAL_ORDER.AnimFixV261.PlayerWeaponChanged"}
}) do
    hook.Remove(data[1], data[2])
end

hook.Add("InitializedPlugins", "IMPERIAL_ORDER.AnimFixV262.InitializedPlugins", function()
    timer.Simple(0, function()
        RefreshAll("InitializedPlugins", true)
    end)
end)

hook.Add("InitPostEntity", "IMPERIAL_ORDER.AnimFixV262.InitPostEntity", function()
    timer.Simple(0, function()
        RefreshAll("InitPostEntity", true)
    end)
end)

hook.Add("OnReloaded", "IMPERIAL_ORDER.AnimFixV262.Reloaded", function()
    RESOLUTION_CACHE = {}
    IMPERIAL_ORDER.UniversalAnimationResolutionCacheV262 = RESOLUTION_CACHE

    timer.Simple(0, function()
        RefreshAll("OnReloaded", true)
    end)
end)

hook.Add("PlayerModelChanged", "IMPERIAL_ORDER.AnimFixV262.PlayerModelChanged", function(client)
    timer.Simple(0, function()
        if IsValid(client) then
            RefreshAnimationCache(client, "PlayerModelChanged", true)
        end
    end)
end)

hook.Add("PlayerWeaponChanged", "IMPERIAL_ORDER.AnimFixV262.PlayerWeaponChanged", function(client)
    timer.Simple(0, function()
        if IsValid(client) then
            RefreshAnimationCache(client, "PlayerWeaponChanged", false)
        end
    end)
end)

function PLUGIN:PlayerLoadedCharacter(client)
    for _, delay in ipairs({0, 0.25, 1}) do
        timer.Simple(delay, function()
            if IsValid(client) then
                RefreshAnimationCache(client, "PlayerLoadedCharacter", delay == 0)
            end
        end)
    end
end

function PLUGIN:PlayerSpawn(client)
    for _, delay in ipairs({0, 0.25, 1}) do
        timer.Simple(delay, function()
            if IsValid(client) then
                RefreshAnimationCache(client, "PlayerSpawn", delay == 0)
            end
        end)
    end
end


if CLIENT then
    local nextAudit = 0

    hook.Add("OnEntityCreated", "IMPERIAL_ORDER.AnimFixV262.PlayerCreated", function(entity)
        if not IsValid(entity) or not entity:IsPlayer() then return end

        timer.Simple(0.5, function()
            if IsValid(entity) then
                RefreshAnimationCache(entity, "OnEntityCreated", true)
            end
        end)
    end)

    hook.Add("NotifyShouldTransmit", "IMPERIAL_ORDER.AnimFixV262.NotifyShouldTransmit", function(entity, shouldTransmit)
        if not shouldTransmit or not IsValid(entity) or not entity:IsPlayer() then return end

        timer.Simple(0, function()
            if IsValid(entity) then
                RefreshAnimationCache(entity, "NotifyShouldTransmit", false)
            end
        end)
    end)

    -- This is a change detector, not an animation watchdog. It performs no
    -- work unless a player's model or active weapon changed without emitting
    -- the expected Garry's Mod/Helix hook on this client.
    hook.Add("Think", "IMPERIAL_ORDER.AnimFixV262.ClientChangeDetector", function()
        if RealTime() < nextAudit then return end
        nextAudit = RealTime() + 0.75

        for _, client in ipairs(player.GetAll()) do
            local model = NormalizeModel(client:GetModel())
            local weapon = client:GetActiveWeapon()
            local weaponClass = IsValid(weapon) and weapon:GetClass() or ""

            if client.imperial_orderAnimModelV262 ~= model
                or client.imperial_orderAnimWeaponV262 ~= weaponClass
                or not client.ixAnimModelClass then
                RefreshAnimationCache(client, "client-change-detected", client.imperial_orderAnimModelV262 ~= model)
            end
        end
    end)
end

local function PrintStatus(client)
    if not IsValid(client) or not client:IsPlayer() then
        print("[Imperial Order V262 Animations] Run this command as a connected player.")
        return
    end

    RefreshAnimationCache(client, "status-command", true)

    local model = NormalizeModel(client:GetModel())
    local registered = ix and ix.anim and isfunction(ix.anim.GetModelClass)
        and ix.anim.GetModelClass(model)
        or "unknown"
    local cached = client.ixAnimModelClass or "none"
    local weapon = client:GetActiveWeapon()
    local weaponClass = IsValid(weapon) and weapon:GetClass() or "none"
    local holdType = IsValid(weapon) and isfunction(weapon.GetHoldType)
        and weapon:GetHoldType()
        or "none"

    local scoreParts = {}
    for className, score in pairs(client.imperial_orderAnimClassScoresV262 or {}) do
        scoreParts[#scoreParts + 1] = className .. "=" .. string.format("%.2f", score)
    end
    table.sort(scoreParts)

    local line = string.format(
        "[Imperial Order V262 Animations] model=%s | registered=%s | cached=%s | source=%s | score=%s | weapon=%s | holdtype=%s | reason=%s | candidates={%s}",
        model,
        tostring(registered),
        tostring(cached),
        tostring(client.imperial_orderAnimClassSourceV262 or "none"),
        tostring(client.imperial_orderAnimClassScoreV262 or "n/a"),
        tostring(weaponClass),
        tostring(holdType),
        tostring(client.imperial_orderAnimRefreshReasonV262 or "none"),
        table.concat(scoreParts, ", ")
    )

    client:PrintMessage(HUD_PRINTCONSOLE, line)
end

if SERVER then
    for _, commandName in ipairs({
        "imperial_order_animation_status_v254",
        "imperial_order_animation_status_v260",
        "imperial_order_animation_status_v261",
        "imperial_order_animation_status_v262",
        "imperial_order_animfix_reload"
    }) do
        concommand.Remove(commandName)
    end

    concommand.Add("imperial_order_animfix_reload", function(client)
        RESOLUTION_CACHE = {}
        IMPERIAL_ORDER.UniversalAnimationResolutionCacheV262 = RESOLUTION_CACHE
        RefreshAll("manual-reload", true)

        if IsValid(client) and client.Notify then
            client:Notify("Universal playermodel animation cache refreshed.")
        else
            print("[Imperial Order V262 Animations] Universal animation cache refreshed.")
        end
    end)

    concommand.Add("imperial_order_animation_status_v254", PrintStatus)
    concommand.Add("imperial_order_animation_status_v260", PrintStatus)
    concommand.Add("imperial_order_animation_status_v261", PrintStatus)
    concommand.Add("imperial_order_animation_status_v262", PrintStatus)
end
