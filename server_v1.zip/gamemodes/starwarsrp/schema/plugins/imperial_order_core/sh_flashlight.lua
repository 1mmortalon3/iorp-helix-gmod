-- Imperial Order v225
-- Restores Garry's Mod's built-in flashlight for every loaded character.

if SERVER then
    AddCSLuaFile()
end

local HOOK_PREFIX = "IMPERIAL_ORDER.V239.FlashlightRestore"
local ACTIVE_PLUGIN = PLUGIN

local function EnableFlashlightPermission(client)
    if not IsValid(client) or not client:IsPlayer() then
        return
    end

    -- AllowFlashlight is realm-local, so this file applies it on both the
    -- server and the owning client. The engine still handles impulse 100.
    if client.AllowFlashlight then
        client:AllowFlashlight(true)
    end
end

if SERVER then
    local function EnableAfterSpawn(client)
        timer.Simple(0, function()
            EnableFlashlightPermission(client)
        end)
    end

    hook.Add("PlayerInitialSpawn", HOOK_PREFIX .. ".InitialSpawn", EnableAfterSpawn)
    hook.Add("PlayerSpawn", HOOK_PREFIX .. ".Spawn", EnableAfterSpawn)
    hook.Add("PlayerLoadedCharacter", HOOK_PREFIX .. ".CharacterLoaded", EnableAfterSpawn)
else
    local function EnableLocalPlayer()
        timer.Simple(0, function()
            EnableFlashlightPermission(LocalPlayer())
        end)
    end

    hook.Add("InitPostEntity", HOOK_PREFIX .. ".InitPostEntity", EnableLocalPlayer)
    hook.Add("OnReloaded", HOOK_PREFIX .. ".Reloaded", EnableLocalPlayer)

    -- Re-enable permission before the normal impulse 100 bind is processed.
    -- Returning nil leaves the default GMod flashlight input untouched.
    hook.Add("PlayerBindPress", HOOK_PREFIX .. ".BindPermission", function(client, bind, pressed)
        if pressed and isstring(bind) and string.find(string.lower(bind), "impulse 100", 1, true) then
            EnableFlashlightPermission(client)
        end
    end)
end

-- This file is included by imperial_order_core/sh_plugin.lua, so the hook belongs to
-- the plugin table. `SCHEMA` is not guaranteed to exist while plugins load.
if ACTIVE_PLUGIN then
    function ACTIVE_PLUGIN:PlayerSwitchFlashlight(client, enabled)
        EnableFlashlightPermission(client)
        return true
    end
else
    -- Defensive fallback for manual inclusion outside Helix's plugin loader.
    hook.Add("PlayerSwitchFlashlight", HOOK_PREFIX .. ".AllowToggle", function(client)
        EnableFlashlightPermission(client)
        return true
    end)
end
