IMPERIAL_ORDER = IMPERIAL_ORDER or {}
IMPERIAL_ORDER_UI_LOADED = IMPERIAL_ORDER_UI_LOADED or {}
IMPERIAL_ORDER_UI_LOADED["imperial_notifications_v108"] = true
IMPERIAL_ORDER_UI_LOADED["imperial_notifications_v109_stackfix"] = true

-- Imperial Order V108 - Imperial Notification Override
-- Replaces Helix/default notification popups with a custom red/grey/black Imperial stack.
-- Hooks:
-- - Player:Notify(...)
-- - ix.util.Notify(...)
-- - IMPERIAL_ORDER_Notify(...)
-- - Common Helix net notification names where safe.
-- - Chatbox notices may be mirrored into this stack, except reward/payment lines that already arrive through the dedicated notification channel.

local NET_NOTIFY = "IMPERIAL_ORDER.ImperialNotify.V108"

local function IsColor(value)
    return istable(value) and isnumber(value.r) and isnumber(value.g) and isnumber(value.b)
end

local function ClampText(value)
    value = tostring(value or "")
    value = string.Trim(value)
    if #value > 260 then value = string.sub(value, 1, 260) .. "..." end
    return value
end

if SERVER then
    util.AddNetworkString(NET_NOTIFY)

    local function SendNotify(target, message, color, duration)
        message = ClampText(message)
        if message == "" then return end

        local recipients = nil

        if IsValid(target) and target:IsPlayer() then
            recipients = target
        elseif istable(target) then
            recipients = {}
            for _, ply in ipairs(target) do
                if IsValid(ply) and ply:IsPlayer() then
                    recipients[#recipients + 1] = ply
                end
            end
        else
            recipients = player.GetAll()
        end

        net.Start(NET_NOTIFY)
            net.WriteString(message)
            net.WriteColor(IsColor(color) and color or Color(215, 42, 42), false)
            net.WriteFloat(tonumber(duration) or 5)
        net.Send(recipients)
    end

    function IMPERIAL_ORDER_Notify(target, message, color, duration)
        SendNotify(target, message, color, duration)
    end

    function IMPERIAL_ORDER_NotifyAll(message, color, duration)
        SendNotify(nil, message, color, duration)
    end

    local meta = FindMetaTable("Player")
    if meta and not meta.IMPERIAL_ORDEROriginalNotifyV108 then
        meta.IMPERIAL_ORDEROriginalNotifyV108 = meta.Notify
        meta.Notify = function(self, message, color, duration)
            SendNotify(self, message, IsColor(color) and color or Color(215, 42, 42), duration or 5)
        end
    end

    timer.Simple(0, function()
        ix = ix or {}
        ix.util = ix.util or {}

        if not ix.util.IMPERIAL_ORDEROriginalNotifyV108 then
            ix.util.IMPERIAL_ORDEROriginalNotifyV108 = ix.util.Notify
        end

        ix.util.Notify = function(message, target, color, duration)
            -- Helix normally calls ix.util.Notify(message, client). Some addons pass
            -- player first by mistake, so support both.
            if IsValid(message) and isstring(target) then
                SendNotify(message, target, color, duration)
                return
            end

            SendNotify(target, message, color, duration)
        end
    end)

    concommand.Add("imperial_order_notify", function(client, _, args)
        if IsValid(client) and not client:IsAdmin() then return end
        local text = table.concat(args or {}, " ")
        if text == "" then text = "Imperial notification test." end
        SendNotify(IsValid(client) and client or nil, text, Color(215, 42, 42), 5)
    end)

    concommand.Add("imperial_order_notify_all", function(client, _, args)
        if IsValid(client) and not client:IsAdmin() then return end
        local text = table.concat(args or {}, " ")
        if text == "" then text = "Imperial broadcast test." end
        SendNotify(nil, text, Color(215, 42, 42), 6)
    end)
else
    if (IMPERIAL_ORDER_USE_NEW_IMPERIAL_UI) then
        local function ForwardImperialNotify(message, color, duration)
            message = ClampText(message)
            if (message == "") then return end

            timer.Simple(0, function()
                if (ImperialUI and ImperialUI.Notify) then
                    local kind = "info"
                    if (IsColor(color) and color.r > color.g * 1.4) then kind = "warning" end
                    ImperialUI.Notify(message, kind, duration or 5)
                else
                    chat.AddText(IsColor(color) and color or Color(215, 42, 42), message)
                end
            end)
        end

        function IMPERIAL_ORDER_AddImperialNotificationV108(message, color, duration)
            ForwardImperialNotify(message, color, duration)
        end

        net.Receive(NET_NOTIFY, function()
            ForwardImperialNotify(net.ReadString(), net.ReadColor(false), net.ReadFloat())
        end)

        timer.Simple(0, function()
            ix = ix or {}
            ix.util = ix.util or {}
            ix.util.Notify = function(message, color, duration)
                ForwardImperialNotify(message, color, duration)
            end
        end)

        return
    end

    IMPERIAL_ORDER_NOTIFY_STACK_V108 = IMPERIAL_ORDER_NOTIFY_STACK_V108 or {}

    surface.CreateFont("IMPERIAL_ORDER.Notify.Title", {font = "Trebuchet MS", size = 16, weight = 1000, antialias = true, extended = true})
    surface.CreateFont("IMPERIAL_ORDER.Notify.Body",  {font = "Trebuchet MS", size = 15, weight = 850,  antialias = true, extended = true})
    surface.CreateFont("IMPERIAL_ORDER.Notify.Tiny",  {font = "Trebuchet MS", size = 11, weight = 800,  antialias = true, extended = true})

    local function Col(name, fallback)
        return IMPERIAL_ORDERUI and IMPERIAL_ORDERUI.Col and IMPERIAL_ORDERUI.Col(name, fallback) or ((IMPERIAL_ORDER_COLORS and IMPERIAL_ORDER_COLORS[name]) or fallback or color_white)
    end

    local function IsRewardOrLegacyChatNotice(message)
        local value = string.lower(string.Trim(tostring(message or "")))
        if value == "" then return false end

        if string.match(value, "^salary:%s*") then return true end
        if string.match(value, "^%+?%d+%s+exp%s*[%-%:]") then return true end
        if string.find(value, "service level", 1, true) and string.find(value, "skill authorization", 1, true) then return true end
        if string.find(value, "you have received $", 1, true)
            and string.find(value, "dollars", 1, true)
            and string.find(value, "salary", 1, true) then
            return true
        end

        return false
    end

    local function AddNotify(message, color, duration, fromChatbox)
        message = ClampText(message)
        if message == "" then return end

        -- Salary/EXP are sent directly to this stack by the server. Ignore their
        -- second copy when an older Helix/DarkRP path also inserts them into chat.
        if fromChatbox and IsRewardOrLegacyChatNotice(message) then return end

        local now = CurTime()
        IMPERIAL_ORDER_NOTIFY_STACK_V108[#IMPERIAL_ORDER_NOTIFY_STACK_V108 + 1] = {
            text = message,
            color = IsColor(color) and color or Col("red", Color(190, 38, 38)),
            created = now,
            expires = now + (tonumber(duration) or 5)
        }

        while #IMPERIAL_ORDER_NOTIFY_STACK_V108 > 6 do
            table.remove(IMPERIAL_ORDER_NOTIFY_STACK_V108, 1)
        end

        -- V159: notifications remain in the dedicated Imperial notice stack.
        -- Do not mirror Player:Notify / ix.util.Notify back into chat; that was
        -- duplicating salary, EXP, whitelist, and deployment notices.
    end

    function IMPERIAL_ORDER_AddImperialNotificationV108(message, color, duration)
        AddNotify(message, color, duration)
    end

    local function DrawNotification(x, y, w, h, item, alpha)
        local accent = item.color or Col("red", Color(190, 38, 38))
        alpha = math.Clamp(alpha or 255, 0, 255)

        draw.RoundedBox(8, x, y, w, h, Color(4, 4, 6, math.floor(alpha * 0.92)))
        draw.RoundedBox(8, x + 3, y + 3, w - 6, h - 6, Color(13, 15, 19, math.floor(alpha * 0.88)))

        surface.SetDrawColor(accent.r, accent.g, accent.b, math.floor(alpha * 0.95))
        surface.DrawRect(x, y, 5, h)
        surface.DrawOutlinedRect(x, y, w, h, 1)

        surface.SetDrawColor(128, 136, 148, math.floor(alpha * 0.35))
        surface.DrawLine(x + 14, y + 30, x + w - 14, y + 30)

        draw.SimpleText("IMPERIAL NOTICE", "IMPERIAL_ORDER.Notify.Title", x + 16, y + 15, Color(accent.r, accent.g, accent.b, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        local text = tostring(item.text or "")
        surface.SetFont("IMPERIAL_ORDER.Notify.Body")
        while #text > 4 and surface.GetTextSize(text .. "...") > w - 32 do
            text = string.sub(text, 1, #text - 1)
        end
        if text ~= item.text then text = text .. "..." end

        draw.SimpleText(text, "IMPERIAL_ORDER.Notify.Body", x + 16, y + 47, Color(246, 247, 250, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    hook.Add("HUDPaint", "IMPERIAL_ORDER.ImperialNotificationsV108.Draw", function()
        local now = CurTime()
        local sw, sh = ScrW(), ScrH()

        local x = sw - 390
        local baseY = 84
        local w = 360
        local h = 70
        local gap = 10
        local drawIndex = 0

        for i = #IMPERIAL_ORDER_NOTIFY_STACK_V108, 1, -1 do
            local item = IMPERIAL_ORDER_NOTIFY_STACK_V108[i]

            if not item or (item.expires or 0) <= now then
                table.remove(IMPERIAL_ORDER_NOTIFY_STACK_V108, i)
            else
                drawIndex = drawIndex + 1
                local life = math.max((item.expires or now) - now, 0)
                local since = now - (item.created or now)
                local alpha = 255

                if since < 0.25 then
                    alpha = math.floor(255 * (since / 0.25))
                elseif life < 0.4 then
                    alpha = math.floor(255 * (life / 0.4))
                end

                local targetY = baseY + (drawIndex - 1) * (h + gap)
                DrawNotification(x, targetY, w, h, item, alpha)
            end
        end
    end)

    net.Receive(NET_NOTIFY, function()
        local message = net.ReadString()
        local color = net.ReadColor(false)
        local duration = net.ReadFloat()
        AddNotify(message, color, duration)
    end)

    -- Override local Helix utility notifications too.
    timer.Simple(0, function()
        ix = ix or {}
        ix.util = ix.util or {}

        if not ix.util.IMPERIAL_ORDERClientOriginalNotifyV108 then
            ix.util.IMPERIAL_ORDERClientOriginalNotifyV108 = ix.util.Notify
        end

        ix.util.Notify = function(message, color, duration)
            AddNotify(message, IsColor(color) and color or Col("red", Color(190, 38, 38)), duration or 5)
        end
    end)

    -- Some Helix versions use netstream "Notify"; some use ixNotify; this captures the common ones
    -- without breaking unrelated systems. If a name does not exist on this branch, this is harmless.
    local function TryReadNotifyPayload()
        local ok, value = pcall(net.ReadString)
        if ok and tostring(value or "") ~= "" then return tostring(value) end
        return nil
    end

    net.Receive("ixNotify", function()
        local message = TryReadNotifyPayload()
        if message then AddNotify(message, Col("red", Color(190, 38, 38)), 5) end
    end)

    net.Receive("ixNotice", function()
        local message = TryReadNotifyPayload()
        if message then AddNotify(message, Col("red", Color(190, 38, 38)), 5) end
    end)

    hook.Add("OnChatAdd", "IMPERIAL_ORDER.ImperialNotifyV108.ChatAdd", function(speaker, chatType, text, anonymous, data)
        if chatType == "notice" or chatType == "notify" then
            AddNotify(text or "", Col("red", Color(190, 38, 38)), 5)
            return true
        end
    end)

    -- Mirror ordinary custom chatbox system notices into the notification stack.
    -- Reward/payment text is filtered in AddNotify because those notices already
    -- arrive through NET_NOTIFY and would otherwise appear twice.
    timer.Simple(1, function()
        if IMPERIAL_ORDER_CHATBOX_AddSystem and not IMPERIAL_ORDER_ORIGINAL_CHATBOX_SYSTEM_V108 then
            IMPERIAL_ORDER_ORIGINAL_CHATBOX_SYSTEM_V108 = IMPERIAL_ORDER_CHATBOX_AddSystem

            IMPERIAL_ORDER_CHATBOX_AddSystem = function(text, color)
                if IMPERIAL_ORDER_NOTIFY_CHATBOX_MIRROR_GUARD_V109 then
                    return IMPERIAL_ORDER_ORIGINAL_CHATBOX_SYSTEM_V108(text, color)
                end

                AddNotify(text, color or Col("red", Color(190, 38, 38)), 4.5, true)
                return IMPERIAL_ORDER_ORIGINAL_CHATBOX_SYSTEM_V108(text, color)
            end
        end
    end)

    concommand.Add("imperial_order_notify_stackfix", function()
        IMPERIAL_ORDER_NOTIFY_CHATBOX_MIRROR_GUARD_V109 = false
        IMPERIAL_ORDER_NOTIFY_STACK_V108 = {}
        print("[IMPERIAL_ORDER] Notification stack recursion guard reset.")
    end)

    concommand.Add("imperial_order_notify_test", function()
        AddNotify("Imperial notification stack online.", Col("red", Color(190, 38, 38)), 5)
    end)

    concommand.Add("imperial_order_clear_notifications", function()
        IMPERIAL_ORDER_NOTIFY_STACK_V108 = {}
        print("[IMPERIAL_ORDER] Notification stack cleared.")
    end)
end
