IMPERIAL_ORDER = IMPERIAL_ORDER or {}

IMPERIAL_ORDER.departments = {
    army = "Imperial Army",
    navy = "Imperial Navy Command",
    isb = "ISB Intelligence Bureau",
    inq = "Inquisitorius",
    engineering = "Imperial Engineering Corps",
    systems = "Imperial Systems Bureau",
    civil = "Civil Administration",
    security = "Sector Security Bureau",
    command = "Imperial High Command",
    royalGuard = "Imperial Royal Guard",
    aux = "Auxiliary Forces"
}

local function CleanText(value)
    return string.lower(tostring(value or ""))
end

local function Has(text, value)
    return string.find(text, value, 1, true) ~= nil
end

function IMPERIAL_ORDER.GetRoleLabel(factionName, className)
    local text = CleanText(tostring(factionName or "") .. " " .. tostring(className or ""))
    if Has(text, "shadow guard") then return "Shadow Guard" end
    if Has(text, "royal guard") or Has(text, "sovereign protector") then return "Royal Guard" end
    if Has(text, "inquisitor") then return "Inquisitor" end
    if Has(text, "director") or Has(text, "isb") then return "ISB Agent" end
    if Has(text, "officer") or Has(text, "lieutenant") or Has(text, "marshal") or Has(text, "warlord") or Has(text, "high") or Has(text, "prime") then return "Officer" end
    if Has(text, "soldier") or Has(text, "trooper") or Has(text, "warrior") or Has(text, "guardian") or Has(text, "sentinel") or Has(text, "warden") or Has(text, "raider") then return "Trooper" end
    if Has(text, "engineer") or Has(text, "pioneer") then return "Engineer" end
    if Has(text, "node") or Has(text, "weaver") or Has(text, "collective") then return "Droid Intelligence" end
    if Has(text, "citizen") or Has(text, "civilian") then return "Civilian Auxilia" end
    if Has(text, "acolyte") then return "Acolyte" end
    if Has(text, "arbiter") or Has(text, "seer") or Has(text, "voice") then return "ISB Specialist" end
    if Has(text, "emissary") or Has(text, "scholar") or Has(text, "initiate") then return "Imperial Attaché" end
    return "Operative"
end

function IMPERIAL_ORDER.GetFaction(factionName, className)
    local text = CleanText(tostring(factionName or "") .. " " .. tostring(className or ""))
    if Has(text, "royal guard") or Has(text, "shadow guard") or Has(text, "sovereign protector") then return IMPERIAL_ORDER.departments.royalGuard end
    if Has(text, "inquisitor") then return IMPERIAL_ORDER.departments.inq end
    if Has(text, "director") or Has(text, "isb") or Has(text, "arbiter") or Has(text, "seer") or Has(text, "voice") then return IMPERIAL_ORDER.departments.isb end
    if Has(text, "officer") or Has(text, "lieutenant") or Has(text, "marshal") or Has(text, "warlord") or Has(text, "prime") or Has(text, "high") then return IMPERIAL_ORDER.departments.navy end
    if Has(text, "soldier") or Has(text, "trooper") or Has(text, "warrior") or Has(text, "guardian") or Has(text, "sentinel") or Has(text, "warden") then return IMPERIAL_ORDER.departments.army end
    if Has(text, "engineer") or Has(text, "pioneer") or Has(text, "scholar") then return IMPERIAL_ORDER.departments.engineering end
    if Has(text, "collective") or Has(text, "node") or Has(text, "weaver") then return IMPERIAL_ORDER.departments.systems end
    if Has(text, "raider") then return IMPERIAL_ORDER.departments.aux end
    if Has(text, "citizen") or Has(text, "civilian") then return IMPERIAL_ORDER.departments.civil end
    return factionName and tostring(factionName) ~= "" and tostring(factionName) or "Imperial Order"
end

function IMPERIAL_ORDER.GetFactionCode(factionName, className)
    local dept = IMPERIAL_ORDER.GetFaction(factionName, className)
    local text = CleanText(dept)
    if Has(text, "royal guard") then return "IRG" end
    if Has(text, "inquisitor") then return "INQ" end
    if Has(text, "intelligence") or Has(text, "isb") then return "ISB" end
    if Has(text, "navy") or Has(text, "command") then return "NAV" end
    if Has(text, "army") then return "ARM" end
    if Has(text, "engineering") then return "ENG" end
    if Has(text, "systems") then return "SYS" end
    if Has(text, "civil") then return "CIV" end
    if Has(text, "auxiliary") then return "AUX" end
    return "IMPERIAL_ORDER"
end

function IMPERIAL_ORDER.GetRoleLine(factionName, className)
    return IMPERIAL_ORDER.GetRoleLabel(factionName, className) .. " | " .. IMPERIAL_ORDER.GetFactionCode(factionName, className)
end

function IMPERIAL_ORDER.GetBriefing(factionName, className)
    local role = IMPERIAL_ORDER.GetRoleLabel(factionName, className)
    local department = IMPERIAL_ORDER.GetFaction(factionName, className)
    return role .. " assigned to " .. department .. ". Maintain order, discipline, and loyalty."
end

function IMPERIAL_ORDER.GetSectionTitle(factionName, className)
    return string.upper(IMPERIAL_ORDER.GetFaction(factionName, className))
end
