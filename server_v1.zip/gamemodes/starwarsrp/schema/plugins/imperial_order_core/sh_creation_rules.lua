IMPERIAL_ORDER = IMPERIAL_ORDER or {}
IMPERIAL_ORDER_UI_LOADED = IMPERIAL_ORDER_UI_LOADED or {}
IMPERIAL_ORDER_UI_LOADED.fresh_creation_table_v56 = true
IMPERIAL_ORDER_UI_LOADED.helix_jobs_import_v57 = true
IMPERIAL_ORDER_UI_LOADED.darkrp_jobs_converted_v57 = true
IMPERIAL_ORDER_UI_LOADED.helix_factions_classes_v57 = true
IMPERIAL_ORDER_UI_LOADED.cadet_default_class_v58 = true
IMPERIAL_ORDER_UI_LOADED.class_whitelist_creation_v58 = true
IMPERIAL_ORDER_UI_LOADED.cadet_only_creation_v62 = true
IMPERIAL_ORDER_UI_LOADED.hidden_imported_factions_creation_v62 = true
IMPERIAL_ORDER_UI_LOADED.duplicate_cadet_cleanup_v62 = true

local fallbackModel = "models/player/group01/male_01.mdl"

local function GetDepartmentSource()
    if not ix or not ix.faction then return {} end
    return ix.faction.indices or ix.faction.teams or {}
end

local function GetClassSource()
    if not ix or not ix.class then return {} end
    return ix.class.list or {}
end

local function Lower(value)
    return string.lower(tostring(value or ""))
end

local function FindCadetDepartment()
    if IMPERIAL_ORDER_FindCadetDepartmentV58 then
        local id, faction = IMPERIAL_ORDER_FindCadetDepartmentV58()
        if id and faction then return id, faction end
    end

    if FACTION_IMPERIAL_CADETS then
        local source = GetDepartmentSource()
        local faction = source[FACTION_IMPERIAL_CADETS]
        if faction then return FACTION_IMPERIAL_CADETS, faction end
    end

    for id, faction in pairs(GetDepartmentSource()) do
        local name = Lower(faction and faction.name)
        if name == "imperial cadets" or string.find(name, "cadet", 1, true) then
            return id, faction
        end
    end

    for id, faction in pairs(GetDepartmentSource()) do
        return id, faction
    end
end

local function FindCadetClass()
    if IMPERIAL_ORDER_FindCadetClassV58 then
        local id, class = IMPERIAL_ORDER_FindCadetClassV58()
        if id and class then return id, class end
    end

    for id, class in pairs(GetClassSource()) do
        local name = Lower(class and class.name)
        local command = Lower(class and class.command)
        if name == "imperial cadet" or command == "ic" then
            return id, class
        end
    end

    for id, class in pairs(GetClassSource()) do
        return id, class
    end
end

function IMPERIAL_ORDER.GetFreshCreationDepartmentsV56(client)
    local factionID, faction = FindCadetDepartment()
    if not factionID or not faction then return {} end

    return {{
        id = factionID,
        data = faction,
        label = "Department: Imperial Cadets"
    }}
end

function IMPERIAL_ORDER.GetFreshCreationClassesV56(factionID, client)
    local cadetDepartmentID, cadetDepartment = FindCadetDepartment()
    local cadetClassID, cadetClass = FindCadetClass()
    if not cadetClassID or not cadetClass then return {} end
    if cadetDepartmentID and tostring(factionID or cadetDepartmentID) ~= tostring(cadetDepartmentID) then return {} end

    return {{
        id = cadetClassID,
        data = cadetClass,
        rank = 0,
        label = "Starting Rank: Imperial Cadet"
    }}
end

local function BuildModelListFromDepartment(faction)
    local output = {}

    if faction and istable(faction.models) then
        local seen = {}
        for index, model in ipairs(faction.models) do
            local path = istable(model) and (model[1] or model.model) or model
            if isstring(path) and path ~= "" and not seen[path] then
                seen[path] = true
                output[#output + 1] = {key = index, model = path, label = "Cadet Model " .. tostring(#output + 1)}
            end
        end
    end

    if #output == 0 then
        output[#output + 1] = {key = 1, model = fallbackModel, label = "Fallback Cadet Model"}
    end

    return output
end

function IMPERIAL_ORDER.GetFreshCreationModelOptionsV56(faction)
    if isnumber(faction) and ix and ix.faction then
        faction = (ix.faction.indices and ix.faction.indices[faction]) or (ix.faction.teams and ix.faction.teams[faction])
    end

    if not faction then
        local _, cadetDepartment = FindCadetDepartment()
        faction = cadetDepartment
    end

    return BuildModelListFromDepartment(faction)
end

function IMPERIAL_ORDER.IsAllowedCreationClassV56(classID, factionID)
    local cadetDepartmentID = FindCadetDepartment()
    local cadetClassID = FindCadetClass()
    return tostring(classID or "") == tostring(cadetClassID or "") and tostring(factionID or cadetDepartmentID or "") == tostring(cadetDepartmentID or "")
end

function IMPERIAL_ORDER_CreationValidatePayloadV56(client, payload)
    if not istable(payload) then return false, "Invalid Imperial personnel data." end
    if not ix or not ix.faction or not ix.class then return false, "Imperial personnel tables are not loaded." end

    local factionID, faction = FindCadetDepartment()
    local classID, class = FindCadetClass()

    if not factionID or not faction then return false, "Imperial Cadets faction is not loaded." end
    if not classID or not class then return false, "Imperial Cadet class is not loaded." end

    payload.faction = factionID
    payload.class = classID

    local models = IMPERIAL_ORDER.GetFreshCreationModelOptionsV56(faction)
    local modelKey = tonumber(payload.model) or 1
    if modelKey < 1 or modelKey > #models then modelKey = 1 end
    payload.model = modelKey

    payload.imperial_orderFreshCreationV56 = true
    payload.imperial_orderCadetOnlyCreationV62 = true

    return true
end

hook.Add("InitializedSchema", "IMPERIAL_ORDER.CadetOnlyDepartmentDefaultsV62", function()
    local cadetDepartmentID = FindCadetDepartment()
    for id, faction in pairs(GetDepartmentSource()) do
        if faction then
            faction.isDefault = tostring(id) == tostring(cadetDepartmentID or "")
            faction.noCreationSelect = not faction.isDefault
        end
    end

    local cadetClassID = FindCadetClass()
    for id, class in pairs(GetClassSource()) do
        if class then
            class.isDefault = tostring(id) == tostring(cadetClassID or "")
            class.whitelist = not class.isDefault
        end
    end
end)
