IMPERIAL_ORDER_UI_LOADED = IMPERIAL_ORDER_UI_LOADED or {}
IMPERIAL_ORDER_UI_LOADED.character_create_bridge_v40 = true
IMPERIAL_ORDER_UI_LOADED.safe_helix_charcreate_v40 = true
IMPERIAL_ORDER_UI_LOADED.custom_create_net_v40 = true
IMPERIAL_ORDER_UI_LOADED.cadet_only_creation_v62 = true

IMPERIAL_ORDER_CREATE_REQUEST_V40 = "IMPERIAL_ORDER.CharacterCreate.RequestV40"
IMPERIAL_ORDER_CREATE_RESULT_V40 = "IMPERIAL_ORDER.CharacterCreate.ResultV40"

local function IMPERIAL_ORDERSendCreateResult(client, ok, message, id, data)
    if not SERVER or not IsValid(client) then return end
    net.Start(IMPERIAL_ORDER_CREATE_RESULT_V40)
    net.WriteBool(ok == true)
    net.WriteString(tostring(message or ""))
    net.WriteUInt(tonumber(id) or 0, 32)
    net.WriteTable(data or {})
    net.Send(client)
end

local function IMPERIAL_ORDERReadableCreateMessage(message, data)
    message = tostring(message or "unknownError")
    local friendly = {
        unknownError = "Personnel creation failed. Check the selected department, class, model, and name.",
        needModel = "Select a valid model for that faction.",
        invalid = "One of the character fields is invalid.",
        maxCharacters = "You have reached the maximum number of personnel files.",
        nameMinLen = "The personnel designation is too short.",
        nameMaxLen = "The personnel designation is too long.",
        descMinLen = "The personnel record could not be generated."
    }
    return friendly[message] or message
end

if SERVER then
    util.AddNetworkString(IMPERIAL_ORDER_CREATE_REQUEST_V40)
    util.AddNetworkString(IMPERIAL_ORDER_CREATE_RESULT_V40)

    -- V209: keep the exact object returned by the creation pipeline until the
    -- character is confirmed active. Some legacy hooks rebuild ix.char.loaded
    -- during CharacterCreated, which made the load bridge temporarily see nil.
    IMPERIAL_ORDER_PENDING_FRESH_CHARACTERS_V209 = IMPERIAL_ORDER_PENDING_FRESH_CHARACTERS_V209 or {}

    local function IMPERIAL_ORDERGetMaxCharacters(client)
        local maximum = 4
        local schemaTable = Schema or SCHEMA

        if schemaTable and type(schemaTable.GetMaxPlayerCharacter) == "function" then
            local ok, result = pcall(schemaTable.GetMaxPlayerCharacter, schemaTable, client)
            if ok and tonumber(result) then
                maximum = tonumber(result)
            end
        elseif ix and ix.config then
            maximum = tonumber(ix.config.Get("maxChars", 4)) or 4
        end

        if maximum < 2 then
            maximum = 4
        end

        return math.Clamp(math.floor(maximum), 2, 10)
    end

    local function IMPERIAL_ORDERCountCharacters(client)
        if not IsValid(client) then return 0 end

        if type(IMPERIAL_ORDER_CountUsableCharacterSlotsV189) == "function" then
            local ok, count = pcall(IMPERIAL_ORDER_CountUsableCharacterSlotsV189, client)
            if ok and tonumber(count) then return math.max(math.floor(tonumber(count)), 0) end
        end

        local seen = {}
        local function AddSource(source)
            if not istable(source) then return end
            for key, value in pairs(source) do
                local id = tonumber(value)
                if not id and istable(value) then
                    id = tonumber(value.id or value._id or value.ID)
                    if not id and type(value.GetID) == "function" then
                        local ok, result = pcall(value.GetID, value)
                        if ok then id = tonumber(result) end
                    end
                end
                if not id then id = tonumber(key) end
                local deleted = false
                if id and IMPERIAL_ORDER_IsCharacterDeletedV58 then
                    local okDeleted, resultDeleted = pcall(IMPERIAL_ORDER_IsCharacterDeletedV58, client, id)
                    deleted = okDeleted and resultDeleted == true
                end
                if id and id > 0 and not deleted then seen[id] = true end
            end
        end

        AddSource(client.ixCharList)
        AddSource(client.characters)
        AddSource(client.charList)
        if ix and ix.char and istable(ix.char.cache) then
            AddSource(ix.char.cache[client:SteamID64()])
        end

        return table.Count(seen)
    end

    local function IMPERIAL_ORDERTrackCharacter(client, id)
        if not IsValid(client) or not tonumber(id) then return end
        id = tonumber(id)
        local steamID = client:SteamID64()
        client.ixCharList = client.ixCharList or {}
        local exists = false
        for _, value in pairs(client.ixCharList) do
            if tonumber(value) == id then
                exists = true
                break
            end
        end
        if not exists then
            table.insert(client.ixCharList, id)
        end
        if ix and ix.char then
            ix.char.cache = ix.char.cache or {}
            ix.char.cache[steamID] = ix.char.cache[steamID] or {}
            local cached = false
            for _, value in pairs(ix.char.cache[steamID]) do
                if tonumber(value) == id then
                    cached = true
                    break
                end
            end
            if not cached then
                table.insert(ix.char.cache[steamID], id)
            end
        end
    end

    local function IMPERIAL_ORDERValidateCreatePayload(client, payload)
        if not istable(payload) then
            return false, "invalid", {"payload"}
        end
        if not ix or not ix.char or not ix.char.vars or not ix.char.Create then
            return false, "Character system is not ready.", {}
        end
        if payload.imperial_orderFreshCreationV56 ~= true then
            return false, "Use the Imperial intake table to create personnel files.", {}
        end
        payload.imperial_orderFreshCreationV56 = nil
        if IMPERIAL_ORDER_CreationValidatePayloadV56 then
            local allowed, reason = IMPERIAL_ORDER_CreationValidatePayloadV56(client, payload)
            if allowed == false then
                return false, reason or "Imperial intake validation failed.", {}
            end
        end
        if ((client.IMPERIAL_ORDERNextCharacterCreateV40 or 0) > RealTime()) then
            return false, "Please wait before creating another personnel file.", {}
        end
        local maxChars = IMPERIAL_ORDERGetMaxCharacters(client)
        if IMPERIAL_ORDERCountCharacters(client) >= maxChars then
            return false, "maxCharacters", {}
        end
        client.IMPERIAL_ORDERNextCharacterCreateV40 = RealTime() + 1
        local results = {hook.Run("CanPlayerCreateCharacter", client, payload)}
        if table.remove(results, 1) == false then
            return false, table.remove(results, 1) or "unknownError", results
        end
        for k, _ in pairs(payload) do
            local info = ix.char.vars[k]
            if (not info or (not info.OnValidate and info.bNoDisplay)) then
                payload[k] = nil
            end
        end
        local newPayload = {}
        for k, v in SortedPairsByMemberValue(ix.char.vars, "index") do
            local value = payload[k]
            if v.OnValidate then
                local result = {v:OnValidate(value, payload, client)}
                if result[1] == false then
                    local fault = result[2]
                    table.remove(result, 2)
                    table.remove(result, 1)
                    return false, fault or "unknownError", result
                else
                    if result[1] ~= nil then
                        payload[k] = result[1]
                    end
                    if v.OnAdjust then
                        v:OnAdjust(client, payload, value, newPayload)
                    end
                end
            end
        end
        payload.description = tostring(payload.description or "")
        if string.Trim(payload.description) == "" or #payload.description < 16 then
            payload.description = "Imperial personnel record."
        end
        payload.desc = payload.description
        payload.steamID = client:SteamID64()
        hook.Run("AdjustCreationPayload", client, payload, newPayload)
        payload = table.Merge(payload, newPayload)
        return true, payload, {}
    end

    local createPending = setmetatable({}, {__mode = "k"})

    local function ClearCreatePending(client)
        if not IsValid(client) then return end
        createPending[client] = nil
        timer.Remove("IMPERIAL_ORDER.CharacterCreate.PendingV171." .. tostring(client:SteamID64() or client:UserID()))
    end


    local function IMPERIAL_ORDERBuildCreateResultDataV197(id, payload)
        payload = istable(payload) and payload or {}
        local factionName = "Imperial Cadets"
        local className = "Imperial Cadet"

        if ix and ix.faction then
            local factions = ix.faction.indices or ix.faction.list or {}
            local faction = factions[payload.faction]
            if istable(faction) and isstring(faction.name) then factionName = faction.name end
        end
        if ix and ix.class and istable(ix.class.list) then
            local class = ix.class.list[payload.class]
            if istable(class) and isstring(class.name) then className = class.name end
        end

        return {
            id = tonumber(id) or 0,
            name = tostring(payload.name or ("Operative #" .. tostring(id))),
            description = tostring(payload.description or "Imperial personnel record."),
            faction = tonumber(payload.faction) or payload.faction,
            factionName = factionName,
            division = factionName,
            class = tonumber(payload.class) or payload.class,
            className = className,
            model = payload.model,
            level = tonumber(payload.imperialOrderLevel or payload.level) or 1
        }
    end

    local function IMPERIAL_ORDERActiveCharacterIDV235(client)
        if not IsValid(client) or type(client.GetCharacter) ~= "function" then return 0 end
        local character = client:GetCharacter()
        if not character or type(character.GetID) ~= "function" then return 0 end
        return tonumber(character:GetID()) or 0
    end

    net.Receive(IMPERIAL_ORDER_CREATE_REQUEST_V40, function(_, client)
        if not IsValid(client) then return end

        if createPending[client] then
            IMPERIAL_ORDERSendCreateResult(client, false, "A personnel file is already being created. Please wait.", 0, {})
            return
        end

        local okRead, payload = pcall(net.ReadTable)
        if not okRead then
            IMPERIAL_ORDERSendCreateResult(client, false, "Invalid character creation data.", 0, {})
            return
        end

        -- V171: lock immediately, before validation/database work. This prevents two
        -- rapid menu submissions from creating separate rows before Helix updates its cache.
        createPending[client] = true
        timer.Create("IMPERIAL_ORDER.CharacterCreate.PendingV171." .. tostring(client:SteamID64() or client:UserID()), 75, 1, function()
            if IsValid(client) and createPending[client] then
                createPending[client] = nil
                IMPERIAL_ORDERSendCreateResult(client, false, "Character creation timed out. Try once more.", 0, {})
            end
        end)

        local ok, result, extra = IMPERIAL_ORDERValidateCreatePayload(client, payload)
        if not ok then
            ClearCreatePending(client)
            IMPERIAL_ORDERSendCreateResult(client, false, IMPERIAL_ORDERReadableCreateMessage(result, extra), 0, extra or {})
            return
        end

        -- Recheck after validation so simultaneous submissions cannot exceed the
        -- configured slot limit before Helix refreshes its character cache.
        local maxChars = IMPERIAL_ORDERGetMaxCharacters(client)
        if IMPERIAL_ORDERCountCharacters(client) >= maxChars then
            ClearCreatePending(client)
            IMPERIAL_ORDERSendCreateResult(client, false, "You have reached the maximum number of Imperial personnel files.", 0, {})
            return
        end

        ix.char.cache = ix.char.cache or {}
        ix.char.cache[client:SteamID64()] = ix.char.cache[client:SteamID64()] or client.ixCharList or {}

        local createOk, createErr = pcall(function()
            ix.char.Create(result, function(id)
                ClearCreatePending(client)
                if not IsValid(client) then return end

                id = tonumber(id) or 0
                if id <= 0 then
                    IMPERIAL_ORDERSendCreateResult(client, false, "Character creation returned no valid profile ID.", 0, {})
                    return
                end

                -- V206: keep a short-lived server-authoritative generation marker.
                -- Some legacy delete hooks can fire during cache cleanup and would
                -- otherwise attach an old numeric-ID tombstone to this new row.
                client.IMPERIAL_ORDERRecentlyCreatedIDsV206 = istable(client.IMPERIAL_ORDERRecentlyCreatedIDsV206) and client.IMPERIAL_ORDERRecentlyCreatedIDsV206 or {}
                client.IMPERIAL_ORDERRecentlyCreatedIDsV206[id] = RealTime() + 600

                -- Numeric IDs can be reused after a database reset. Mark this exact
                -- freshly-created row as a new generation before any load/delete guard
                -- sees the old tombstone that previously belonged to the same ID.
                if IMPERIAL_ORDER_MarkCharacterRecreatedV198 then
                    pcall(IMPERIAL_ORDER_MarkCharacterRecreatedV198, client, id)
                end
                if IMPERIAL_ORDER_ClearDeletedCharacterMarkV58 then
                    pcall(IMPERIAL_ORDER_ClearDeletedCharacterMarkV58, client, id)
                end

                IMPERIAL_ORDERTrackCharacter(client, id)
                local character = ix.char.loaded and (ix.char.loaded[id] or ix.char.loaded[tostring(id)]) or nil
                if character then
                    IMPERIAL_ORDER_PENDING_FRESH_CHARACTERS_V209[id] = character
                    character.player = client
                    character.client = client

                    -- V236: this custom request bypasses Helix's native
                    -- ixCharacterCreate receiver, so reproduce its required
                    -- synchronization/authentication handoff before deployment.
                    if type(character.Sync) == "function" then
                        local syncOK, syncErr = pcall(character.Sync, character, client)
                        if not syncOK then
                            ErrorNoHalt("[Imperial Order V236] Character sync error for #" .. tostring(id) .. ": " .. tostring(syncErr) .. "\n")
                        end
                    end

                    client.ixCharList = istable(client.ixCharList) and client.ixCharList or {}
                    local listed = false
                    for _, listedID in ipairs(client.ixCharList) do
                        if tonumber(listedID) == tonumber(id) then listed = true break end
                    end
                    if not listed then client.ixCharList[#client.ixCharList + 1] = id end

                    net.Start("ixCharacterAuthed")
                    net.WriteUInt(id, 32)
                    net.WriteUInt(math.min(#client.ixCharList, 63), 6)
                    for index = 1, math.min(#client.ixCharList, 63) do
                        net.WriteUInt(tonumber(client.ixCharList[index]) or 0, 32)
                    end
                    net.Send(client)
                end

                -- Match the current Helix creation lifecycle. CharacterCreated is
                -- not the native post-create hook and caused duplicate side effects.
                local hookOK, hookErr = pcall(hook.Run, "OnCharacterCreated", client, character)
                if not hookOK then
                    ErrorNoHalt("[Imperial Order V236] OnCharacterCreated hook error for #" .. tostring(id) .. ": " .. tostring(hookErr) .. "\n")
                end

                -- Some legacy hooks rebuild ix.char.loaded. Preserve the exact
                -- newly-created object for the deployment handoff.
                character = character or IMPERIAL_ORDER_PENDING_FRESH_CHARACTERS_V209[id]
                    or (ix.char.loaded and (ix.char.loaded[id] or ix.char.loaded[tostring(id)]))
                if character and ix and ix.char and istable(ix.char.loaded) then
                    IMPERIAL_ORDER_PENDING_FRESH_CHARACTERS_V209[id] = character
                    ix.char.loaded[id] = character
                    character.player = client
                    character.client = client
                end

                local resultData = IMPERIAL_ORDERBuildCreateResultDataV197(id, result)
                IMPERIAL_ORDERSendCreateResult(client, true, "Personnel file created.", id, resultData)
                -- V235: creation and deployment are deliberately separate. The client
                -- receives the new ID, refreshes the list, then asks Helix through its
                -- native ixCharacterChoose receiver. No custom server activation runs.
                if IMPERIAL_ORDER_PushCharacterSync then
                    timer.Simple(0.1, function()
                        if IsValid(client) then IMPERIAL_ORDER_PushCharacterSync(client) end
                    end)
                end
            end)
        end)

        if not createOk then
            ClearCreatePending(client)
            IMPERIAL_ORDERSendCreateResult(client, false, tostring(createErr or "Character creation failed."), 0, {})
        end
    end)

    concommand.Add("imperial_order_created_deploy_status_v208", function(client, _, args)
        if IsValid(client) and not client:IsAdmin() then return end
        local target = client
        if not IsValid(target) then
            local wanted = tostring(args and args[2] or "")
            for _, candidate in ipairs(player.GetAll()) do
                if wanted ~= "" and tostring(candidate:SteamID64() or "") == wanted then target = candidate break end
            end
        end
        if not IsValid(target) then
            print("[Imperial Order V208] Usage: imperial_order_created_deploy_status_v208 <characterID> <online SteamID64>")
            return
        end
        local id = tonumber(args and args[1] or 0) or 0
        local loaded = ix and ix.char and ix.char.loaded and ix.char.loaded[id] or nil
        local line = "[Imperial Order V208] player=" .. target:Nick() .. " requested=" .. tostring(id)
            .. " active=" .. tostring(IMPERIAL_ORDERActiveCharacterIDV235(target))
            .. " netvar=" .. tostring(type(target.GetNetVar) == "function" and target:GetNetVar("char", 0) or "n/a")
            .. " loadedObject=" .. tostring(loaded ~= nil)
        if IsValid(client) then client:PrintMessage(HUD_PRINTCONSOLE, line .. "\n") else print(line) end
    end)
end
