-- Imperial Order v255
-- Reliable CAMI/SAM privilege cache for Helix Basic Prop Protection.
--
-- CAMI.PlayerHasAccess is callback-based. Sandbox hooks such as CanTool,
-- PhysgunPickup, CanProperty, and PlayerSpawnObject require an immediate
-- boolean decision, so this file keeps a short-lived permission cache and
-- refreshes it whenever player/usergroup state changes.

IMPERIAL_ORDER = IMPERIAL_ORDER or {}
IMPERIAL_ORDER_LOADED = IMPERIAL_ORDER_LOADED or {}
IMPERIAL_ORDER_LOADED.cami_propprotect_fix_v255 = true

IMPERIAL_ORDER.PropProtect = IMPERIAL_ORDER.PropProtect or {}
local PP = IMPERIAL_ORDER.PropProtect

PP.Privilege = "Helix - Bypass Prop Protection"
PP.CacheLifetime = 20
PP.Cache = PP.Cache or setmetatable({}, {__mode = "k"})
PP.Pending = PP.Pending or setmetatable({}, {__mode = "k"})

local function Now()
    return RealTime and RealTime() or CurTime()
end

local function GetGroup(client)
    if not IsValid(client) or not client:IsPlayer() then return "" end
    if not client.GetUserGroup then return "" end

    local ok, group = pcall(client.GetUserGroup, client)
    return ok and tostring(group or "") or ""
end

local function SetCache(client, allowed, reason)
    if not IsValid(client) or not client:IsPlayer() then return false end

    local value = allowed == true
    PP.Cache[client] = {
        allowed = value,
        reason = tostring(reason or ""),
        group = GetGroup(client),
        expires = Now() + PP.CacheLifetime,
        updated = Now()
    }

    PP.Pending[client] = nil
    return value
end

function PP.Invalidate(client)
    if IsValid(client) then
        PP.Cache[client] = nil
        PP.Pending[client] = nil
    end
end

function PP.Refresh(client, callback)
    if not IsValid(client) or not client:IsPlayer() then
        if isfunction(callback) then callback(false, "invalid player") end
        return false
    end

    -- Garry's Mod's built-in admin groups always keep the bypass, even if an
    -- admin addon has not finished loading its CAMI permissions yet.
    if client:IsSuperAdmin() or client:IsAdmin() then
        local result = SetCache(client, true, "built-in admin")
        if isfunction(callback) then callback(result, "built-in admin") end
        return result
    end

    if not CAMI or not isfunction(CAMI.PlayerHasAccess) then
        local result = SetCache(client, false, "CAMI unavailable")
        if isfunction(callback) then callback(result, "CAMI unavailable") end
        return result
    end

    local pendingAt = tonumber(PP.Pending[client])
    if pendingAt and (Now() - pendingAt) < 5 then
        return nil
    end

    PP.Pending[client] = Now()
    local requestStarted = PP.Pending[client]
    local callbackFired = false
    local callbackValue = false
    local callbackReason = "pending"

    local function ReceiveAccess(hasAccess, reason)
        if not IsValid(client) then return end

        callbackFired = true
        callbackValue = SetCache(client, hasAccess == true, reason)
        callbackReason = tostring(reason or "CAMI")

        if isfunction(callback) then
            callback(callbackValue, callbackReason)
        end
    end

    local ok, err = pcall(function()
        CAMI.PlayerHasAccess(client, PP.Privilege, ReceiveAccess)
    end)

    if not ok then
        PP.Pending[client] = nil
        local result = SetCache(client, false, "CAMI error: " .. tostring(err))
        if isfunction(callback) then callback(result, tostring(err)) end
        return result
    end

    timer.Simple(5, function()
        if IsValid(client) and PP.Pending[client] == requestStarted then
            PP.Pending[client] = nil
        end
    end)

    -- Some CAMI providers invoke the callback before PlayerHasAccess returns.
    if callbackFired then
        return callbackValue, callbackReason
    end

    -- Asynchronous provider: keep the previous cached result until the callback
    -- arrives. Unknown users fail closed only for this brief first refresh.
    local cached = PP.Cache[client]
    if cached and cached.group == GetGroup(client) then
        return cached.allowed == true, cached.reason
    end

    return nil
end

function PP.HasBypass(client)
    if not IsValid(client) or not client:IsPlayer() then return false end

    if client:IsSuperAdmin() or client:IsAdmin() then
        SetCache(client, true, "built-in admin")
        return true
    end

    local cached = PP.Cache[client]
    local group = GetGroup(client)

    if cached and cached.group == group and (tonumber(cached.expires) or 0) > Now() then
        return cached.allowed == true
    end

    -- Refresh in the background. When CAMI answers synchronously this also
    -- returns the new value immediately.
    local refreshed = PP.Refresh(client)
    if isbool(refreshed) then return refreshed end

    -- If an expired value exists for the same group, use it while an async
    -- refresh is pending rather than briefly revoking an established rank.
    if cached and cached.group == group then
        return cached.allowed == true
    end

    return false
end

function PP.Prime(client)
    if not IsValid(client) or not client:IsPlayer() then return end

    PP.Invalidate(client)
    PP.Refresh(client)
end

local function PrimeLater(client, delay)
    timer.Simple(delay, function()
        if IsValid(client) then
            PP.Prime(client)
        end
    end)
end

if SERVER then
    hook.Add("PlayerInitialSpawn", "IMPERIAL_ORDER.V255.CAMIPropProtect.InitialSpawn", function(client)
        PrimeLater(client, 0)
        PrimeLater(client, 1)
        PrimeLater(client, 5)
    end)

    hook.Add("PlayerLoadedCharacter", "IMPERIAL_ORDER.V255.CAMIPropProtect.Character", function(client)
        PrimeLater(client, 0)
    end)

    hook.Add("PlayerDisconnected", "IMPERIAL_ORDER.V255.CAMIPropProtect.Disconnect", function(client)
        PP.Invalidate(client)
    end)

    timer.Create("IMPERIAL_ORDER.V255.CAMIPropProtect.Refresh", 15, 0, function()
        for _, client in ipairs(player.GetAll()) do
            PP.Refresh(client)
        end
    end)
else
    hook.Add("InitPostEntity", "IMPERIAL_ORDER.V255.CAMIPropProtect.ClientPrime", function()
        PrimeLater(LocalPlayer(), 0)
        PrimeLater(LocalPlayer(), 2)
    end)

    timer.Create("IMPERIAL_ORDER.V255.CAMIPropProtect.ClientRefresh", 15, 0, function()
        local client = LocalPlayer()
        if IsValid(client) then
            PP.Refresh(client)
        end
    end)
end

-- SAM and other CAMI-compatible admin systems are expected to signal this hook
-- when a player's group changes. Invalidate immediately so the next check uses
-- the newly assigned rank.
hook.Add("CAMI.PlayerUsergroupChanged", "IMPERIAL_ORDER.V255.CAMIPropProtect.GroupChanged", function(client)
    if not IsValid(client) then return end

    PP.Invalidate(client)
    PrimeLater(client, 0)
    PrimeLater(client, 1)
end)

hook.Add("CAMI.OnPrivilegeRegistered", "IMPERIAL_ORDER.V255.CAMIPropProtect.PrivilegeRegistered", function(privilege)
    if not istable(privilege) or privilege.Name ~= PP.Privilege then return end

    if SERVER then
        for _, client in ipairs(player.GetAll()) do
            PrimeLater(client, 0)
        end
    else
        PrimeLater(LocalPlayer(), 0)
    end
end)

concommand.Add("imperial_order_cami_bypass_status_v255", function(client)
    local target = IsValid(client) and client or (CLIENT and LocalPlayer() or nil)
    local privilegeFound = false

    if CAMI and isfunction(CAMI.GetPrivilege) then
        local ok, privilege = pcall(CAMI.GetPrivilege, PP.Privilege)
        privilegeFound = ok and privilege ~= nil
    end

    local cached = IsValid(target) and PP.Cache[target] or nil
    local lines = {
        "[Imperial Order v255] CAMI available: " .. (CAMI and isfunction(CAMI.PlayerHasAccess) and "yes" or "no"),
        "[Imperial Order v255] privilege registered: " .. (privilegeFound and "yes" or "no"),
        "[Imperial Order v255] usergroup: " .. (IsValid(target) and GetGroup(target) or "server console"),
        "[Imperial Order v255] built-in admin: " .. (IsValid(target) and (target:IsAdmin() or target:IsSuperAdmin()) and "yes" or "no"),
        "[Imperial Order v255] cached bypass: " .. (cached and tostring(cached.allowed == true) or "unknown"),
        "[Imperial Order v255] cached reason: " .. (cached and tostring(cached.reason or "") or "none"),
        "[Imperial Order v255] effective bypass: " .. (IsValid(target) and tostring(PP.HasBypass(target)) or "n/a")
    }

    for _, line in ipairs(lines) do
        if SERVER and IsValid(client) then
            client:PrintMessage(HUD_PRINTCONSOLE, line .. "\n")
        else
            print(line)
        end
    end

    if IsValid(target) then
        PP.Refresh(target, function(allowed, reason)
            local line = "[Imperial Order v255] live CAMI callback: " .. tostring(allowed == true) .. " (" .. tostring(reason or "") .. ")"
            if SERVER and IsValid(client) then
                client:PrintMessage(HUD_PRINTCONSOLE, line .. "\n")
            else
                print(line)
            end
        end)
    end
end)
