if (not CLIENT) then return end

-- Imperial Order v212
-- Replaces Helix's stock purple intro with a minimal Imperial terminal splash.

local TITLE = "Imperial Order"
local AUTHOR = "1mmortalon3"

local function ForceSchemaCredit()
    local schemaTable = Schema or SCHEMA

    if schemaTable then
        schemaTable.author = AUTHOR
        Schema = schemaTable
        SCHEMA = schemaTable
    end

    if (GM) then GM.Author = AUTHOR end
    if (GAMEMODE) then GAMEMODE.Author = AUTHOR end
end

ForceSchemaCredit()
hook.Add("Initialize", "IMPERIAL_ORDER.V212.ForceSchemaCredit", ForceSchemaCredit)
hook.Add("InitPostEntity", "IMPERIAL_ORDER.V212.ForceSchemaCredit.Client", ForceSchemaCredit)
hook.Add("OnReloaded", "IMPERIAL_ORDER.V212.ForceSchemaCredit.Reload", ForceSchemaCredit)

surface.CreateFont("IMPERIAL_ORDER.IntroTitle", {
    font = "Roboto",
    size = math.Clamp(math.floor(ScrH() * 0.058), 42, 74),
    weight = 900,
    antialias = true,
    extended = true
})

local function RebuildIntroFonts()
    surface.CreateFont("IMPERIAL_ORDER.IntroTitle", {
        font = "Roboto",
        size = math.Clamp(math.floor(ScrH() * 0.058), 42, 74),
        weight = 900,
        antialias = true,
        extended = true
    })
end
hook.Add("OnScreenSizeChanged", "IMPERIAL_ORDER.V212.RebuildIntroFonts", RebuildIntroFonts)

local PANEL = {}

function PANEL:Init()
    ForceSchemaCredit()

    if (IsValid(ix.gui.intro) and ix.gui.intro ~= self) then
        local previous = ix.gui.intro
        if (previous.Remove) then
            pcall(previous.Remove, previous, true)
        end
    end

    ix.gui.intro = self
    self.IMPERIAL_ORDERTerminalSplash = true
    self:SetSize(ScrW(), ScrH())
    self:SetPos(0, 0)
    self:SetZPos(99999)
    self:MakePopup()
    self:SetAlpha(255)

    self.startTime = SysTime()
    self.readyTime = self.startTime + 1.25
    self.autoCloseTime = self.startTime + 5.5
    self.scanOffset = 0
    self.bClosing = false

    if (ix and ix.option and ix.option.Set) then
        pcall(ix.option.Set, "showIntro", false)
    end

    surface.PlaySound("buttons/combine_button1.wav")

    -- Hard failsafe: never allow the branded intro to trap the player on-screen.
    local panel = self
    timer.Simple(8, function()
        if IsValid(panel) then
            panel:SetMouseInputEnabled(false)
            panel:SetKeyboardInputEnabled(false)
            panel:Remove()
        end
    end)
end

function PANEL:Think()
    if (self.bClosing) then return end

    self.scanOffset = (self.scanOffset + FrameTime() * 95) % 48

    if (SysTime() >= self.autoCloseTime) then
        self:CloseTerminal()
    end
end

local function DrawCorner(x, y, sx, sy, length, thickness, color)
    local horizontalX = sx < 0 and x - length or x
    local horizontalY = sy < 0 and y - thickness or y
    local verticalX = sx < 0 and x - thickness or x
    local verticalY = sy < 0 and y - length or y

    surface.SetDrawColor(color)
    surface.DrawRect(horizontalX, horizontalY, length, thickness)
    surface.DrawRect(verticalX, verticalY, thickness, length)
end

function PANEL:Paint(width, height)
    local elapsed = SysTime() - self.startTime
    local reveal = math.Clamp((elapsed - 0.35) / 1.35, 0, 1)
    local pulse = 0.55 + math.sin(SysTime() * 2.2) * 0.18

    surface.SetDrawColor(2, 3, 5, 255)
    surface.DrawRect(0, 0, width, height)

    -- Subtle terminal grid.
    surface.SetDrawColor(110, 8, 14, 35)
    local grid = math.max(48, math.floor(width / 30))
    for x = 0, width, grid do
        surface.DrawLine(x, 0, x, height)
    end
    for y = 0, height, grid do
        surface.DrawLine(0, y, width, y)
    end

    -- Animated scanlines.
    surface.SetDrawColor(205, 20, 28, 20)
    for y = -48 + self.scanOffset, height, 48 do
        surface.DrawRect(0, y, width, 1)
    end

    local frameW = math.min(width * 0.74, 1260)
    local frameH = math.min(height * 0.42, 430)
    local frameX = width * 0.5 - frameW * 0.5
    local frameY = height * 0.5 - frameH * 0.5
    local red = Color(182, 16, 23, math.floor(215 * pulse))
    local dimRed = Color(84, 7, 12, 190)

    surface.SetDrawColor(7, 9, 12, 238)
    surface.DrawRect(frameX, frameY, frameW, frameH)
    surface.SetDrawColor(dimRed)
    surface.DrawOutlinedRect(frameX, frameY, frameW, frameH, 1)

    local corner = math.max(28, math.floor(frameW * 0.035))
    local thick = 3
    DrawCorner(frameX, frameY, 1, 1, corner, thick, red)
    DrawCorner(frameX + frameW, frameY, -1, 1, corner, thick, red)
    DrawCorner(frameX, frameY + frameH, 1, -1, corner, thick, red)
    DrawCorner(frameX + frameW, frameY + frameH, -1, -1, corner, thick, red)

    surface.SetDrawColor(150, 14, 20, 110)
    surface.DrawRect(frameX + 22, frameY + frameH * 0.5, frameW - 44, 1)

    local logo = Material("imperial_order_ui/imperial_order_crest.png", "smooth noclamp")
    local logoSize = math.min(frameH * 0.78, 330)
    if (logo and not logo:IsError()) then
        surface.SetMaterial(logo)
        surface.SetDrawColor(255, 255, 255, math.floor(255 * reveal))
        surface.DrawTexturedRect(width * 0.5 - logoSize * 0.5, frameY + frameH * 0.5 - logoSize * 0.5, logoSize, logoSize)
    else
        draw.SimpleText(
            TITLE,
            "IMPERIAL_ORDER.IntroTitle",
            width * 0.5,
            frameY + frameH * 0.5,
            Color(239, 241, 244, math.floor(255 * reveal)),
            TEXT_ALIGN_CENTER,
            TEXT_ALIGN_CENTER
        )
    end

    surface.SetDrawColor(178, 16, 23, math.floor(125 * pulse))
    surface.DrawRect(0, 0, width, 3)
    surface.DrawRect(0, height - 3, width, 3)
end

function PANEL:CloseTerminal()
    if (self.bClosing) then return end
    self.bClosing = true
    self:SetMouseInputEnabled(false)
    self:SetKeyboardInputEnabled(false)

    self:AlphaTo(0, 0.55, 0, function()
        if (IsValid(self)) then
            self:Remove()
        end
    end)
end

function PANEL:OnKeyCodePressed()
    if (SysTime() >= self.readyTime) then
        self:CloseTerminal()
    end
end

function PANEL:OnMousePressed()
    if (SysTime() >= self.readyTime) then
        self:CloseTerminal()
    end
end

function PANEL:OnRemove()
    if (ix and ix.gui and ix.gui.intro == self) then
        ix.gui.intro = nil
    end

    if (ix and ix.gui and IsValid(ix.gui.characterMenu) and ix.gui.characterMenu.PlayMusic) then
        pcall(ix.gui.characterMenu.PlayMusic, ix.gui.characterMenu)
    end
end

vgui.Register("ixIntro", PANEL, "EditablePanel")

-- If Helix created the stock intro before this schema file finished loading,
-- replace that existing instance with the terminal version.
timer.Create("IMPERIAL_ORDER.V212.ReplaceExistingIntro", 0.1, 60, function()
    if (not ix or not ix.gui) then return end

    if (IsValid(ix.gui.intro)) then
        if (ix.gui.intro.IMPERIAL_ORDERTerminalSplash) then
            timer.Remove("IMPERIAL_ORDER.V212.ReplaceExistingIntro")
            return
        end

        local previous = ix.gui.intro
        if (previous.Remove) then
            pcall(previous.Remove, previous, true)
        end

        vgui.Create("ixIntro")
        timer.Remove("IMPERIAL_ORDER.V212.ReplaceExistingIntro")
    end
end)

concommand.Add("imperial_order_show_splash", function()
    if (IsValid(ix.gui.intro)) then
        ix.gui.intro:Remove()
    end
    vgui.Create("ixIntro")
end)
