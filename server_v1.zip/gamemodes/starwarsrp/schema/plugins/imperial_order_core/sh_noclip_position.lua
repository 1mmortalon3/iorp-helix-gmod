-- Imperial Order V187
-- Keep the player's current position when noclip/admin flight is disabled.
-- Some admin-mode addons save the position from before noclip and restore it on exit.
-- This file makes the exit location authoritative instead.

if not SERVER then return end
if IMPERIAL_ORDER_NOCLIP_EXIT_POSITION_V187 then return end
IMPERIAL_ORDER_NOCLIP_EXIT_POSITION_V187 = true

local keepPosition = CreateConVar(
    "imperial_order_noclip_keep_exit_position",
    "1",
    FCVAR_ARCHIVE,
    "Keep players at their current location when noclip is disabled instead of returning them to their pre-noclip position."
)

local tracked = setmetatable({}, {__mode = "k"})
local pending = setmetatable({}, {__mode = "k"})

local function copyVector(value)
    return Vector(value.x, value.y, value.z)
end

local function copyAngle(value)
    -- Player eye roll should remain level. Preserving a non-zero roll here can
    -- leave both first- and third-person cameras permanently tilted after noclip.
    return Angle(value.p, value.y, 0)
end

local function rememberNoclipPosition(client)
    if not IsValid(client) or not client:IsPlayer() then return end

    tracked[client] = tracked[client] or {}
    local data = tracked[client]
    data.wasNoclip = true
    data.position = copyVector(client:GetPos())
    data.eyeAngles = copyAngle(client:EyeAngles())
end

local function applyExitPosition(client, token)
    if not keepPosition:GetBool() then return end
    if not IsValid(client) or not client:IsPlayer() then return end
    if pending[client] ~= token then return end
    if client:GetMoveType() == MOVETYPE_NOCLIP then return end

    -- SetPos after the noclip/admin command completes. This intentionally wins over
    -- addons that restore a saved pre-noclip location when flight mode is disabled.
    client:SetPos(token.position)
    client:SetEyeAngles(token.eyeAngles)
    client:SetLocalVelocity(vector_origin)
end

local function preserveExitPosition(client, position, eyeAngles)
    if not keepPosition:GetBool() then return end
    if not IsValid(client) or not client:IsPlayer() then return end

    local token = {
        position = copyVector(position or client:GetPos()),
        eyeAngles = copyAngle(eyeAngles or client:EyeAngles())
    }

    pending[client] = token

    -- Run once on the next server frame and once shortly afterward. The second pass
    -- handles admin addons that perform their old-position restore in a zero-delay timer.
    timer.Simple(0, function()
        applyExitPosition(client, token)
    end)

    timer.Simple(0.06, function()
        applyExitPosition(client, token)
        if IsValid(client) and pending[client] == token then
            pending[client] = nil
        end
    end)
end

-- Standard sandbox/ULX-style noclip path. This hook runs before the movement type
-- changes, so GetPos() is the exact place where the player switched noclip off.
hook.Add("PlayerNoClip", "IMPERIAL_ORDER.V187.KeepNoclipExitPosition", function(client, desiredState)
    if desiredState == true then
        rememberNoclipPosition(client)
        return
    end

    if desiredState == false and IsValid(client) then
        local data = tracked[client]
        if data then
            data.wasNoclip = false
        end

        preserveExitPosition(client, client:GetPos(), client:EyeAngles())
    end
end)

-- Fallback for admin systems that call SetMoveType directly and never invoke
-- PlayerNoClip. SetupMove remembers the last confirmed position while flying and
-- detects the first movement command after the player returns to walking.
hook.Add("SetupMove", "IMPERIAL_ORDER.V187.TrackDirectNoclipTransitions", function(client)
    if not keepPosition:GetBool() then return end
    if not IsValid(client) or not client:IsPlayer() then return end

    local data = tracked[client]
    local isNoclip = client:GetMoveType() == MOVETYPE_NOCLIP

    if isNoclip then
        rememberNoclipPosition(client)
        return
    end

    if data and data.wasNoclip then
        data.wasNoclip = false

        if data.position then
            preserveExitPosition(client, data.position, data.eyeAngles)
        end
    end
end)

hook.Add("PlayerSpawn", "IMPERIAL_ORDER.V187.ClearNoclipExitState", function(client)
    tracked[client] = nil
    pending[client] = nil
end)

hook.Add("PlayerDisconnected", "IMPERIAL_ORDER.V187.ClearNoclipExitState.Disconnect", function(client)
    tracked[client] = nil
    pending[client] = nil
end)
