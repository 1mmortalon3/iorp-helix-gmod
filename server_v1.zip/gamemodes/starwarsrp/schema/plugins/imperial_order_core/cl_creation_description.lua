IMPERIAL_ORDER_UI_LOADED = IMPERIAL_ORDER_UI_LOADED or {}
IMPERIAL_ORDER_UI_LOADED.character_creation_description_removed_v115 = true

-- V115: Remove/hide the default Helix description field from character creation.
-- The server now auto-generates a safe default personnel record, so players only
-- need to choose designation, department/class, and model.

local function SafeClass(panel)
    return IsValid(panel) and panel.GetClassName and panel:GetClassName() or ""
end

local function PanelText(panel)
    if not IsValid(panel) or not panel.GetText then return "" end
    local ok, value = pcall(panel.GetText, panel)
    return ok and tostring(value or "") or ""
end

local function IsCharacterMenuPanel(panel)
    if not IsValid(panel) then return false end
    local parent = panel
    while IsValid(parent) do
        local class = string.lower(SafeClass(parent))
        if string.find(class, "ixcharmenu", 1, true) or string.find(class, "character", 1, true) then return true end
        if ix and ix.gui and IsValid(ix.gui.characterMenu) and parent == ix.gui.characterMenu then return true end
        parent = parent:GetParent()
    end
    return false
end

local descWords = {
    "description",
    "bio-record",
    "bio record",
    "service record / description",
    "physical description"
}

local function LooksLikeDescriptionControl(panel)
    if not IsValid(panel) or not IsCharacterMenuPanel(panel) then return false end
    local class = SafeClass(panel)
    local text = string.lower(string.Trim(PanelText(panel)))

    for _, word in ipairs(descWords) do
        if text ~= "" and string.find(text, word, 1, true) then return true end
    end

    if class == "DTextEntry" then
        local placeholder = ""
        if panel.GetPlaceholderText then
            local ok, value = pcall(panel.GetPlaceholderText, panel)
            if ok then placeholder = string.lower(tostring(value or "")) end
        end
        for _, word in ipairs(descWords) do
            if placeholder ~= "" and string.find(placeholder, word, 1, true) then return true end
        end
        if panel.GetMultiline and panel:GetMultiline() then return true end
        if panel:GetTall() and panel:GetTall() > 64 then return true end
    end

    return false
end

local function HideDescriptionControls(panel)
    if not IsValid(panel) then return end

    if LooksLikeDescriptionControl(panel) then
        panel.IMPERIAL_ORDERDescriptionHiddenV115 = true
        if panel.SetText then pcall(panel.SetText, panel, "") end
        if panel.SetValue then pcall(panel.SetValue, panel, "Imperial personnel record.") end
        panel:SetVisible(false)
        panel:SetMouseInputEnabled(false)
        panel:SetKeyboardInputEnabled(false)
        if panel.SetTall then panel:SetTall(0) end
        if panel.SetZPos then panel:SetZPos(-10000) end
    end

    for _, child in ipairs(panel.GetChildren and panel:GetChildren() or {}) do
        HideDescriptionControls(child)
    end
end

local function ApplyDescriptionRemoval()
    if ix and ix.gui and IsValid(ix.gui.characterMenu) then
        HideDescriptionControls(ix.gui.characterMenu)
    end

    local world = vgui.GetWorldPanel and vgui.GetWorldPanel() or nil
    if IsValid(world) then
        for _, child in ipairs(world:GetChildren() or {}) do
            if IsValid(child) and IsCharacterMenuPanel(child) then
                HideDescriptionControls(child)
            end
        end
    end
end

hook.Add("OnCharacterMenuCreated", "IMPERIAL_ORDER.RemoveDescriptionV115", function()
    timer.Simple(0, ApplyDescriptionRemoval)
    timer.Simple(0.2, ApplyDescriptionRemoval)
    timer.Simple(0.8, ApplyDescriptionRemoval)
end)

hook.Add("MenuSubpanelCreated", "IMPERIAL_ORDER.RemoveDescriptionV115.Subpanel", function(_, panel)
    timer.Simple(0, function()
        if IsValid(panel) then HideDescriptionControls(panel) end
        ApplyDescriptionRemoval()
    end)
end)

-- V157: no permanent Think scan; menu/subpanel creation hooks above handle this.
