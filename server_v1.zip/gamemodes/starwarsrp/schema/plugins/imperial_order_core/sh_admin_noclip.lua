-- Imperial Order v226
-- Restricts noclip to administrators and blocks addons from putting normal users
-- into MOVETYPE_NOCLIP directly.

if CLIENT then return end
if IMPERIAL_ORDER_ADMIN_ONLY_NOCLIP_V226 then return end
IMPERIAL_ORDER_ADMIN_ONLY_NOCLIP_V226 = true

local adminOnly = CreateConVar(
    "imperial_order_noclip_admin_only",
    "1",
    bit.bor(FCVAR_ARCHIVE, FCVAR_NOTIFY),
    "Restrict noclip to admins and superadmins."
)

local lastLegalPosition = setmetatable({}, {__mode = "k"})

local function canNoclip(client)
    if not adminOnly:GetBool() then return true end
    if not IsValid(client) or not client:IsPlayer() then return false end
    return client:IsAdmin() or client:IsSuperAdmin()
end

-- Always allow players to leave noclip. Only deny entering it.
hook.Add("PlayerNoClip", "IMPERIAL_ORDER.V226.AdminOnlyNoclip", function(client, desiredState)
    if desiredState == false then return end
    if not canNoclip(client) then
        return false
    end
end)

-- Some admin/utility addons bypass PlayerNoClip and call SetMoveType directly.
-- This server-side guard removes unauthorized noclip on the next movement tick.
hook.Add("SetupMove", "IMPERIAL_ORDER.V226.BlockDirectNoclip", function(client)
    if not IsValid(client) or not client:IsPlayer() or not client:Alive() then return end

    if client:GetMoveType() ~= MOVETYPE_NOCLIP then
        if not client:InVehicle() then
            lastLegalPosition[client] = client:GetPos()
        end
        return
    end

    if canNoclip(client) then return end

    client:SetMoveType(MOVETYPE_WALK)
    client:SetMoveCollide(MOVECOLLIDE_DEFAULT)
    client:SetLocalVelocity(vector_origin)

    local position = lastLegalPosition[client]
    if isvector(position) then
        client:SetPos(position)
    end
end)

hook.Add("PlayerSpawn", "IMPERIAL_ORDER.V226.ResetNoclipGuard", function(client)
    lastLegalPosition[client] = client:GetPos()
end)

hook.Add("PlayerDisconnected", "IMPERIAL_ORDER.V226.ClearNoclipGuard", function(client)
    lastLegalPosition[client] = nil
end)
