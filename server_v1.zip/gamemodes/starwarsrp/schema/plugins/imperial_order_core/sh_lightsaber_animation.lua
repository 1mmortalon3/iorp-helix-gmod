-- Imperial Order V254
-- Custom SWEP animation ownership helper.
--
-- Older releases wrapped generic T-pose repair functions that no longer exist.
-- V254 keeps only lightweight detection/status helpers and does not alter any
-- player activities, hold types, sequences, gestures, bones, or SWEP methods.

IMPERIAL_ORDER = IMPERIAL_ORDER or {}
IMPERIAL_ORDER_LOADED = IMPERIAL_ORDER_LOADED or {}

if IMPERIAL_ORDER_CUSTOM_SWEP_ANIMATION_ISOLATION_V254 then return end
IMPERIAL_ORDER_CUSTOM_SWEP_ANIMATION_ISOLATION_V254 = true
IMPERIAL_ORDER_LOADED.custom_swep_animation_isolation_v254 = true

local function Lower(value)
    return string.lower(string.Trim(tostring(value or "")))
end

local function ContainsSaberIdentifier(value)
    value = Lower(value)
    if value == "" then return false end

    return string.find(value, "lightsaber", 1, true) ~= nil
        or string.find(value, "light_saber", 1, true) ~= nil
        or string.find(value, "wos_adv_dcrs", 1, true) ~= nil
        or string.find(value, "wos_lightsaber", 1, true) ~= nil
        or string.find(value, "_saber", 1, true) ~= nil
        or string.sub(value, 1, 6) == "saber_"
        or value == "weapon_saber"
end

local function ReadWeaponValue(weapon, key)
    if not IsValid(weapon) then return nil end

    local direct = weapon[key]
    if direct ~= nil then return direct end

    local stored = weapons and weapons.GetStored and weapons.GetStored(weapon:GetClass()) or nil
    if istable(stored) then
        return stored[key]
    end

    return nil
end

function IMPERIAL_ORDER.IsLightsaberWeaponV254(weapon)
    if not IsValid(weapon) then return false end

    for _, value in ipairs({
        weapon.GetClass and weapon:GetClass() or "",
        ReadWeaponValue(weapon, "Base"),
        ReadWeaponValue(weapon, "Category"),
        ReadWeaponValue(weapon, "PrintName")
    }) do
        if ContainsSaberIdentifier(value) then
            return true
        end
    end

    for _, key in ipairs({
        "IsLightsaber",
        "Lightsaber",
        "LightSaber",
        "IsSaber",
        "Saber",
        "wOSLightsaber",
        "WOSLightsaber"
    }) do
        local value = ReadWeaponValue(weapon, key)

        if value == true then
            return true
        end

        if isfunction(value) then
            local ok, result = pcall(value, weapon)
            if ok and result == true then
                return true
            end
        end
    end

    return false
end

function IMPERIAL_ORDER.PlayerUsingLightsaberV254(client)
    if not IsValid(client) or not client:IsPlayer() then return false end
    return IMPERIAL_ORDER.IsLightsaberWeaponV254(client:GetActiveWeapon())
end

-- Backwards-compatible names for any external Imperial Order code that reads these
-- helpers. They are detection functions only and do not install animation hooks.
IMPERIAL_ORDER.IsLightsaberWeaponV188 = IMPERIAL_ORDER.IsLightsaberWeaponV254
IMPERIAL_ORDER.PlayerUsingLightsaberV188 = IMPERIAL_ORDER.PlayerUsingLightsaberV254

for _, hookName in ipairs({
    "IMPERIAL_ORDER.V188.LightsaberAnimationTransition",
    "IMPERIAL_ORDER.V188.LightsaberAnimationEquip",
    "IMPERIAL_ORDER.V188.LightsaberAnimationCleanup",
    "IMPERIAL_ORDER.V188.InstallLightsaberAnimationGuards",
    "IMPERIAL_ORDER.V188.ReinstallLightsaberAnimationGuards"
}) do
    hook.Remove("PlayerSwitchWeapon", hookName)
    hook.Remove("WeaponEquip", hookName)
    hook.Remove("PlayerDisconnected", hookName)
    hook.Remove("InitializedPlugins", hookName)
    hook.Remove("OnReloaded", hookName)
end

if SERVER then
    local function PrintStatus(client)
        local targets = IsValid(client) and {client} or player.GetAll()

        for _, target in ipairs(targets) do
            local weapon = target:GetActiveWeapon()
            local class = IsValid(weapon) and weapon:GetClass() or "none"
            local detected = IMPERIAL_ORDER.PlayerUsingLightsaberV254(target)
            local message = string.format(
                "[Imperial Order V254] %s | active=%s | customSaber=%s | animationOwner=SWEP",
                target:Nick(),
                class,
                tostring(detected)
            )

            if IsValid(client) and client.PrintMessage then
                client:PrintMessage(HUD_PRINTCONSOLE, message)
            else
                print(message)
            end
        end
    end

    concommand.Remove("imperial_order_lightsaber_anim_status_v188")
    concommand.Remove("imperial_order_lightsaber_anim_status_v254")
    concommand.Add("imperial_order_lightsaber_anim_status_v188", PrintStatus)
    concommand.Add("imperial_order_lightsaber_anim_status_v254", PrintStatus)
end
