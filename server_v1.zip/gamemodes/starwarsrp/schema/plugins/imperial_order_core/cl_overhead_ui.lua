IMPERIAL_ORDER_UI_LOADED = IMPERIAL_ORDER_UI_LOADED or {}
IMPERIAL_ORDER_UI_LOADED.overhead_ui_v115 = true
IMPERIAL_ORDER_UI_LOADED.overhead_ui_v117 = true

-- V117: Clean Imperial overhead player HUD.
-- This replaces the older 3D2D panel with a screen-space nameplate that stays
-- directly above the player's head and does not tilt/float away from them.

if SERVER then return end

hook.Remove("PostPlayerDraw", "IMPERIAL_ORDER.OverheadUIV115")
hook.Remove("HUDPaint", "IMPERIAL_ORDER.OverheadUIV115")
hook.Remove("HUDPaint", "IMPERIAL_ORDER.OverheadUIV117")
hook.Remove("ShouldDrawPlayerInfo", "IMPERIAL_ORDER.OverheadUIV115.SuppressDefault")
hook.Remove("ShouldDrawPlayerInfo", "IMPERIAL_ORDER.OverheadUIV117.SuppressDefault")
hook.Remove("CanDrawCharInfo", "IMPERIAL_ORDER.OverheadUIV117.SuppressHelix")

surface.CreateFont("IMPERIAL_ORDER.OverheadV117.Name", {
    font = "Trebuchet MS",
    size = 18,
    weight = 1000,
    antialias = true,
    extended = true
})

surface.CreateFont("IMPERIAL_ORDER.OverheadV117.Role", {
    font = "Trebuchet MS",
    size = 12,
    weight = 850,
    antialias = true,
    extended = true
})

surface.CreateFont("IMPERIAL_ORDER.OverheadV117.Small", {
    font = "Trebuchet MS",
    size = 11,
    weight = 850,
    antialias = true,
    extended = true
})

local enabled = CreateClientConVar("imperial_order_overhead_enabled", "1", true, false, "Enable the Imperial overhead player HUD.")
local maxDistance = CreateClientConVar("imperial_order_overhead_distance", "850", true, false, "Maximum distance for Imperial overhead player HUD.")
local updateRate = CreateClientConVar("imperial_order_overhead_update_rate", "0.12", true, false, "Seconds between overhead visibility/distance updates.", 0.06, 0.5)
local maxVisible = CreateClientConVar("imperial_order_overhead_max_visible", "18", true, false, "Maximum overhead nameplates drawn at once.", 4, 64)

local function Col(name, fallback)
    if IMPERIAL_ORDERUI and IMPERIAL_ORDERUI.Col then
        local c = IMPERIAL_ORDERUI.Col(name, fallback)
        if c then return c end
    end

    if IMPERIAL_ORDER_COLORS and IMPERIAL_ORDER_COLORS[name] then
        return IMPERIAL_ORDER_COLORS[name]
    end

    return fallback or color_white
end

local function SafeText(text, fallback)
    text = string.Trim(tostring(text or ""))
    if text == "" then return fallback end
    return text
end

local function GetChar(ply)
    if not IsValid(ply) or type(ply.GetCharacter) ~= "function" then return nil end

    local ok, char = pcall(ply.GetCharacter, ply)
    if ok then return char end

    return nil
end

local function CallChar(char, method, fallback)
    if not char or type(char[method]) ~= "function" then return fallback end

    local ok, value = pcall(char[method], char)
    if ok and value ~= nil then return value end

    return fallback
end

local function TextWidth(text, font)
    surface.SetFont(font)
    local w = surface.GetTextSize(tostring(text or ""))
    return w or 0
end

local function FitText(text, font, maxW)
    text = SafeText(text, "")

    if TextWidth(text, font) <= maxW then
        return text
    end

    local result = "..."
    for i = 1, #text do
        local test = string.sub(text, 1, i) .. "..."
        if TextWidth(test, font) > maxW then
            return result
        end

        result = test
    end

    return result
end

local function GetOverheadName(ply)
    local char = GetChar(ply)
    local name = CallChar(char, "GetName", nil)

    if not name and ply.Name then
        name = ply:Name()
    end

    return SafeText(name, "Imperial Operative")
end

local function GetOverheadRole(ply)
    local serverRank = IMPERIAL_ORDER and IMPERIAL_ORDER.GetServerRankLabel and IMPERIAL_ORDER.GetServerRankLabel(ply)
        or string.upper(tostring((ply.GetUserGroup and ply:GetUserGroup()) or "user"))
    local char = GetChar(ply)
    if not char then return serverRank .. " | UNASSIGNED" end

    local factionName = "Imperial Order"
    local className = "Operative"

    local factionID = CallChar(char, "GetFaction", nil)
    if ix and ix.faction and ix.faction.indices and factionID and ix.faction.indices[factionID] then
        factionName = ix.faction.indices[factionID].name or factionName
    end

    local classID = CallChar(char, "GetClass", nil)
    if ix and ix.class and ix.class.list and classID and ix.class.list[classID] then
        className = ix.class.list[classID].name or className
    end

    return SafeText(serverRank .. " | " .. string.upper(tostring(className)), "PLAYER | OPERATIVE")
end

local playerDataCache = setmetatable({}, {__mode = "k"})
local visibilityCache = setmetatable({}, {__mode = "k"})
local headHeightCache = setmetatable({}, {__mode = "k"})
local cachedPlayers = {}
local nextPlayerListRefresh = 0

local function GetCachedPlayers()
    local now = CurTime()
    if now >= nextPlayerListRefresh then
        nextPlayerListRefresh = now + 0.25
        cachedPlayers = player.GetAll()
    end
    return cachedPlayers
end

local function GetCachedPlayerData(ply)
    local now = CurTime()
    local cached = playerDataCache[ply]
    if cached and cached.expires > now then return cached end

    local name = FitText(GetOverheadName(ply), "IMPERIAL_ORDER.OverheadV117.Name", 210)
    local role = FitText(GetOverheadRole(ply), "IMPERIAL_ORDER.OverheadV117.Role", 240)

    -- Certification badges are supplied by the certifications plugin, if it is
    -- installed. Resolved here so it shares this cache instead of running per
    -- frame; absent plugin simply yields nil and the plate renders as before.
    local certs
    if (isfunction(IMPERIAL_ORDER_GetOverheadCertifications)) then
        local ok, result = pcall(IMPERIAL_ORDER_GetOverheadCertifications, ply)
        if (ok and istable(result) and #result > 0) then
            certs = result

            surface.SetFont("IMPERIAL_ORDER.OverheadV117.Small")
            local total = 0
            for _, badge in ipairs(certs) do
                badge.w = surface.GetTextSize(badge.text) + 12
                total = total + badge.w + 4
            end
            certs.totalW = math.max(0, total - 4)
        end
    end

    cached = {
        expires = now + 1.25,
        name = name,
        role = role,
        certs = certs,
        nameW = TextWidth(name, "IMPERIAL_ORDER.OverheadV117.Name"),
        roleW = TextWidth(role, "IMPERIAL_ORDER.OverheadV117.Role")
    }
    playerDataCache[ply] = cached
    return cached
end

local function CanSeePlayer(localPlayer, ply)
    if not IsValid(localPlayer) or not IsValid(ply) then return false end

    local now = CurTime()
    local cached = visibilityCache[ply]
    if cached and cached.expires > now then return cached.visible end

    local tr = util.TraceLine({
        start = localPlayer:EyePos(),
        endpos = ply:EyePos(),
        filter = {localPlayer, ply},
        mask = MASK_VISIBLE_AND_NPCS
    })

    cached = {
        visible = not tr.Hit,
        expires = now + math.max(0.12, updateRate:GetFloat()) + ((ply:EntIndex() % 5) * 0.01)
    }
    visibilityCache[ply] = cached
    return cached.visible
end

local function GetHeadScreenPosition(ply)
    local now = CurTime()
    local cached = headHeightCache[ply]
    local headHeight
    if cached and cached.expires > now then
        headHeight = cached.height
    else
        local maxs = ply:OBBMaxs()
        headHeight = (maxs and maxs.z and maxs.z > 0) and maxs.z or 84
        headHeightCache[ply] = {height = headHeight, expires = now + 1.5}
    end

    local worldPos = ply:GetPos() + Vector(0, 0, headHeight + 12)
    local screenPos = worldPos:ToScreen()

    if not screenPos or screenPos.visible == false then return nil end

    local sw, sh = ScrW(), ScrH()
    if screenPos.x < -120 or screenPos.x > sw + 120 or screenPos.y < -120 or screenPos.y > sh + 120 then
        return nil
    end

    return screenPos
end

local function DrawNameplate(ply, data, x, y, alpha, scale)
    local name = data.name
    local role = data.role
    local certs = data.certs
    local certRow = certs and (18 * scale) or 0

    local contentW = math.max(data.nameW, data.roleW)
    if (certs) then contentW = math.max(contentW, certs.totalW) end

    local w = math.Clamp(contentW + 48, 160, 320) * scale
    local h = (56 * scale) + certRow

    x = math.floor(x)
    y = math.floor(y - h)

    local panelX = math.floor(x - (w / 2))
    local panelY = math.floor(y)
    local red = Col("red", Color(190, 38, 38))

    draw.RoundedBox(6, panelX, panelY, w, h, Color(4, 4, 6, math.floor(alpha * 0.76)))
    draw.RoundedBox(6, panelX + 2, panelY + 2, w - 4, h - 4, Color(22, 24, 28, math.floor(alpha * 0.82)))

    surface.SetDrawColor(red.r or 190, red.g or 38, red.b or 38, alpha)
    surface.DrawOutlinedRect(panelX, panelY, w, h, 1)
    surface.DrawRect(panelX, panelY, 4, h)
    surface.DrawRect(panelX + w - 4, panelY, 4, h)

    draw.SimpleTextOutlined(name, "IMPERIAL_ORDER.OverheadV117.Name", x, panelY + (15 * scale), Color(245, 247, 250, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, alpha))
    draw.SimpleText(role, "IMPERIAL_ORDER.OverheadV117.Role", x, panelY + (34 * scale), Color(190, 195, 205, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

    if (certs) then
        local chipY = math.floor(panelY + (42 * scale))
        local chipH = math.max(11, math.floor(14 * scale))
        local chipX = math.floor(x - ((certs.totalW * scale) / 2))

        surface.SetFont("IMPERIAL_ORDER.OverheadV117.Small")

        for _, badge in ipairs(certs) do
            local chipW = math.floor(badge.w * scale)
            local c = badge.color

            draw.RoundedBox(2, chipX, chipY, chipW, chipH,
                Color(c.r, c.g, c.b, math.floor(alpha * 0.22)))

            surface.SetDrawColor(c.r, c.g, c.b, math.floor(alpha * 0.85))
            surface.DrawOutlinedRect(chipX, chipY, chipW, chipH, 1)

            draw.SimpleText(badge.text, "IMPERIAL_ORDER.OverheadV117.Small",
                chipX + (chipW / 2), chipY + (chipH / 2),
                Color(c.r, c.g, c.b, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

            chipX = chipX + chipW + math.floor(4 * scale)
        end
    end

    local maxHP = math.max(ply:GetMaxHealth() or 100, 1)
    local hp = math.Clamp(ply:Health() or 0, 0, maxHP)
    local hpFrac = math.Clamp(hp / maxHP, 0, 1)

    local barW = math.max(20, math.floor(w - (38 * scale)))
    local barH = math.max(4, math.floor(5 * scale))
    local barX = math.floor(x - (barW / 2))
    local barY = math.floor(panelY + (45 * scale) + certRow)

    draw.RoundedBox(3, barX, barY, barW, barH, Color(0, 0, 0, math.floor(alpha * 0.7)))
    draw.RoundedBox(3, barX, barY, barW * hpFrac, barH, Color(red.r or 190, red.g or 38, red.b or 38, alpha))
end

local renderList = {}
local nextRenderListUpdate = 0

local function RefreshRenderList(localPlayer)
    local now = CurTime()
    if now < nextRenderListUpdate then return end
    nextRenderListUpdate = now + math.Clamp(updateRate:GetFloat(), 0.06, 0.5)

    local maxDist = math.Clamp(maxDistance:GetFloat(), 250, 1500)
    local maxDistSqr = maxDist * maxDist
    local localPos = localPlayer:GetPos()
    local candidates = {}

    for _, ply in ipairs(GetCachedPlayers()) do
        if IsValid(ply) and ply ~= localPlayer and ply:Alive() and not ply:IsDormant() then
            local distSqr = localPos:DistToSqr(ply:GetPos())
            if distSqr <= maxDistSqr and CanSeePlayer(localPlayer, ply) then
                candidates[#candidates + 1] = {
                    ply = ply,
                    distSqr = distSqr,
                    data = GetCachedPlayerData(ply)
                }
            end
        end
    end

    table.sort(candidates, function(a, b) return a.distSqr < b.distSqr end)
    renderList = {}
    local limit = math.Clamp(maxVisible:GetInt(), 4, 64)
    for i = 1, math.min(#candidates, limit) do renderList[i] = candidates[i] end
end

hook.Add("HUDPaint", "IMPERIAL_ORDER.OverheadUIV117", function()
    if not enabled:GetBool() then return end

    local localPlayer = LocalPlayer()
    if not IsValid(localPlayer) then return end
    RefreshRenderList(localPlayer)

    local maxDist = math.Clamp(maxDistance:GetFloat(), 250, 1500)
    for i = #renderList, 1, -1 do
        local item = renderList[i]
        local ply = item and item.ply
        if not IsValid(ply) or not ply:Alive() or ply:IsDormant() then
            table.remove(renderList, i)
        else
            local screenPos = GetHeadScreenPosition(ply)
            if screenPos then
                local dist = math.sqrt(localPlayer:GetPos():DistToSqr(ply:GetPos()))
                local fadeStart = maxDist * 0.55
                local fade = 1
                if dist > fadeStart then
                    fade = 1 - math.Clamp((dist - fadeStart) / math.max(maxDist - fadeStart, 1), 0, 1)
                end

                local alpha = math.Clamp(95 + (160 * fade), 80, 255)
                local scale = math.Clamp(1.08 - (dist / maxDist) * 0.28, 0.78, 1.08)
                DrawNameplate(ply, item.data or GetCachedPlayerData(ply), screenPos.x, screenPos.y, alpha, scale)
            end
        end
    end
end)

-- Suppress Helix/default overhead text so only the Imperial nameplate shows.
hook.Add("ShouldDrawPlayerInfo", "IMPERIAL_ORDER.OverheadUIV117.SuppressDefault", function()
    return false
end)

hook.Add("CanDrawCharInfo", "IMPERIAL_ORDER.OverheadUIV117.SuppressHelix", function()
    return false
end)

concommand.Add("imperial_order_overhead_refresh", function()
    print("[IMPERIAL_ORDER] Imperial overhead HUD is active. Set imperial_order_overhead_enabled 0/1 to toggle.")
end)
