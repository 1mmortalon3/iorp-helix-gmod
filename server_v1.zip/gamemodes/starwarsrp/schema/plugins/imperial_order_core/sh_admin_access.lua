IMPERIAL_ORDER_UI_LOADED = IMPERIAL_ORDER_UI_LOADED or {}
IMPERIAL_ORDER_UI_LOADED.admin_access_guard_v115 = true

-- V115: Server-authoritative admin UI access. This prevents the Imperial admin
-- command console from showing to normal players while still allowing real staff
-- groups to receive access even when clientside IsAdmin() is unreliable.

IMPERIAL_ORDER_ADMIN_ACCESS_NET_V115 = "IMPERIAL_ORDER.AdminAccess.SyncV115"

local staffGroups = {
    superadmin = true,
    admin = true,
    owner = true,
    founder = true,
    manager = true,
    moderator = true,
    mod = true,
    trialmod = true,
    ["trial moderator"] = true,
    senioradmin = true,
    ["senior admin"] = true,
    gamemaster = true,
    ["game master"] = true,
    staff = true
}

local function NormalizeGroup(group)
    group = string.lower(string.Trim(tostring(group or "")))
    group = string.Replace(group, "_", " ")
    group = string.Replace(group, "-", " ")
    return group
end

function IMPERIAL_ORDER_CanAccessAdminUI(client)
    if not IsValid(client) or not client:IsPlayer() then return false end
    if client:IsSuperAdmin() or client:IsAdmin() then return true end

    local group = ""
    if type(client.GetUserGroup) == "function" then
        local ok, value = pcall(client.GetUserGroup, client)
        if ok then group = NormalizeGroup(value) end
    end

    if group ~= "" then
        if staffGroups[group] then return true end
        local compact = string.Replace(group, " ", "")
        if staffGroups[compact] then return true end
    end

    return false
end

if SERVER then
    util.AddNetworkString(IMPERIAL_ORDER_ADMIN_ACCESS_NET_V115)

    local function SendAdminAccess(client)
        if not IsValid(client) then return end
        local group = "user"
        if type(client.GetUserGroup) == "function" then
            local ok, value = pcall(client.GetUserGroup, client)
            if ok and tostring(value or "") ~= "" then group = tostring(value) end
        end

        net.Start(IMPERIAL_ORDER_ADMIN_ACCESS_NET_V115)
        net.WriteBool(IMPERIAL_ORDER_CanAccessAdminUI(client) == true)
        net.WriteString(group)
        net.Send(client)
    end

    hook.Add("PlayerInitialSpawn", "IMPERIAL_ORDER.AdminAccessGuardV115.Initial", function(client)
        timer.Simple(1, function()
            if IsValid(client) then SendAdminAccess(client) end
        end)
    end)

    hook.Add("PlayerAuthed", "IMPERIAL_ORDER.AdminAccessGuardV115.Authed", function(client)
        timer.Simple(1, function()
            if IsValid(client) then SendAdminAccess(client) end
        end)
    end)

    concommand.Add("imperial_order_admin_access_refresh", function(client)
        if IsValid(client) then SendAdminAccess(client) end
    end)
else
    IMPERIAL_ORDER_ADMIN_ACCESS_V115 = IMPERIAL_ORDER_ADMIN_ACCESS_V115 or false
    IMPERIAL_ORDER_ADMIN_GROUP_V115 = IMPERIAL_ORDER_ADMIN_GROUP_V115 or "user"

    local function LocalFallbackAdmin()
        local client = LocalPlayer and LocalPlayer() or nil
        if not IsValid(client) then return false end
        return client:IsSuperAdmin() or client:IsAdmin()
    end

    function IMPERIAL_ORDER_HasAdminAccessV115()
        return IMPERIAL_ORDER_ADMIN_ACCESS_V115 == true or LocalFallbackAdmin()
    end

    function IMPERIAL_ORDER_AdminAccessDeniedV115()
        if ix and ix.util and ix.util.Notify then
            ix.util.Notify("Access denied. Imperial command console is staff-only.")
        else
            chat.AddText(Color(215, 42, 42), "[IMPERIAL_ORDER] ", Color(246, 247, 250), "Access denied. Imperial command console is staff-only.")
        end
    end

    net.Receive(IMPERIAL_ORDER_ADMIN_ACCESS_NET_V115, function()
        IMPERIAL_ORDER_ADMIN_ACCESS_V115 = net.ReadBool()
        IMPERIAL_ORDER_ADMIN_GROUP_V115 = net.ReadString()
    end)

    hook.Add("InitPostEntity", "IMPERIAL_ORDER.AdminAccessGuardV115.Request", function()
        timer.Simple(1, function()
            if RunConsoleCommand then RunConsoleCommand("imperial_order_admin_access_refresh") end
        end)
    end)
end
