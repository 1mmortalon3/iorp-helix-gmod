IMPERIAL_ORDER_UI_LOADED = IMPERIAL_ORDER_UI_LOADED or {}
IMPERIAL_ORDER_UI_LOADED.default_stamina_suppressed = true
IMPERIAL_ORDER_UI_LOADED.stamina_bar_hidden_v31 = true
IMPERIAL_ORDER_UI_LOADED.default_vitals_hidden_v42 = true
IMPERIAL_ORDER_UI_LOADED.helix_health_armor_hidden_v42 = true

local hiddenHud = {
    CHudHealth = true,
    CHudBattery = true,
    CHudSuitPower = true,
    CHudAmmo = true,
    CHudSecondaryAmmo = true,
    CHudDamageIndicator = true,
    CHudStamina = true
}

local blockedWords = {
    health = true,
    armor = true,
    armour = true,
    battery = true,
    stamina = true,
    suitpower = true,
    suit = true,
    stm = true,
    hp = true
}

local function HasBlockedWord(value)
    local text = string.lower(tostring(value or ""))
    if text == "" then return false end
    if blockedWords[text] then return true end
    for word in pairs(blockedWords) do
        if string.find(text, word, 1, true) then
            return true
        end
    end
    return false
end

hook.Add("HUDShouldDraw", "IMPERIAL_ORDER.SuppressDefaultVitalHUD", function(name)
    if hiddenHud[name] or HasBlockedWord(name) then
        return false
    end
end)

local function RemoveDefaultVitalBars()
    hook.Remove("HUDPaint", "ixBars")
    hook.Remove("HUDPaint", "ix.DrawBars")
    hook.Remove("HUDPaint", "ixCharacterBars")

    if ix and ix.bar then
        if ix.bar.Add and not IMPERIAL_ORDER_ORIGINAL_IX_BAR_ADD_V42 then
            IMPERIAL_ORDER_ORIGINAL_IX_BAR_ADD_V42 = ix.bar.Add
            ix.bar.Add = function(...)
                local args = {...}
                for _, value in ipairs(args) do
                    if isstring(value) and HasBlockedWord(value) then
                        return nil
                    end
                end
                return IMPERIAL_ORDER_ORIGINAL_IX_BAR_ADD_V42(...)
            end
        end
        if ix.bar.Remove then
            pcall(ix.bar.Remove, "stm")
            pcall(ix.bar.Remove, "stamina")
            pcall(ix.bar.Remove, "Stamina")
            pcall(ix.bar.Remove, "health")
            pcall(ix.bar.Remove, "Health")
            pcall(ix.bar.Remove, "hp")
            pcall(ix.bar.Remove, "HP")
            pcall(ix.bar.Remove, "armor")
            pcall(ix.bar.Remove, "Armor")
            pcall(ix.bar.Remove, "armour")
            pcall(ix.bar.Remove, "Armour")
            pcall(ix.bar.Remove, "battery")
            pcall(ix.bar.Remove, "Battery")
        end

        if istable(ix.bar.list) then
            for key, data in pairs(ix.bar.list) do
                local remove = false
                if HasBlockedWord(key) then
                    remove = true
                end
                if istable(data) then
                    if HasBlockedWord(data.name) or HasBlockedWord(data.text) or HasBlockedWord(data.id) or HasBlockedWord(data.uniqueID) then
                        remove = true
                    end
                end
                if remove then
                    ix.bar.list[key] = nil
                end
            end
        end
    end

    local world = vgui.GetWorldPanel and vgui.GetWorldPanel() or nil
    if not IsValid(world) then return end

    local stack = world:GetChildren() or {}
    while #stack > 0 do
        local panel = table.remove(stack)
        if IsValid(panel) then
            local class = panel.GetClassName and panel:GetClassName() or ""
            local name = panel.GetName and panel:GetName() or ""
            if HasBlockedWord(class) or HasBlockedWord(name) then
                panel:SetVisible(false)
                panel:SetAlpha(0)
                panel:SetMouseInputEnabled(false)
                panel:SetKeyboardInputEnabled(false)
            end

            local children = panel.GetChildren and panel:GetChildren() or nil
            if children then
                for _, child in ipairs(children) do
                    stack[#stack + 1] = child
                end
            end
        end
    end
end

hook.Add("InitPostEntity", "IMPERIAL_ORDER.RemoveDefaultVitalBarsInit", function()
    timer.Simple(0.05, RemoveDefaultVitalBars)
    timer.Simple(0.2, RemoveDefaultVitalBars)
    timer.Simple(1, RemoveDefaultVitalBars)
    timer.Simple(3, RemoveDefaultVitalBars)
end)

hook.Add("Think", "IMPERIAL_ORDER.RemoveDefaultVitalBarsThink", function()
    if not IMPERIAL_ORDER_NEXT_VITAL_REMOVE or IMPERIAL_ORDER_NEXT_VITAL_REMOVE < CurTime() then
        IMPERIAL_ORDER_NEXT_VITAL_REMOVE = CurTime() + 2
        RemoveDefaultVitalBars()
    end
end)

hook.Add("CharacterLoaded", "IMPERIAL_ORDER.RemoveDefaultVitalBarsCharacterLoaded", function()
    timer.Simple(0.1, RemoveDefaultVitalBars)
    timer.Simple(1, RemoveDefaultVitalBars)
end)

concommand.Add("imperial_order_hide_stamina", RemoveDefaultVitalBars)
concommand.Add("imperial_order_hide_default_bars", RemoveDefaultVitalBars)
