local IMPERIAL_ORDER_LANGUAGE_PATCH = {
    helix = "Imperial Order",
    schemaName = "Imperial Order",
    schemaDesc = "Imperial command, sector control, and military roleplay inside the Helix framework.",
    create = "Register Imperial Personnel",
    load = "Access Imperial Archive",
    ["return"] = "Return to Bridge",
    returnText = "Return to Bridge",
    returnToGame = "Return to Bridge",
    leave = "Leave Server",
    disconnect = "Leave Server",
    play = "Deploy Operative",
    character = "Operative",
    characters = "Personnel Files",
    name = "Identity",
    description = "Bio-Record",
    desc = "Bio-Record",
    model = "Model",
    faction = "Imperial Department",
    factions = "Imperial Departments",
    class = "Role",
    classes = "Roles",
    attribs = "Attributes",
    attributes = "Attributes",
    attribute = "Attribute",
    inventory = "Imperial Inventory",
    business = "Supply Terminal",
    scoreboard = "Imperial Roster",
    options = "Settings",
    help = "Command Index",
    money = "₹ Credits",
    currency = "₹ Credits",
    finish = "Deploy",
    deleteCharacter = "Delete Personnel File"
}

local function IMPERIAL_ORDERApplyLanguagePatch()
    if not ix or not ix.lang or not ix.lang.AddTable then return end

    ix.lang.AddTable("english", IMPERIAL_ORDER_LANGUAGE_PATCH)
    ix.lang.AddTable("en", IMPERIAL_ORDER_LANGUAGE_PATCH)
end

hook.Add("InitializedSchema", "IMPERIAL_ORDER.ApplyLanguagePatch", IMPERIAL_ORDERApplyLanguagePatch)
timer.Simple(0, IMPERIAL_ORDERApplyLanguagePatch)
