-- Imperial Order V254
-- Animation-safe raised-state synchronization.
--
-- This file deliberately does NOT replace Helix Player:SetWepRaised or
-- Player:ToggleWepRaised and does NOT run a repeating watchdog. It performs a
-- single Helix state sync after a weapon switch, then leaves hold types,
-- activities, sequences, gestures, IK, viewmodels, and attacks to the SWEP.

IMPERIAL_ORDER = IMPERIAL_ORDER or {}
IMPERIAL_ORDER_LOADED = IMPERIAL_ORDER_LOADED or {}

if IMPERIAL_ORDER_ALWAYS_RAISED_WEAPONS_V254 then return end
IMPERIAL_ORDER_ALWAYS_RAISED_WEAPONS_V254 = true
IMPERIAL_ORDER_LOADED.always_raised_weapons_v254 = true

if CLIENT then return end

local flags = FCVAR_ARCHIVE
if bit and bit.bor then
    flags = bit.bor(FCVAR_ARCHIVE, FCVAR_NOTIFY, FCVAR_REPLICATED)
end

local enabledConVar = GetConVar("imperial_order_weapons_always_raised")
if not enabledConVar then
    enabledConVar = CreateConVar(
        "imperial_order_weapons_always_raised",
        "1",
        flags,
        "Synchronize Helix's raised flag once after weapon changes without overriding SWEP animations."
    )
end

local excludedClasses = {
    ["ix_hands"] = true,
    ["mvp_perfecthands"] = true,
    ["ix_perfecthands"] = true,
    ["weapon_hands"] = true,
    ["hands"] = true,
    ["weapon_fists"] = true,
    ["weapon_physgun"] = true,
    ["weapon_physcannon"] = true,
    ["gmod_tool"] = true,
    ["gmod_camera"] = true,
    ["weapon_camera"] = true
}

local excludedFragments = {
    "perfecthands",
    "perfect_hands",
    "toolgun",
    "physgun",
    "physcannon",
    "gmod_camera"
}

local function Lower(value)
    return string.lower(string.Trim(tostring(value or "")))
end

local function HasExcludedFragment(value)
    value = Lower(value)
    if value == "" then return false end

    for _, fragment in ipairs(excludedFragments) do
        if string.find(value, fragment, 1, true) then
            return true
        end
    end

    return false
end

local function RestoreHelixMethods()
    local playerMeta = FindMetaTable("Player")
    if not playerMeta then return end

    -- V191/V250/V251 replaced these metatable methods. Restore the native
    -- functions during Lua reloads when references from the older patch exist.
    if isfunction(IMPERIAL_ORDER.OriginalSetWepRaisedV191) then
        playerMeta.SetWepRaised = IMPERIAL_ORDER.OriginalSetWepRaisedV191
    end

    if isfunction(IMPERIAL_ORDER.OriginalToggleWepRaisedV191) then
        playerMeta.ToggleWepRaised = IMPERIAL_ORDER.OriginalToggleWepRaisedV191
    end
end

RestoreHelixMethods()
timer.Simple(0, RestoreHelixMethods)

local function IsEligibleWeapon(weapon)
    if not IsValid(weapon) or not weapon:IsWeapon() then return false end

    local class = Lower(weapon:GetClass())
    if class == "" or excludedClasses[class] then
        return false
    end

    if HasExcludedFragment(class) then
        return false
    end

    -- Respect weapon bases that explicitly require a lowered state.
    if weapon.IsAlwaysLowered == true or weapon.NeverRaised == true then
        return false
    end

    return true
end

IMPERIAL_ORDER.IsAlwaysRaiseEligibleWeaponV254 = IsEligibleWeapon
IMPERIAL_ORDER.IsAlwaysRaiseEligibleWeaponV251 = IsEligibleWeapon
IMPERIAL_ORDER.IsAlwaysRaiseEligibleWeaponV191 = IsEligibleWeapon

local pendingTokens = setmetatable({}, {__mode = "k"})

local function CanSync(client, weapon)
    if not enabledConVar:GetBool() then return false end
    if not IsValid(client) or not client:IsPlayer() or not client:Alive() then return false end
    if client.GetCharacter and not client:GetCharacter() then return false end
    if client.IsRestricted and client:IsRestricted() then return false end
    if client:GetMoveType() == MOVETYPE_OBSERVER then return false end

    weapon = IsValid(weapon) and weapon or client:GetActiveWeapon()
    if client:GetActiveWeapon() ~= weapon then return false end

    return IsEligibleWeapon(weapon)
end

local function SyncRaisedOnce(client, weapon)
    if not CanSync(client, weapon) then return false end
    if not isfunction(client.SetWepRaised) then return false end

    -- Helix only receives its raised flag. The SWEP remains the sole owner of
    -- HoldType, TranslateActivity, CalcMainActivity, gestures, IK, and sequences.
    local ok = pcall(client.SetWepRaised, client, true, weapon)
    return ok
end

IMPERIAL_ORDER.ForceWeaponRaisedV254 = SyncRaisedOnce
IMPERIAL_ORDER.ForceWeaponRaisedV251 = SyncRaisedOnce
IMPERIAL_ORDER.ForceWeaponRaisedV191 = SyncRaisedOnce

local function QueueRaisedSync(client, expectedWeapon, delay)
    if not IsValid(client) then return end

    local token = (pendingTokens[client] or 0) + 1
    pendingTokens[client] = token

    timer.Simple(tonumber(delay) or 0.05, function()
        if not IsValid(client) or pendingTokens[client] ~= token then return end

        local active = client:GetActiveWeapon()
        if IsValid(expectedWeapon) and active ~= expectedWeapon then return end

        SyncRaisedOnce(client, active)
    end)
end

-- Remove every previous raised-state owner. This is important for lua_refresh;
-- a full restart is still recommended after replacing the schema.
local oldHookNames = {
    "IMPERIAL_ORDER.V191.InstallAlwaysRaisedGuards",
    "IMPERIAL_ORDER.V191.ReinstallAlwaysRaisedGuards",
    "IMPERIAL_ORDER.V191.RaiseOnWeaponSwitch",
    "IMPERIAL_ORDER.V191.RaiseOnWeaponEquip",
    "IMPERIAL_ORDER.V191.RaiseOnSpawn",
    "IMPERIAL_ORDER.V191.RaiseOnCharacterLoad",
    "IMPERIAL_ORDER.V191.RaiseAfterLoadout",
    "IMPERIAL_ORDER.V191.RaiseOnHelixWeaponChange",
    "IMPERIAL_ORDER.V251.InstallAlwaysRaisedGuards",
    "IMPERIAL_ORDER.V251.ReinstallAlwaysRaisedGuards",
    "IMPERIAL_ORDER.V251.RaiseOnWeaponSwitch",
    "IMPERIAL_ORDER.V251.RaiseOnWeaponEquip",
    "IMPERIAL_ORDER.V251.RaiseOnSpawn",
    "IMPERIAL_ORDER.V251.RaiseOnCharacterLoad",
    "IMPERIAL_ORDER.V251.RaiseAfterLoadout",
    "IMPERIAL_ORDER.V251.RaiseOnHelixWeaponChange",
    "IMPERIAL_ORDER.V254.RestoreHelixRaiseMethods",
    "IMPERIAL_ORDER.V254.RaiseOnWeaponSwitch",
    "IMPERIAL_ORDER.V254.RaiseOnHelixWeaponChange",
    "IMPERIAL_ORDER.V254.RaiseAfterLoadout",
    "IMPERIAL_ORDER.V254.RaiseOnCharacterLoad"
}

for _, hookName in ipairs(oldHookNames) do
    for _, eventName in ipairs({
        "InitializedPlugins",
        "OnReloaded",
        "PlayerSwitchWeapon",
        "WeaponEquip",
        "PlayerSpawn",
        "PlayerLoadedCharacter",
        "PostPlayerLoadout",
        "PlayerWeaponChanged"
    }) do
        hook.Remove(eventName, hookName)
    end
end

timer.Remove("IMPERIAL_ORDER.V191.AlwaysRaisedWatchdog")
timer.Remove("IMPERIAL_ORDER.V251.AlwaysRaisedWatchdog")
timer.Remove("IMPERIAL_ORDER.V254.AlwaysRaisedWatchdog")

hook.Add("InitializedPlugins", "IMPERIAL_ORDER.V254.RestoreHelixRaiseMethods", function()
    RestoreHelixMethods()
end)

hook.Add("OnReloaded", "IMPERIAL_ORDER.V254.RestoreHelixRaiseMethods", function()
    timer.Simple(0, RestoreHelixMethods)
end)

hook.Add("PlayerSwitchWeapon", "IMPERIAL_ORDER.V254.RaiseOnWeaponSwitch", function(client, oldWeapon, newWeapon)
    QueueRaisedSync(client, newWeapon, 0.05)
end)

hook.Add("PlayerWeaponChanged", "IMPERIAL_ORDER.V254.RaiseOnHelixWeaponChange", function(client, weapon)
    QueueRaisedSync(client, weapon, 0.05)
end)

hook.Add("PostPlayerLoadout", "IMPERIAL_ORDER.V254.RaiseAfterLoadout", function(client)
    QueueRaisedSync(client, nil, 0.1)
end)

hook.Add("PlayerLoadedCharacter", "IMPERIAL_ORDER.V254.RaiseOnCharacterLoad", function(client)
    QueueRaisedSync(client, nil, 0.15)
end)

local function PrintStatus(client)
    local targets = IsValid(client) and {client} or player.GetAll()

    for _, target in ipairs(targets) do
        local weapon = target:GetActiveWeapon()
        local class = IsValid(weapon) and weapon:GetClass() or "none"
        local holdType = IsValid(weapon) and isfunction(weapon.GetHoldType)
            and tostring(weapon:GetHoldType()) or "none"
        local eligible = IsEligibleWeapon(weapon)
        local raised = target.IsWepRaised and target:IsWepRaised() or false
        local line = string.format(
            "[Imperial Order V254] %s | active=%s | holdtype=%s | eligible=%s | raised=%s | mode=one-shot",
            target:Nick(),
            class,
            holdType,
            tostring(eligible),
            tostring(raised)
        )

        if IsValid(client) and client.PrintMessage then
            client:PrintMessage(HUD_PRINTCONSOLE, line)
        else
            print(line)
        end
    end
end

concommand.Remove("imperial_order_always_raised_status_v191")
concommand.Remove("imperial_order_always_raised_status_v251")
concommand.Remove("imperial_order_always_raised_status_v254")
concommand.Add("imperial_order_always_raised_status_v191", PrintStatus)
concommand.Add("imperial_order_always_raised_status_v251", PrintStatus)
concommand.Add("imperial_order_always_raised_status_v254", PrintStatus)
