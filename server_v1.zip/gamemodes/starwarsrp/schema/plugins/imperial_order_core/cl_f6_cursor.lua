if SERVER then return end

IMPERIAL_ORDER_UI_LOADED = IMPERIAL_ORDER_UI_LOADED or {}
IMPERIAL_ORDER_UI_LOADED.f6_cursor_fix_v249 = nil
IMPERIAL_ORDER_UI_LOADED.f6_cursor_removed = true

-- The F6 HUD edit cursor feature has been removed. Keep this file included so
-- installing over an existing copy also removes its old hooks during a reload.
hook.Remove("PlayerButtonDown", "IMPERIAL_ORDER.HUDEditKey")
hook.Remove("Think", "IMPERIAL_ORDER.HUDEditClicker")
hook.Remove("PlayerButtonDown", "IMPERIAL_ORDER.F6CursorFixV106.Button")
hook.Remove("PlayerBindPress", "IMPERIAL_ORDER.F6CursorFixV106.Bind")
hook.Remove("Think", "IMPERIAL_ORDER.F6CursorFixV106.Think")
hook.Remove("OnSpawnMenuOpen", "IMPERIAL_ORDER.F6CursorFixV106.QOpen")
hook.Remove("OnContextMenuOpen", "IMPERIAL_ORDER.F6CursorFixV106.COpen")
hook.Remove("OnSpawnMenuOpen", "IMPERIAL_ORDER.F6CursorFixV249.QOpen")
hook.Remove("OnContextMenuOpen", "IMPERIAL_ORDER.F6CursorFixV249.COpen")

concommand.Remove("imperial_order_hud_edit_on")
concommand.Remove("imperial_order_hud_edit_off")
concommand.Remove("imperial_order_f6_fix_cursor")

-- Clear an old editing session once, after the client files finish loading.
-- No key handler or cursor-maintenance loop is installed by this file.
timer.Simple(0, function()
    local ui = IMPERIAL_ORDERUI
    local editing = GetConVar("imperial_order_hud_editing")

    if editing then
        editing:SetBool(false)
    end

    if ui then
        if isfunction(ui.SetHUDEditing) then
            ui.SetHUDEditing(false)
        end

        ui.ActiveDrag = nil

        -- Use the existing guarded cleanup so menus and chat retain input.
        if isfunction(ui.ReleaseStaleGameMenuCursorV249) then
            ui.ReleaseStaleGameMenuCursorV249()
        end
    end
end)
