IMPERIAL_ORDER_UI_LOADED = IMPERIAL_ORDER_UI_LOADED or {}
IMPERIAL_ORDER_UI_LOADED.q_menu_fix_v249 = true
IMPERIAL_ORDER_UI_LOADED.q_menu_fix_v269_3 = true

-- V249: Q/C menu input ownership repair.
-- Garry's Mod already owns the cursor while the spawn/context menus are open.
-- Calling gui.EnableScreenClicker(true) here created a second owner that could
-- survive after Q was released, especially when the Imperial chatbox had also
-- called MakePopup. This file now observes the game menus instead of forcing
-- their cursor and only performs a guarded stale-cursor cleanup after closing.

IMPERIAL_ORDERUI = IMPERIAL_ORDERUI or {}
IMPERIAL_ORDERUI.GameMenuInput = IMPERIAL_ORDERUI.GameMenuInput or {
    spawnOpen = false,
    contextOpen = false,
    lastClose = 0
}

local STATE = IMPERIAL_ORDERUI.GameMenuInput

-- Clear the V103 hooks if this file is reloaded without a full reconnect.
hook.Remove("PlayerBindPress", "IMPERIAL_ORDER.QMenuFixV103.AllowQMenu")
hook.Remove("OnSpawnMenuOpen", "IMPERIAL_ORDER.QMenuFixV103.SpawnOpen")
hook.Remove("OnSpawnMenuClose", "IMPERIAL_ORDER.QMenuFixV103.SpawnClose")

local function panelVisible(panel)
    -- Some Helix/addon registries store non-panel metadata (including numeric
    -- IDs) alongside their panels. util.IsValid throws when given a number, so
    -- reject anything that is not a VGUI panel before calling IsValid.
    if not ispanel(panel) then return false end
    if not IsValid(panel) then return false end

    local ok, visible = pcall(panel.IsVisible, panel)
    return ok and visible == true
end

local function spawnMenuVisible()
    return panelVisible(g_SpawnMenu)
end

local function contextMenuVisible()
    return panelVisible(g_ContextMenu)
end

local function gameMenuVisible()
    return STATE.spawnOpen
        or STATE.contextOpen
        or spawnMenuVisible()
        or contextMenuVisible()
end

function IMPERIAL_ORDERUI.IsGameMenuInputOpenV249()
    return gameMenuVisible()
end

local function chatIsActive()
    local frame = ImperialUI and ImperialUI.ChatFrame or IMPERIAL_ORDER_CHATBOX_PANEL
    if not ispanel(frame) or not IsValid(frame) then return false end

    if frame.GetActive then
        local ok, active = pcall(frame.GetActive, frame)
        if ok and active == true then return true end
    end

    return frame.IUActive == true and frame:IsVisible()
end

local function hudEditActive()
    if IMPERIAL_ORDERUI and IMPERIAL_ORDERUI.IsHUDEditing then
        return IMPERIAL_ORDERUI.IsHUDEditing() == true
    end

    local cv = GetConVar("imperial_order_hud_editing")
    return cv and cv:GetBool() or false
end

local function knownInputPanelOpen()
    if gui.IsGameUIVisible and gui.IsGameUIVisible() then return true end
    if gameMenuVisible() then return true end
    if chatIsActive() then return true end
    if hudEditActive() then return true end

    local known = {
        IMPERIAL_ORDER_FULL_CUSTOM_F1,
        IMPERIAL_ORDER_JOBS_MENU_V102,
        IMPERIAL_ORDER_TICKET_MENU_V104,
        IMPERIAL_ORDER_F1_FALLBACK_V102,
        IMPERIAL_ORDER_F4_MENU,
        IMPERIAL_ORDER_WHITELIST_MENU,
        IMPERIAL_ORDER_MONEY_MENU
    }

    for _, panel in ipairs(known) do
        if panelVisible(panel) then return true end
    end

    if IMPERIAL_ORDERBodyGrouper and panelVisible(IMPERIAL_ORDERBodyGrouper.Frame) then
        return true
    end

    if ImperialUI then
        if panelVisible(ImperialUI.ActiveMenu)
            or panelVisible(ImperialUI.InventoryFrame)
            or panelVisible(ImperialUI.Scoreboard) then
            return true
        end
    end

    if ix and ix.gui then
        for key, panel in pairs(ix.gui) do
            if panelVisible(panel) then
                local name = string.lower(tostring(key or ""))
                if string.find(name, "character", 1, true)
                    or string.find(name, "menu", 1, true)
                    or string.find(name, "whitelist", 1, true)
                    or string.find(name, "inventory", 1, true) then
                    return true
                end
            end
        end
    end

    local focus = vgui.GetKeyboardFocus and vgui.GetKeyboardFocus() or nil
    if panelVisible(focus) then return true end

    return false
end

local function releaseStaleCursor()
    -- Run across a few frames because the spawn menu closes asynchronously.
    for _, delay in ipairs({0, 0.03, 0.10, 0.20}) do
        timer.Simple(delay, function()
            if knownInputPanelOpen() then return end
            gui.EnableScreenClicker(false)
        end)
    end
end

function IMPERIAL_ORDERUI.ReleaseStaleGameMenuCursorV249()
    releaseStaleCursor()
end

local function IsQMenuBind(bind)
    bind = string.lower(tostring(bind or ""))

    return string.find(bind, "+menu", 1, true)
        or string.find(bind, "gm_showspare1", 1, true)
        or string.find(bind, "+menu_context", 1, true)
end

hook.Add("PlayerBindPress", "IMPERIAL_ORDER.QMenuFixV249.AllowQMenu", function(_, bind, pressed)
    if not pressed then return end
    if IsQMenuBind(bind) then
        -- Never consume Q/C. Sandbox/spawnmenu remains the only menu owner.
        return nil
    end
end)

hook.Add("OnSpawnMenuOpen", "IMPERIAL_ORDER.QMenuFixV249.SpawnOpen", function()
    STATE.spawnOpen = true
    hook.Run("IMPERIAL_ORDERGameMenuInputOpened", "spawn")
    -- Do not call gui.EnableScreenClicker(true). Garry's Mod already does it.
end)

hook.Add("OnSpawnMenuClose", "IMPERIAL_ORDER.QMenuFixV249.SpawnClose", function()
    STATE.spawnOpen = false
    STATE.lastClose = RealTime()
    hook.Run("IMPERIAL_ORDERGameMenuInputClosed", "spawn")
    releaseStaleCursor()
end)

hook.Add("OnContextMenuOpen", "IMPERIAL_ORDER.QMenuFixV249.ContextOpen", function()
    STATE.contextOpen = true
    hook.Run("IMPERIAL_ORDERGameMenuInputOpened", "context")
end)

hook.Add("OnContextMenuClose", "IMPERIAL_ORDER.QMenuFixV249.ContextClose", function()
    STATE.contextOpen = false
    STATE.lastClose = RealTime()
    hook.Run("IMPERIAL_ORDERGameMenuInputClosed", "context")
    releaseStaleCursor()
end)

-- Safety net for addons that remove/rebuild the spawn menu without producing
-- a matching close hook. It only acts shortly after this patch observed a game
-- menu and only when no other known UI owns input.
local nextWatch = 0
hook.Add("Think", "IMPERIAL_ORDER.QMenuFixV249.CursorWatchdog", function()
    if RealTime() < nextWatch then return end
    nextWatch = RealTime() + 0.10

    if STATE.spawnOpen and not spawnMenuVisible() and not input.IsKeyDown(KEY_Q) then
        STATE.spawnOpen = false
        STATE.lastClose = RealTime()
        hook.Run("IMPERIAL_ORDERGameMenuInputClosed", "spawn_watchdog")
        releaseStaleCursor()
    end

    if STATE.contextOpen and not contextMenuVisible() and not input.IsKeyDown(KEY_C) then
        STATE.contextOpen = false
        STATE.lastClose = RealTime()
        hook.Run("IMPERIAL_ORDERGameMenuInputClosed", "context_watchdog")
        releaseStaleCursor()
    end
end)

concommand.Add("imperial_order_fix_q_menu", function()
    RunConsoleCommand("imperial_order_weapon_selector_hide_default", "1")
    RunConsoleCommand("imperial_order_weapon_selector_enabled", "1")
    RunConsoleCommand("spawnmenu_reload")
    releaseStaleCursor()

    print("[IMPERIAL_ORDER] Q/C menu input ownership repaired; stale cursor cleanup scheduled.")
end)

concommand.Add("imperial_order_release_cursor", function()
    releaseStaleCursor()
    print("[IMPERIAL_ORDER] Cursor release requested. It will remain visible only if another known menu owns input.")
end)
