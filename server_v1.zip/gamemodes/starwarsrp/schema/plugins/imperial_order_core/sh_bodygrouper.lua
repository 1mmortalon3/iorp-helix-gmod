-- Imperial Order v158
-- Persistent, character-bound bodygroup and skin editor with Imperial UI styling.

IMPERIAL_ORDER_UI_LOADED = IMPERIAL_ORDER_UI_LOADED or {}
IMPERIAL_ORDER_UI_LOADED.imperial_bodygrouper_v158 = true

local NET_APPLY = "IMPERIAL_ORDER.Bodygrouper.ApplyV158"
local NET_STATUS = "IMPERIAL_ORDER.Bodygrouper.StatusV158"
local NET_OPEN = "IMPERIAL_ORDER.Bodygrouper.OpenV158"
local DATA_KEY = "imperial_orderBodygroupProfilesV158"
local MAX_BODYGROUPS = 64

if ix and ix.config then
    ix.config.Add("imperial_orderBodygrouperEnabled", true, "Allow players to configure bodygroups available on their current model.", nil, {
        category = "Imperial Order"
    })
end

local function IsEnabled()
    if not ix or not ix.config then return true end
    return ix.config.Get("imperial_orderBodygrouperEnabled", true)
end

local function ModelKey(model)
    return string.lower(string.Trim(tostring(model or "")))
end

local function CopyTable(value)
    if not istable(value) then return {} end
    if table.Copy then return table.Copy(value) end

    local output = {}
    for key, item in pairs(value) do
        output[key] = istable(item) and CopyTable(item) or item
    end
    return output
end

if SERVER then
    util.AddNetworkString(NET_APPLY)
    util.AddNetworkString(NET_STATUS)
    util.AddNetworkString(NET_OPEN)

    local profileCache = setmetatable({}, {__mode = "k"})
    local nextApply = setmetatable({}, {__mode = "k"})

    local function CharacterID(character)
        if not character or type(character.GetID) ~= "function" then return 0 end
        return tonumber(character:GetID()) or 0
    end

    local function GetProfiles(client, character)
        local charID = CharacterID(character)
        local cached = profileCache[client]

        if cached and cached.charID == charID and istable(cached.profiles) then
            return cached.profiles
        end

        local profiles = {}
        if character and type(character.GetData) == "function" then
            profiles = CopyTable(character:GetData(DATA_KEY, {}))
        end

        if not istable(profiles) then profiles = {} end
        profileCache[client] = {
            charID = charID,
            profiles = profiles
        }

        return profiles
    end

    local function SendStatus(client, success, message)
        if not IsValid(client) then return end
        net.Start(NET_STATUS)
        net.WriteBool(success and true or false)
        net.WriteString(tostring(message or ""))
        net.Send(client)
    end

    local function SanitizeProfile(client, bodygroups, skin)
        local sanitized = {
            bodygroups = {},
            skin = 0
        }

        if not IsValid(client) then return sanitized end

        local available = {}
        for _, info in ipairs(client:GetBodyGroups() or {}) do
            local id = tonumber(info.id)
            local count = math.max(tonumber(info.num) or 0, 0)
            if id and id >= 0 and id <= 255 and count > 0 then
                available[id] = count
            end
        end

        local added = 0
        for rawID, rawValue in pairs(bodygroups or {}) do
            if added >= MAX_BODYGROUPS then break end

            local id = tonumber(rawID)
            local count = id and available[id]
            if count then
                local value = math.Clamp(math.floor(tonumber(rawValue) or 0), 0, math.max(0, count - 1))
                sanitized.bodygroups[tostring(id)] = value
                added = added + 1
            end
        end

        sanitized.skin = math.Clamp(
            math.floor(tonumber(skin) or 0),
            0,
            math.max(0, (tonumber(client:SkinCount()) or 1) - 1)
        )

        return sanitized
    end

    local function ApplyProfile(client, profile)
        if not IsValid(client) or not istable(profile) then return end

        local bodygroups = profile.bodygroups
        if not istable(bodygroups) then
            -- Compatibility with an older flat bodygroup table, if one was ever stored.
            bodygroups = profile
        end

        local sanitized = SanitizeProfile(client, bodygroups, profile.skin)

        for rawID, value in pairs(sanitized.bodygroups) do
            local id = tonumber(rawID)
            if id and client:GetBodygroup(id) ~= value then
                client:SetBodygroup(id, value)
            end
        end

        if client:GetSkin() ~= sanitized.skin then
            client:SetSkin(sanitized.skin)
        end
    end

    local function ApplySavedProfile(client)
        if not IsEnabled() or not IsValid(client) then return end

        local character = client.GetCharacter and client:GetCharacter() or nil
        if not character then return end

        local model = ModelKey(client:GetModel())
        if model == "" then return end

        local profiles = GetProfiles(client, character)
        local profile = profiles[model]
        if not istable(profile) then return end

        ApplyProfile(client, profile)
    end

    local function QueueSavedProfile(client, delay)
        if not IsValid(client) then return end

        local token = tostring(client:SteamID64() or client:UserID() or "0")
        local timerName = "IMPERIAL_ORDER.Bodygrouper.RestoreV158." .. token

        timer.Create(timerName, math.max(tonumber(delay) or 0.4, 0), 1, function()
            if IsValid(client) then
                ApplySavedProfile(client)
            end
        end)
    end

    net.Receive(NET_APPLY, function(_, client)
        if not IsEnabled() then
            SendStatus(client, false, "Uniform configuration is disabled by the server.")
            return
        end

        if not IsValid(client) or not client:Alive() then return end

        local character = client.GetCharacter and client:GetCharacter() or nil
        if not character then
            SendStatus(client, false, "No active personnel record was found.")
            return
        end

        local now = CurTime()
        if (nextApply[client] or 0) > now then return end
        nextApply[client] = now + 0.08

        local count = math.min(net.ReadUInt(7), MAX_BODYGROUPS)
        local requested = {}

        for _ = 1, count do
            local id = net.ReadUInt(8)
            local value = net.ReadUInt(8)
            requested[id] = value
        end

        local skin = net.ReadUInt(8)
        local profile = SanitizeProfile(client, requested, skin)
        local model = ModelKey(client:GetModel())

        if model == "" then
            SendStatus(client, false, "The current model cannot be configured.")
            return
        end

        ApplyProfile(client, profile)

        local profiles = GetProfiles(client, character)
        profiles[model] = profile
        profileCache[client] = {
            charID = CharacterID(character),
            profiles = profiles
        }

        if type(character.SetData) == "function" then
            character:SetData(DATA_KEY, profiles)
        end

        SendStatus(client, true, "Uniform configuration saved to this character.")
    end)

    hook.Add("PlayerLoadedCharacter", "IMPERIAL_ORDER.Bodygrouper.CharacterLoadedV158", function(client)
        profileCache[client] = nil
        QueueSavedProfile(client, 0.65)
    end)

    hook.Add("PlayerSpawn", "IMPERIAL_ORDER.Bodygrouper.PlayerSpawnV158", function(client)
        QueueSavedProfile(client, 0.55)
    end)

    hook.Add("PostPlayerLoadout", "IMPERIAL_ORDER.Bodygrouper.PostLoadoutV158", function(client)
        QueueSavedProfile(client, 0.35)
    end)

    hook.Add("OnPlayerChangedClass", "IMPERIAL_ORDER.Bodygrouper.ClassChangedV158", function(client)
        QueueSavedProfile(client, 0.55)
    end)

    hook.Add("PlayerDisconnected", "IMPERIAL_ORDER.Bodygrouper.CleanupV158", function(client)
        local token = tostring(client:SteamID64() or client:UserID() or "0")
        timer.Remove("IMPERIAL_ORDER.Bodygrouper.RestoreV158." .. token)
        profileCache[client] = nil
        nextApply[client] = nil
    end)

    if ix and ix.command then
        ix.command.Add("BodyGrouper", {
            description = "Open the Imperial uniform bodygroup configurator.",
            OnRun = function(_, client)
                if not IsEnabled() then
                    if client.Notify then client:Notify("Uniform configuration is disabled by the server.") end
                    return
                end

                net.Start(NET_OPEN)
                net.Send(client)
            end
        })
    end
end

if CLIENT then
    local function IMPERIAL_ORDERBodyGrouperCreateFonts()
        local scale = math.Clamp(math.min(ScrW() / 1920, ScrH() / 1080), 0.75, 1.25)
        local function create(name, size, weight)
            surface.CreateFont(name, {
                font = "Roboto",
                size = math.max(10, math.floor(size * scale)),
                weight = weight or 700,
                antialias = true,
                extended = true
            })
        end

        create("IMPERIAL_ORDER.UI.Title", 30, 900)
        create("IMPERIAL_ORDER.UI.Header", 22, 900)
        create("IMPERIAL_ORDER.UI.Body", 18, 800)
        create("IMPERIAL_ORDER.UI.Small", 15, 700)
        create("IMPERIAL_ORDER.UI.Tiny", 13, 700)
    end

    IMPERIAL_ORDERBodyGrouperCreateFonts()
    hook.Add("OnScreenSizeChanged", "IMPERIAL_ORDER.Bodygrouper.RebuildFontsV213", IMPERIAL_ORDERBodyGrouperCreateFonts)

    IMPERIAL_ORDERBodyGrouper = IMPERIAL_ORDERBodyGrouper or {}
    IMPERIAL_ORDERBodyGrouper.Pending = IMPERIAL_ORDERBodyGrouper.Pending or {}
    IMPERIAL_ORDERBodyGrouper.Skin = IMPERIAL_ORDERBodyGrouper.Skin or 0

    local function Col(name, fallback)
        if IMPERIAL_ORDERUI and IMPERIAL_ORDERUI.Col then return IMPERIAL_ORDERUI.Col(name, fallback) end
        return (IMPERIAL_ORDER_COLORS and IMPERIAL_ORDER_COLORS[name]) or fallback or color_white
    end

    local function PaintPanel(x, y, w, h, title)
        if IMPERIAL_ORDERUI and IMPERIAL_ORDERUI.Panel then
            IMPERIAL_ORDERUI.Panel(x, y, w, h, title, Col("red", Color(190, 38, 38)), true)
            return
        end

        draw.RoundedBox(6, x, y, w, h, Color(11, 12, 15, 248))
        surface.SetDrawColor(Col("border", Color(128, 136, 148)))
        surface.DrawOutlinedRect(x, y, w, h, 1)
        surface.SetDrawColor(Col("red", Color(190, 38, 38)))
        surface.DrawRect(x, y, 5, h)
    end

    local function DrawText(text, font, x, y, color, alignX, alignY)
        text = tostring(text or "")
        font = isstring(font) and font or "IMPERIAL_ORDER.UI.Body"
        x = tonumber(x) or 0
        y = tonumber(y) or 0
        color = IsColor(color) and color or color_white
        alignX = tonumber(alignX) or TEXT_ALIGN_LEFT
        alignY = tonumber(alignY) or TEXT_ALIGN_TOP

        if IMPERIAL_ORDERUI and isfunction(IMPERIAL_ORDERUI.Text) then
            local ok = pcall(IMPERIAL_ORDERUI.Text, text, font, x, y, color, alignX, alignY)
            if ok then return end
        end

        local ok = pcall(draw.SimpleText, text, font, x, y, color, alignX, alignY)
        if not ok then
            draw.SimpleText(text, "DermaDefaultBold", x, y, color, alignX, alignY)
        end
    end

    local function PaintButton(button, w, h, label, sublabel)
        w = math.max(1, tonumber(w) or (IsValid(button) and button:GetWide()) or 1)
        h = math.max(1, tonumber(h) or (IsValid(button) and button:GetTall()) or 1)

        if IMPERIAL_ORDERUI and isfunction(IMPERIAL_ORDERUI.PaintButton) then
            local ok = pcall(IMPERIAL_ORDERUI.PaintButton, button, w, h, label, sublabel)
            if ok then return end
        end

        local hovered = IsValid(button) and button:IsHovered()
        draw.RoundedBox(4, 0, 0, w, h, hovered and Color(31, 34, 40) or Color(17, 19, 23))
        surface.SetDrawColor(hovered and Col("crimson", Color(215, 42, 42)) or Col("red", Color(190, 38, 38)))
        surface.DrawRect(0, 0, 5, h)
        surface.SetDrawColor(Col("border", Color(128, 136, 148)))
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        DrawText(label, "IMPERIAL_ORDER.UI.Body", w / 2, h / 2, Col("text", color_white), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local function ValidPlayer()
        local client = LocalPlayer()
        return IsValid(client) and client:GetModel() and client:GetModel() ~= ""
    end

    local function ReadBodygroups(entity)
        local output = {}
        if not IsValid(entity) then return output end

        for _, info in ipairs(entity:GetBodyGroups() or {}) do
            local id = tonumber(info.id)
            local count = tonumber(info.num) or 0
            if id and count > 0 then
                output[id] = math.Clamp(entity:GetBodygroup(id), 0, math.max(0, count - 1))
            end
        end

        return output
    end

    local function SendConfiguration(showPendingStatus)
        if not ValidPlayer() then return end

        local client = LocalPlayer()
        local groups = client:GetBodyGroups() or {}
        local payload = {}

        for _, info in ipairs(groups) do
            local id = tonumber(info.id)
            local count = tonumber(info.num) or 0
            if id and count > 0 and #payload < MAX_BODYGROUPS then
                payload[#payload + 1] = {
                    id = math.Clamp(id, 0, 255),
                    value = math.Clamp(math.floor(tonumber(IMPERIAL_ORDERBodyGrouper.Pending[id]) or client:GetBodygroup(id) or 0), 0, math.max(0, count - 1))
                }
            end
        end

        net.Start(NET_APPLY)
        net.WriteUInt(#payload, 7)
        for _, item in ipairs(payload) do
            net.WriteUInt(item.id, 8)
            net.WriteUInt(item.value, 8)
        end
        net.WriteUInt(math.Clamp(math.floor(tonumber(IMPERIAL_ORDERBodyGrouper.Skin) or client:GetSkin() or 0), 0, 255), 8)
        net.SendToServer()

        if showPendingStatus and IsValid(IMPERIAL_ORDERBodyGrouper.StatusLabel) then
            IMPERIAL_ORDERBodyGrouper.StatusLabel:SetText("TRANSMITTING UNIFORM CONFIGURATION...")
            IMPERIAL_ORDERBodyGrouper.StatusLabel:SetTextColor(Col("steelLight", Color(184, 190, 200)))
        end
    end

    local function QueueAutoSave()
        timer.Create("IMPERIAL_ORDER.Bodygrouper.AutoSaveV158", 0.18, 1, function()
            SendConfiguration(true)
        end)
    end

    local function FitModelPanel(panel)
        if not IsValid(panel) or not IsValid(panel.Entity) then return end

        local mins, maxs = panel.Entity:GetRenderBounds()
        local center = (mins + maxs) * 0.5
        local size = math.max(maxs.x - mins.x, maxs.y - mins.y, maxs.z - mins.z)
        size = math.max(size, 40)

        panel:SetFOV(34)
        panel:SetLookAt(center + Vector(0, 0, size * 0.04))
        panel:SetCamPos(center + Vector(size * 1.2, size * 1.2, size * 0.45))
    end

    local function OptionLabel(info, value)
        local submodels = istable(info.submodels) and info.submodels or {}
        local raw = submodels[value] or submodels[value + 1]
        raw = string.Trim(tostring(raw or ""))

        if raw == "" then
            return string.format("OPTION %02d", value)
        end

        raw = string.StripExtension(raw)
        raw = string.gsub(raw, "_", " ")
        return string.upper(raw)
    end

    local function StyleScrollBar(scroll)
        if not IsValid(scroll) or not IsValid(scroll.VBar) then return end
        local bar = scroll.VBar
        bar:SetWide(10)
        bar.Paint = function(_, w, h)
            draw.RoundedBox(2, 2, 0, w - 4, h, Color(4, 4, 5, 230))
        end
        bar.btnUp.Paint = function(_, w, h)
            draw.RoundedBox(2, 1, 1, w - 2, h - 2, Col("greyDark", Color(18, 20, 24)))
        end
        bar.btnDown.Paint = bar.btnUp.Paint
        bar.btnGrip.Paint = function(_, w, h)
            draw.RoundedBox(2, 1, 0, w - 2, h, Col("red", Color(190, 38, 38)))
        end
    end

    local function RefreshPreviewEntity()
        local frame = IMPERIAL_ORDERBodyGrouper.Frame
        local preview = IMPERIAL_ORDERBodyGrouper.Preview
        if not IsValid(frame) or not IsValid(preview) or not ValidPlayer() then return end

        local client = LocalPlayer()
        preview:SetModel(client:GetModel())

        if IsValid(preview.Entity) then
            preview.Entity:SetSkin(math.Clamp(tonumber(IMPERIAL_ORDERBodyGrouper.Skin) or client:GetSkin(), 0, math.max(0, preview.Entity:SkinCount() - 1)))
            for id, value in pairs(IMPERIAL_ORDERBodyGrouper.Pending or {}) do
                preview.Entity:SetBodygroup(tonumber(id) or 0, tonumber(value) or 0)
            end
        end

        FitModelPanel(preview)
    end

    local function AddSelectorRow(parent, info)
        local client = LocalPlayer()
        local id = tonumber(info.id) or 0
        local count = math.max(tonumber(info.num) or 1, 1)
        local current = math.Clamp(tonumber(IMPERIAL_ORDERBodyGrouper.Pending[id]) or client:GetBodygroup(id) or 0, 0, count - 1)

        local row = parent:Add("DPanel")
        row:Dock(TOP)
        row:DockMargin(0, 0, 8, 8)
        row:SetTall(76)
        row.Paint = function(_, w, h)
            draw.RoundedBox(4, 0, 0, w, h, Color(14, 16, 20, 245))
            surface.SetDrawColor(Col("border", Color(128, 136, 148)))
            surface.DrawOutlinedRect(0, 0, w, h, 1)
            surface.SetDrawColor(Col("red", Color(190, 38, 38)))
            surface.DrawRect(0, 0, 4, h)

            DrawText(string.upper(tostring(info.name or ("BODYGROUP " .. id))), "IMPERIAL_ORDER.UI.Body", 16, h / 2, Col("text", color_white), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end

        local combo = vgui.Create("DComboBox", row)
        combo:Dock(RIGHT)
        combo:DockMargin(0, 14, 14, 14)
        combo:SetWide(math.Clamp(ScrW() * 0.17, 190, 270))
        combo:SetFont("IMPERIAL_ORDER.UI.Small")
        combo:SetTextColor(Col("text", color_white))
        combo:SetValue(OptionLabel(info, current))
        combo.Paint = function(self, w, h)
            draw.RoundedBox(3, 0, 0, w, h, self:IsHovered() and Color(31, 34, 40, 250) or Color(7, 8, 10, 250))
            local menuOpen = self.IsMenuOpen and self:IsMenuOpen()
            surface.SetDrawColor(menuOpen and Col("red", Color(190, 38, 38)) or Col("border", Color(128, 136, 148)))
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end

        for value = 0, count - 1 do
            combo:AddChoice(OptionLabel(info, value), value, value == current)
        end

        IMPERIAL_ORDERBodyGrouper.ComboByID = IMPERIAL_ORDERBodyGrouper.ComboByID or {}
        IMPERIAL_ORDERBodyGrouper.InfoByID = IMPERIAL_ORDERBodyGrouper.InfoByID or {}
        IMPERIAL_ORDERBodyGrouper.ComboByID[id] = combo
        IMPERIAL_ORDERBodyGrouper.InfoByID[id] = info

        combo.OnSelect = function(_, _, _, data)
            local value = math.Clamp(math.floor(tonumber(data) or 0), 0, count - 1)
            IMPERIAL_ORDERBodyGrouper.Pending[id] = value

            if IsValid(IMPERIAL_ORDERBodyGrouper.Preview) and IsValid(IMPERIAL_ORDERBodyGrouper.Preview.Entity) then
                IMPERIAL_ORDERBodyGrouper.Preview.Entity:SetBodygroup(id, value)
            end

            QueueAutoSave()
        end
    end

    local function AddSkinRow(parent)
        local client = LocalPlayer()
        local count = math.max(tonumber(client:SkinCount()) or 1, 1)
        if count <= 1 then return end

        local row = parent:Add("DPanel")
        row:Dock(TOP)
        row:DockMargin(0, 0, 8, 8)
        row:SetTall(76)
        row.Paint = function(_, w, h)
            draw.RoundedBox(4, 0, 0, w, h, Color(14, 16, 20, 245))
            surface.SetDrawColor(Col("border", Color(128, 136, 148)))
            surface.DrawOutlinedRect(0, 0, w, h, 1)
            surface.SetDrawColor(Col("steelLight", Color(184, 190, 200)))
            surface.DrawRect(0, 0, 4, h)

            DrawText("UNIFORM SKIN", "IMPERIAL_ORDER.UI.Body", 16, h / 2, Col("text", color_white), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end

        local combo = vgui.Create("DComboBox", row)
        combo:Dock(RIGHT)
        combo:DockMargin(0, 14, 14, 14)
        combo:SetWide(math.Clamp(ScrW() * 0.17, 190, 270))
        combo:SetFont("IMPERIAL_ORDER.UI.Small")
        combo:SetTextColor(Col("text", color_white))
        combo:SetValue(string.format("SKIN %02d", tonumber(IMPERIAL_ORDERBodyGrouper.Skin) or 0))
        combo.Paint = function(self, w, h)
            draw.RoundedBox(3, 0, 0, w, h, self:IsHovered() and Color(31, 34, 40, 250) or Color(7, 8, 10, 250))
            local menuOpen = self.IsMenuOpen and self:IsMenuOpen()
            surface.SetDrawColor(menuOpen and Col("red", Color(190, 38, 38)) or Col("border", Color(128, 136, 148)))
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end

        for value = 0, count - 1 do
            combo:AddChoice(string.format("SKIN %02d", value), value, value == IMPERIAL_ORDERBodyGrouper.Skin)
        end

        IMPERIAL_ORDERBodyGrouper.SkinCombo = combo

        combo.OnSelect = function(_, _, _, data)
            local value = math.Clamp(math.floor(tonumber(data) or 0), 0, count - 1)
            IMPERIAL_ORDERBodyGrouper.Skin = value

            if IsValid(IMPERIAL_ORDERBodyGrouper.Preview) and IsValid(IMPERIAL_ORDERBodyGrouper.Preview.Entity) then
                IMPERIAL_ORDERBodyGrouper.Preview.Entity:SetSkin(value)
            end

            QueueAutoSave()
        end
    end

    function IMPERIAL_ORDERBodyGrouper.Refresh()
        if not ValidPlayer() then return end

        local frame = IMPERIAL_ORDERBodyGrouper.Frame
        local list = IMPERIAL_ORDERBodyGrouper.List
        if not IsValid(frame) or not IsValid(list) then return end

        list:Clear()
        IMPERIAL_ORDERBodyGrouper.ComboByID = {}
        IMPERIAL_ORDERBodyGrouper.InfoByID = {}
        IMPERIAL_ORDERBodyGrouper.SkinCombo = nil

        local client = LocalPlayer()
        IMPERIAL_ORDERBodyGrouper.Pending = ReadBodygroups(client)
        IMPERIAL_ORDERBodyGrouper.Skin = math.Clamp(client:GetSkin(), 0, math.max(0, client:SkinCount() - 1))

        if IsValid(IMPERIAL_ORDERBodyGrouper.NameLabel) then
            local character = client.GetCharacter and client:GetCharacter() or nil
            local name = character and character.GetName and character:GetName() or client:Nick()
            IMPERIAL_ORDERBodyGrouper.NameLabel:SetText(string.upper(tostring(name or "UNKNOWN OPERATIVE")))
        end

        if IsValid(IMPERIAL_ORDERBodyGrouper.ModelLabel) then
            IMPERIAL_ORDERBodyGrouper.ModelLabel:SetText(string.upper(tostring(client:GetModel() or "UNKNOWN MODEL")))
        end

        AddSkinRow(list)

        local shown = 0
        for _, info in ipairs(client:GetBodyGroups() or {}) do
            if (tonumber(info.num) or 0) > 1 then
                AddSelectorRow(list, info)
                shown = shown + 1
            end
        end

        if shown == 0 and client:SkinCount() <= 1 then
            local empty = list:Add("DPanel")
            empty:Dock(TOP)
            empty:DockMargin(0, 0, 8, 8)
            empty:SetTall(130)
            empty.Paint = function(_, w, h)
                draw.RoundedBox(4, 0, 0, w, h, Color(14, 16, 20, 245))
                surface.SetDrawColor(Col("border", Color(128, 136, 148)))
                surface.DrawOutlinedRect(0, 0, w, h, 1)
                DrawText("NO CONFIGURABLE BODYGROUPS", "IMPERIAL_ORDER.UI.Header", w / 2, 45, Col("text", color_white), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
        end

        RefreshPreviewEntity()

        if IsValid(IMPERIAL_ORDERBodyGrouper.StatusLabel) then
            IMPERIAL_ORDERBodyGrouper.StatusLabel:SetText("")
            IMPERIAL_ORDERBodyGrouper.StatusLabel:SetTextColor(Col("textDim", Color(188, 194, 204)))
        end
    end

    local function BuildFrame()
        local frame = vgui.Create("DFrame")
        IMPERIAL_ORDERBodyGrouper.Frame = frame

        frame:SetSize(math.min(math.Clamp(ScrW() * 0.78, 760, 1180), ScrW() - 36), math.min(math.Clamp(ScrH() * 0.78, 560, 820), ScrH() - 36))
        frame:Center()
        frame:SetTitle("")
        frame:ShowCloseButton(false)
        frame:SetDraggable(true)
        frame:SetSizable(true)
        frame:SetDeleteOnClose(false)
        frame:SetVisible(false)
        frame.Paint = function(_, w, h)
            PaintPanel(0, 0, w, h, "")
            draw.RoundedBox(0, 5, 5, w - 10, 66, Color(6, 7, 9, 248))
            surface.SetDrawColor(Col("red", Color(190, 38, 38)))
            surface.DrawRect(5, 69, w - 10, 3)

            DrawText("IMPERIAL UNIFORM CONFIGURATOR", "IMPERIAL_ORDER.UI.Title", 28, 19, Col("text", color_white), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        end

        frame.OnClose = function(self)
            self:SetVisible(false)
            timer.Remove("IMPERIAL_ORDER.Bodygrouper.AutoSaveV158")
        end

        local close = vgui.Create("DButton", frame)
        close:SetSize(48, 40)
        close:SetPos(frame:GetWide() - 62, 17)
        close:SetText("")
        close.Paint = function(self, w, h)
            draw.RoundedBox(3, 0, 0, w, h, self:IsHovered() and Col("redDark", Color(92, 12, 16)) or Color(17, 19, 23, 245))
            surface.SetDrawColor(self:IsHovered() and Col("crimson", Color(215, 42, 42)) or Col("border", Color(128, 136, 148)))
            surface.DrawOutlinedRect(0, 0, w, h, 1)
            DrawText("X", "IMPERIAL_ORDER.UI.Header", w / 2, h / 2, Col("text", color_white), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        close.DoClick = function()
            frame:Close()
        end

        local content = vgui.Create("DPanel", frame)
        content:SetPos(18, 86)
        content:SetSize(frame:GetWide() - 36, frame:GetTall() - 104)
        content.Paint = nil
        frame.PerformLayout = function(self, w, h)
            w, h = w or self:GetWide(), h or self:GetTall()
            if IsValid(close) then close:SetPos(w - 62, 17) end
            if IsValid(content) then
                content:SetPos(18, 86)
                content:SetSize(math.max(1, w - 36), math.max(1, h - 104))
                content:InvalidateLayout(true)
            end
        end
        content.PerformLayout = function(self)
            local w, h = self:GetSize()
            local leftWidth = math.Clamp(w * 0.39, 300, 430)

            if IsValid(IMPERIAL_ORDERBodyGrouper.LeftPanel) then
                IMPERIAL_ORDERBodyGrouper.LeftPanel:SetPos(0, 0)
                IMPERIAL_ORDERBodyGrouper.LeftPanel:SetSize(leftWidth, h)
            end

            if IsValid(IMPERIAL_ORDERBodyGrouper.RightPanel) then
                IMPERIAL_ORDERBodyGrouper.RightPanel:SetPos(leftWidth + 14, 0)
                IMPERIAL_ORDERBodyGrouper.RightPanel:SetSize(w - leftWidth - 14, h)
            end
        end

        local contentWidth, contentHeight = content:GetSize()
        local initialLeftWidth = math.Clamp(contentWidth * 0.39, 300, 430)

        local left = vgui.Create("DPanel", content)
        IMPERIAL_ORDERBodyGrouper.LeftPanel = left
        left:SetPos(0, 0)
        left:SetSize(initialLeftWidth, contentHeight)
        left.Paint = function(_, w, h)
            PaintPanel(0, 0, w, h, "LIVE UNIFORM PREVIEW")
        end

        local preview = vgui.Create("DModelPanel", left)
        IMPERIAL_ORDERBodyGrouper.Preview = preview
        preview:SetPos(12, 36)
        preview:SetSize(left:GetWide() - 24, left:GetTall() - 184)
        preview:SetAnimated(true)
        preview:SetMouseInputEnabled(true)
        preview.LayoutEntity = function(self, entity)
            if self.bAnimated then self:RunAnimation() end
            entity:SetAngles(Angle(0, 35, 0))
        end
        preview.PaintOver = function(_, w, h)
            surface.SetDrawColor(Col("border", Color(128, 136, 148)))
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end

        local identity = vgui.Create("DPanel", left)
        identity:SetPos(12, left:GetTall() - 136)
        identity:SetSize(left:GetWide() - 24, 72)
        identity.Paint = function(_, w, h)
            draw.RoundedBox(4, 0, 0, w, h, Color(7, 8, 10, 245))
            surface.SetDrawColor(Col("border", Color(128, 136, 148)))
            surface.DrawOutlinedRect(0, 0, w, h, 1)
            surface.SetDrawColor(Col("red", Color(190, 38, 38)))
            surface.DrawRect(0, 0, 4, h)
        end

        local nameLabel = vgui.Create("DLabel", identity)
        IMPERIAL_ORDERBodyGrouper.NameLabel = nameLabel
        nameLabel:SetPos(16, 11)
        nameLabel:SetSize(identity:GetWide() - 32, 25)
        nameLabel:SetFont("IMPERIAL_ORDER.UI.Body")
        nameLabel:SetTextColor(Col("text", color_white))
        nameLabel:SetText("UNKNOWN OPERATIVE")

        local modelLabel = vgui.Create("DLabel", identity)
        IMPERIAL_ORDERBodyGrouper.ModelLabel = modelLabel
        modelLabel:SetPos(16, 39)
        modelLabel:SetSize(identity:GetWide() - 32, 20)
        modelLabel:SetFont("IMPERIAL_ORDER.UI.Tiny")
        modelLabel:SetTextColor(Col("textDim", Color(188, 194, 204)))
        modelLabel:SetText("UNKNOWN MODEL")

        local reset = vgui.Create("DButton", left)
        reset:SetPos(12, left:GetTall() - 52)
        reset:SetSize((left:GetWide() - 34) * 0.46, 40)
        reset:SetText("")
        reset.Paint = function(self, w, h)
            PaintButton(self, w, h, "RESET UNIFORM")
        end
        reset.DoClick = function()
            if not ValidPlayer() then return end
            local client = LocalPlayer()

            for _, info in ipairs(client:GetBodyGroups() or {}) do
                local id = tonumber(info.id)
                if id then
                    IMPERIAL_ORDERBodyGrouper.Pending[id] = 0
                    local combo = IMPERIAL_ORDERBodyGrouper.ComboByID and IMPERIAL_ORDERBodyGrouper.ComboByID[id]
                    if IsValid(combo) then combo:SetValue(OptionLabel(info, 0)) end
                end
            end
            IMPERIAL_ORDERBodyGrouper.Skin = 0
            if IsValid(IMPERIAL_ORDERBodyGrouper.SkinCombo) then
                IMPERIAL_ORDERBodyGrouper.SkinCombo:SetValue("SKIN 00")
            end

            RefreshPreviewEntity()
            SendConfiguration(true)
        end

        local refresh = vgui.Create("DButton", left)
        refresh:SetPos(reset:GetX() + reset:GetWide() + 10, left:GetTall() - 52)
        refresh:SetSize(left:GetWide() - refresh:GetX() - 12, 40)
        refresh:SetText("")
        refresh.Paint = function(self, w, h)
            PaintButton(self, w, h, "REFRESH MODEL")
        end
        refresh.DoClick = function()
            IMPERIAL_ORDERBodyGrouper.Refresh()
        end

        local right = vgui.Create("DPanel", content)
        IMPERIAL_ORDERBodyGrouper.RightPanel = right
        right:SetPos(initialLeftWidth + 14, 0)
        right:SetSize(contentWidth - initialLeftWidth - 14, contentHeight)
        right.Paint = function(_, w, h)
            PaintPanel(0, 0, w, h, "AVAILABLE UNIFORM CHANNELS")
        end

        local list = vgui.Create("DScrollPanel", right)
        IMPERIAL_ORDERBodyGrouper.List = list
        list:SetPos(12, 36)
        list:SetSize(right:GetWide() - 24, right:GetTall() - 128)
        StyleScrollBar(list)

        local status = vgui.Create("DLabel", right)
        IMPERIAL_ORDERBodyGrouper.StatusLabel = status
        status:SetPos(14, right:GetTall() - 80)
        status:SetSize(right:GetWide() - 28, 20)
        status:SetFont("IMPERIAL_ORDER.UI.Tiny")
        status:SetTextColor(Col("textDim", Color(188, 194, 204)))
        status:SetText("")
        status:SetContentAlignment(5)

        local apply = vgui.Create("DButton", right)
        apply:SetPos(14, right:GetTall() - 54)
        apply:SetSize(right:GetWide() - 28, 42)
        apply:SetText("")
        apply.Paint = function(self, w, h)
            PaintButton(self, w, h, "APPLY & SAVE UNIFORM")
        end
        apply.DoClick = function()
            timer.Remove("IMPERIAL_ORDER.Bodygrouper.AutoSaveV158")
            SendConfiguration(true)
        end

        left.PerformLayout = function(self)
            local w, h = self:GetSize()
            preview:SetPos(12, 36)
            preview:SetSize(w - 24, h - 184)
            identity:SetPos(12, h - 136)
            identity:SetSize(w - 24, 72)
            nameLabel:SetSize(identity:GetWide() - 32, 25)
            modelLabel:SetSize(identity:GetWide() - 32, 20)
            reset:SetPos(12, h - 52)
            reset:SetSize((w - 34) * 0.46, 40)
            refresh:SetPos(reset:GetX() + reset:GetWide() + 10, h - 52)
            refresh:SetSize(w - refresh:GetX() - 12, 40)
        end

        right.PerformLayout = function(self)
            local w, h = self:GetSize()
            list:SetPos(12, 36)
            list:SetSize(w - 24, h - 128)
            status:SetPos(14, h - 80)
            status:SetSize(w - 28, 20)
            apply:SetPos(14, h - 54)
            apply:SetSize(w - 28, 42)
        end

        content:InvalidateLayout(true)
        return frame
    end

    function IMPERIAL_ORDERBodyGrouper.Open()
        if not IsEnabled() then
            notification.AddLegacy("Uniform configuration is disabled by the server.", NOTIFY_ERROR, 4)
            return
        end

        if not ValidPlayer() then
            notification.AddLegacy("No configurable player model is active.", NOTIFY_ERROR, 4)
            return
        end

        local frame = IMPERIAL_ORDERBodyGrouper.Frame
        if not IsValid(frame) then
            frame = BuildFrame()
        end

        frame:SetVisible(true)
        frame:MoveToFront()
        frame:MakePopup()
        IMPERIAL_ORDERBodyGrouper.Refresh()

        timer.Simple(0, function()
            if IsValid(frame) and frame:IsVisible() then
                frame:MakePopup()
            end
        end)
    end

    local function EnsureContextButton()
        if not IsValid(g_ContextMenu) then return end

        local button = IMPERIAL_ORDERBodyGrouper.ContextButton
        if not IsValid(button) or button:GetParent() ~= g_ContextMenu then
            if IsValid(button) then button:Remove() end

            button = vgui.Create("DButton", g_ContextMenu)
            IMPERIAL_ORDERBodyGrouper.ContextButton = button
            button:SetText("")
            button:SetSize(264, 56)
            button.Paint = function(self, w, h)
                PaintButton(self, w, h, "BODY GROUPER", "IMPERIAL UNIFORM CONTROL")
            end
            button.DoClick = function()
                IMPERIAL_ORDERBodyGrouper.Open()
                timer.Simple(0.05, function()
                    if IsValid(IMPERIAL_ORDERBodyGrouper.Frame) and IMPERIAL_ORDERBodyGrouper.Frame:IsVisible() then
                        IMPERIAL_ORDERBodyGrouper.Frame:MakePopup()
                    end
                end)
            end
        end

        button:SetPos(math.max(16, g_ContextMenu:GetWide() - button:GetWide() - 28), 28)
        button:SetVisible(true)
        button:MoveToFront()
    end

    hook.Add("OnContextMenuOpen", "IMPERIAL_ORDER.Bodygrouper.ContextOpenV158", function()
        timer.Simple(0, EnsureContextButton)
    end)

    hook.Add("OnContextMenuClose", "IMPERIAL_ORDER.Bodygrouper.ContextCloseV158", function()
        if IsValid(IMPERIAL_ORDERBodyGrouper.ContextButton) then
            IMPERIAL_ORDERBodyGrouper.ContextButton:SetVisible(false)
        end

        timer.Simple(0, function()
            local frame = IMPERIAL_ORDERBodyGrouper.Frame
            if IsValid(frame) and frame:IsVisible() then
                frame:MakePopup()
            end
        end)
    end)

    hook.Add("OnScreenSizeChanged", "IMPERIAL_ORDER.Bodygrouper.ScreenSizeV158", function()
        if IsValid(IMPERIAL_ORDERBodyGrouper.ContextButton) and IsValid(g_ContextMenu) then
            IMPERIAL_ORDERBodyGrouper.ContextButton:SetPos(math.max(16, g_ContextMenu:GetWide() - IMPERIAL_ORDERBodyGrouper.ContextButton:GetWide() - 28), 28)
        end

        local frame = IMPERIAL_ORDERBodyGrouper.Frame
        if IsValid(frame) then
            frame:SetSize(math.min(math.Clamp(ScrW() * 0.78, 760, 1180), ScrW() - 36), math.min(math.Clamp(ScrH() * 0.78, 560, 820), ScrH() - 36))
            frame:Center()
        end
    end)

    net.Receive(NET_STATUS, function()
        local success = net.ReadBool()
        local message = net.ReadString()

        if IsValid(IMPERIAL_ORDERBodyGrouper.StatusLabel) then
            IMPERIAL_ORDERBodyGrouper.StatusLabel:SetText(string.upper(message))
            IMPERIAL_ORDERBodyGrouper.StatusLabel:SetTextColor(success and Col("steelLight", Color(184, 190, 200)) or Col("warning", Color(238, 72, 72)))
        end
    end)

    net.Receive(NET_OPEN, function()
        IMPERIAL_ORDERBodyGrouper.Open()
    end)

    concommand.Add("imperial_order_bodygrouper", function()
        IMPERIAL_ORDERBodyGrouper.Open()
    end)

    concommand.Add("imperial_order_bodygrouper_refresh", function()
        if IsValid(IMPERIAL_ORDERBodyGrouper.Frame) then
            IMPERIAL_ORDERBodyGrouper.Refresh()
        else
            IMPERIAL_ORDERBodyGrouper.Open()
        end
    end)
end
