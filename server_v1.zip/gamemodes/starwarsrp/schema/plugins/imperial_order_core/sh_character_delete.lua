-- Imperial Order v169: confirmed, owner-only Helix character deletion.
-- The file name is retained for upgrade compatibility, but this implementation
-- supersedes v164. A delete is not reported as successful until the database
-- confirms that the owned character row no longer exists.

IMPERIAL_ORDER = IMPERIAL_ORDER or {}
IMPERIAL_ORDER_LOADED = IMPERIAL_ORDER_LOADED or {}
IMPERIAL_ORDER_LOADED.authoritative_character_delete_v164 = true
IMPERIAL_ORDER_LOADED.authoritative_character_delete_v165 = true
IMPERIAL_ORDER_LOADED.authoritative_character_delete_v169 = true

local DELETE_REQUEST = "IMPERIAL_ORDER.CharacterDelete.RequestV36"
local DELETE_RESULT = "IMPERIAL_ORDER.CharacterDelete.ResultV36"
local SYNC_V34 = "IMPERIAL_ORDER.CharacterSync.SendV34"
local SYNC_OLD = "IMPERIAL_ORDER.CharacterSync.Send"

local function ReadCharacterID(character)
    if character == nil then return nil end
    if isnumber(character) or isstring(character) then return tonumber(character) end

    if istable(character) then
        local direct = character.id or character._id or character.ID
        if direct ~= nil then return tonumber(direct) end
        if type(character.GetID) == "function" then
            local ok, value = pcall(character.GetID, character)
            if ok then return tonumber(value) end
        end
    end
end

local function RemoveIDFromList(list, id)
    if not istable(list) then return end
    id = tonumber(id)
    if not id then return end

    for index = #list, 1, -1 do
        local value = list[index]
        if tonumber(value) == id or ReadCharacterID(value) == id then
            table.remove(list, index)
        end
    end

    local removeKeys = {}
    for key, value in pairs(list) do
        if tonumber(key) == id or tonumber(value) == id or ReadCharacterID(value) == id then
            removeKeys[#removeKeys + 1] = key
        end
    end

    for _, key in ipairs(removeKeys) do
        list[key] = nil
    end
end

local function ListContainsID(list, id)
    if not istable(list) then return false end
    id = tonumber(id)
    if not id then return false end

    for key, value in pairs(list) do
        if tonumber(key) == id or tonumber(value) == id or ReadCharacterID(value) == id then
            return true
        end
    end

    return false
end

if SERVER then
    util.AddNetworkString(DELETE_REQUEST)
    util.AddNetworkString(DELETE_RESULT)
    util.AddNetworkString(SYNC_V34)
    util.AddNetworkString(SYNC_OLD)

    local pending = setmetatable({}, {__mode = "k"})
    local cooldown = setmetatable({}, {__mode = "k"})

    local function PlayerToken(client)
        return tostring(client:SteamID64() or client:UserID() or "0")
    end

    local function NotifyDeleteResult(client, ok, id, message)
        if not IsValid(client) then return end
        net.Start(DELETE_RESULT)
        net.WriteBool(ok == true)
        net.WriteUInt(math.max(tonumber(id) or 0, 0), 32)
        net.WriteString(tostring(message or ""))
        net.Send(client)
    end

    local function FindLoadedCharacter(id)
        id = tonumber(id)
        if not id or not ix or not ix.char then return nil end

        for _, source in ipairs({ix.char.loaded, ix.char.list, ix.char.instances}) do
            if istable(source) then
                local character = source[id] or source[tostring(id)]
                if istable(character) then return character end
            end
        end
    end

    local function CharacterBelongsToClient(character, client)
        if not istable(character) or not IsValid(client) then return false end
        local steam64 = tostring(client:SteamID64() or "")
        local steam = tostring(client:SteamID() or "")

        local storedSteam = tostring(character._steamID or character.steamID or character.steamid or "")
        if storedSteam == steam64 or storedSteam == steam then return true end

        if type(character.GetSteamID) == "function" then
            local ok, value = pcall(character.GetSteamID, character)
            value = ok and tostring(value or "") or ""
            if value == steam64 or value == steam then return true end
        end

        if type(character.GetPlayer) == "function" then
            local ok, owner = pcall(character.GetPlayer, character)
            if ok and owner == client then return true end
        end

        return false
    end

    local function CachedOwnership(client, id, character)
        if CharacterBelongsToClient(character, client) then return true end
        if ListContainsID(client.ixCharList, id) then return true end
        if ListContainsID(client.characters, id) then return true end
        if ListContainsID(client.charList, id) then return true end
        if ListContainsID(client.CharacterList, id) then return true end

        local steam64 = tostring(client:SteamID64() or "")
        local steam = tostring(client:SteamID() or "")
        if ix and ix.char and istable(ix.char.cache) then
            if ListContainsID(ix.char.cache[steam64], id) then return true end
            if ListContainsID(ix.char.cache[steam], id) then return true end
        end

        return false
    end

    local function QueryOwnedRow(client, id, callback)
        if not IsValid(client) then return callback(false, false, nil) end
        id = tonumber(id)
        if not id then return callback(false, false, nil) end

        if mysql and type(mysql.Select) == "function" then
            local ok, query = pcall(function() return mysql:Select("ix_characters") end)
            if ok and query and type(query.Where) == "function" and type(query.Callback) == "function" and type(query.Execute) == "function" then
                local configured = pcall(function()
                    query:Select("id")
                    query:Where("id", id)
                    query:Where("steamid", client:SteamID64())
                    query:Callback(function(rows)
                        rows = istable(rows) and rows or {}
                        callback(true, rows[1] ~= nil, rows[1])
                    end)
                end)
                if configured and pcall(function() query:Execute() end) then return end
            end
        end

        if sql and type(sql.Query) == "function" then
            local quoted = sql.SQLStr and sql.SQLStr(tostring(client:SteamID64() or ""))
                or ("'" .. string.gsub(tostring(client:SteamID64() or ""), "'", "''") .. "'")
            local ok, rows = pcall(sql.Query, "SELECT id FROM ix_characters WHERE id = " .. id .. " AND steamid = " .. quoted .. " LIMIT 1")
            if ok then
                rows = istable(rows) and rows or {}
                callback(true, rows[1] ~= nil, rows[1])
                return
            end
        end

        callback(false, false, nil)
    end

    local function QueueCharacterDelete(client, id)
        if not IsValid(client) then return false end
        id = tonumber(id)
        if not id then return false end

        if mysql and type(mysql.Delete) == "function" then
            local ok, query = pcall(function() return mysql:Delete("ix_characters") end)
            if ok and query and type(query.Where) == "function" and type(query.Execute) == "function" then
                local queued = pcall(function()
                    query:Where("id", id)
                    query:Where("steamid", client:SteamID64())
                    query:Execute()
                end)
                if queued then return true end
            end
        end

        if sql and type(sql.Query) == "function" then
            local quoted = sql.SQLStr and sql.SQLStr(tostring(client:SteamID64() or ""))
                or ("'" .. string.gsub(tostring(client:SteamID64() or ""), "'", "''") .. "'")
            local ok = pcall(sql.Query, "DELETE FROM ix_characters WHERE id = " .. id .. " AND steamid = " .. quoted)
            return ok
        end

        return false
    end

    local function DeleteInventories(id)
        id = tonumber(id)
        if not id then return end

        local function DeleteInventoryID(inventoryID)
            inventoryID = tonumber(inventoryID)
            if not inventoryID then return end

            if mysql and type(mysql.Delete) == "function" then
                local okItems, itemQuery = pcall(function() return mysql:Delete("ix_items") end)
                if okItems and itemQuery then
                    pcall(function()
                        itemQuery:Where("inventory_id", inventoryID)
                        itemQuery:Execute()
                    end)
                end
            end

            if ix and ix.item and istable(ix.item.inventories) then
                ix.item.inventories[inventoryID] = nil
            end
        end

        if mysql and type(mysql.Select) == "function" then
            local ok, query = pcall(function() return mysql:Select("ix_inventories") end)
            if ok and query then
                pcall(function()
                    query:Select("inventory_id")
                    query:Where("character_id", id)
                    query:Callback(function(rows)
                        for _, row in ipairs(istable(rows) and rows or {}) do
                            DeleteInventoryID(row.inventory_id or row._id or row.id)
                        end

                        local deleteQuery = mysql:Delete("ix_inventories")
                        if deleteQuery then
                            deleteQuery:Where("character_id", id)
                            deleteQuery:Execute()
                        end
                    end)
                    query:Execute()
                end)
                return
            end
        end

        if sql and type(sql.Query) == "function" then
            local rows = sql.Query("SELECT inventory_id FROM ix_inventories WHERE character_id = " .. id)
            for _, row in ipairs(istable(rows) and rows or {}) do
                local inventoryID = tonumber(row.inventory_id or row._id or row.id)
                if inventoryID then
                    pcall(sql.Query, "DELETE FROM ix_items WHERE inventory_id = " .. inventoryID)
                    if ix and ix.item and istable(ix.item.inventories) then
                        ix.item.inventories[inventoryID] = nil
                    end
                end
            end
            pcall(sql.Query, "DELETE FROM ix_inventories WHERE character_id = " .. id)
        end
    end

    local function RemoveFromCaches(client, id)
        RemoveIDFromList(client.ixCharList, id)
        RemoveIDFromList(client.characters, id)
        RemoveIDFromList(client.charList, id)
        RemoveIDFromList(client.CharacterList, id)

        local steam64 = tostring(client:SteamID64() or "")
        local steam = tostring(client:SteamID() or "")

        if ix and ix.char then
            for _, source in ipairs({ix.char.loaded, ix.char.list, ix.char.instances}) do
                RemoveIDFromList(source, id)
            end
            if istable(ix.char.cache) then
                RemoveIDFromList(ix.char.cache, id)
                RemoveIDFromList(ix.char.cache[steam64], id)
                RemoveIDFromList(ix.char.cache[steam], id)
            end
        end

        if ix and istable(ix.characters) then
            RemoveIDFromList(ix.characters, id)
            RemoveIDFromList(ix.characters[steam64], id)
            RemoveIDFromList(ix.characters[steam], id)
            RemoveIDFromList(ix.characters[client], id)
        end
    end

    local function RowValue(row, ...)
        if not istable(row) then return nil end
        for index = 1, select("#", ...) do
            local key = select(index, ...)
            if row[key] ~= nil then return row[key] end
        end
    end

    local function BuildEntry(row)
        local id = tonumber(RowValue(row, "id", "_id"))
        if not id then return nil end
        return {
            id = id,
            name = tostring(RowValue(row, "name", "_name") or ("Operative #" .. id)),
            description = tostring(RowValue(row, "description", "_description", "desc") or ""),
            faction = tonumber(RowValue(row, "faction", "_faction")) or RowValue(row, "faction", "_faction"),
            class = tonumber(RowValue(row, "class", "_class")) or RowValue(row, "class", "_class"),
            model = RowValue(row, "model", "_model"),
            schemaKey = "imperial_order"
        }
    end

    local function SendAuthoritativeList(client)
        if not IsValid(client) then return end

        local function SendRows(rows)
            if not IsValid(client) then return end
            local entries = {}
            for _, row in ipairs(istable(rows) and rows or {}) do
                local entry = BuildEntry(row)
                if entry and (not IMPERIAL_ORDER_IsCharacterDeletedV58 or not IMPERIAL_ORDER_IsCharacterDeletedV58(client, entry.id)) then
                    entries[#entries + 1] = entry
                end
            end
            table.sort(entries, function(a, b) return (tonumber(a.id) or 0) < (tonumber(b.id) or 0) end)

            net.Start(SYNC_V34)
            net.WriteTable(entries)
            net.Send(client)
            net.Start(SYNC_OLD)
            net.WriteTable(entries)
            net.Send(client)
        end

        if mysql and type(mysql.Select) == "function" then
            local ok, query = pcall(function() return mysql:Select("ix_characters") end)
            if ok and query then
                local configured = pcall(function()
                    query:Where("steamid", client:SteamID64())
                    query:Callback(function(rows) SendRows(rows) end)
                end)
                if configured and pcall(function() query:Execute() end) then return end
            end
        end

        if sql and type(sql.Query) == "function" then
            local quoted = sql.SQLStr and sql.SQLStr(tostring(client:SteamID64() or ""))
                or ("'" .. string.gsub(tostring(client:SteamID64() or ""), "'", "''") .. "'")
            local schemaQuoted = sql.SQLStr and sql.SQLStr(tostring(Schema and Schema.folder or "starwarsrp"))
                or ("'" .. string.gsub(tostring(Schema and Schema.folder or "starwarsrp"), "'", "''") .. "'")
            local ok, rows = pcall(sql.Query, "SELECT * FROM ix_characters WHERE steamid = " .. quoted .. " AND schema = " .. schemaQuoted)
            if ok then SendRows(rows) return end
        end

        -- Last-resort cache sync still respects the server-side deleted-ID guard.
        if IMPERIAL_ORDER.QueueCharacterSyncV155 then
            pcall(IMPERIAL_ORDER.QueueCharacterSyncV155, client, {force = true, delay = 0.05})
        elseif IMPERIAL_ORDER_PushCharacterSync then
            pcall(IMPERIAL_ORDER_PushCharacterSync, client)
        end
    end

    local function FinishConfirmedDelete(client, id, character)
        if not IsValid(client) then return end
        pending[client] = nil

        local active = client.GetCharacter and client:GetCharacter() or nil
        local isCurrentCharacter = ReadCharacterID(active) == tonumber(id)

        if IMPERIAL_ORDER_MarkCharacterDeletedV58 then
            pcall(IMPERIAL_ORDER_MarkCharacterDeletedV58, client, id)
        end

        RemoveFromCaches(client, id)
        DeleteInventories(id)

        -- Match Helix's native behavior so every client clears the deleted
        -- character object from its local cache.
        if util.NetworkStringToID("ixCharacterDelete") and util.NetworkStringToID("ixCharacterDelete") > 0 then
            net.Start("ixCharacterDelete")
            net.WriteUInt(id, 32)
            net.Broadcast()
        end

        hook.Run("CharacterDeleted", client, tonumber(id), isCurrentCharacter)

        if isCurrentCharacter then
            if type(client.SetCharacter) == "function" then pcall(client.SetCharacter, client, nil) end
            if type(client.SetNetVar) == "function" then pcall(client.SetNetVar, client, "char", nil) end
            client.ixChar = nil
            client.character = nil
            client.ixCharID = nil

            if client:Alive() then pcall(client.KillSilent, client) end
            pcall(client.StripWeapons, client)
            pcall(client.StripAmmo, client)
        end

        NotifyDeleteResult(client, true, id, "Personnel file deleted and synchronized.")
        SendAuthoritativeList(client)

        timer.Create("IMPERIAL_ORDER.CharacterDelete.FinalSyncV165." .. PlayerToken(client), 0.45, 1, function()
            if IsValid(client) then SendAuthoritativeList(client) end
        end)
    end

    local verifyDelays = {0.12, 0.25, 0.45, 0.75, 1.1, 1.5}

    local function VerifyDeletion(client, id, character, attempt)
        if not IsValid(client) then return end
        local state = pending[client]
        if not state or state.id ~= id then return end

        QueryOwnedRow(client, id, function(queryOK, stillExists)
            if not IsValid(client) then return end
            local current = pending[client]
            if not current or current.id ~= id then return end

            if not queryOK then
                pending[client] = nil
                NotifyDeleteResult(client, false, id, "The character database could not confirm the deletion.")
                return
            end

            if not stillExists then
                FinishConfirmedDelete(client, id, character)
                return
            end

            attempt = tonumber(attempt) or 1
            if attempt >= #verifyDelays then
                pending[client] = nil
                NotifyDeleteResult(client, false, id, "The database still contains this personnel file. No client cache was cleared.")
                return
            end

            timer.Create("IMPERIAL_ORDER.CharacterDelete.VerifyV165." .. PlayerToken(client), verifyDelays[attempt + 1], 1, function()
                VerifyDeletion(client, id, character, attempt + 1)
            end)
        end)
    end

    local function BeginDelete(client, id)
        if not IsValid(client) then return false end
        id = tonumber(id)
        if not id or id <= 0 then
            NotifyDeleteResult(client, false, id, "Invalid personnel file ID.")
            return false
        end

        if pending[client] then
            NotifyDeleteResult(client, false, id, "A personnel file deletion is already being verified.")
            return false
        end

        local now = CurTime()
        if (cooldown[client] or 0) > now then
            NotifyDeleteResult(client, false, id, "Please wait before deleting another personnel file.")
            return false
        end
        cooldown[client] = now + 1

        local character = FindLoadedCharacter(id)
        QueryOwnedRow(client, id, function(queryOK, ownsRow)
            if not IsValid(client) then return end

            if not queryOK then
                NotifyDeleteResult(client, false, id, "The character database is unavailable.")
                return
            end

            if not ownsRow then
                -- The authoritative row is already absent. Treat this as a completed
                -- delete so any stale owner-side menu/cache entry is removed immediately.
                FinishConfirmedDelete(client, id, character)
                return
            end

            -- V206: distinguish a real user-requested deletion from stale cache
            -- cleanup hooks that may fire during character creation.
            client.IMPERIAL_ORDERExplicitDeleteIDsV206 = istable(client.IMPERIAL_ORDERExplicitDeleteIDsV206) and client.IMPERIAL_ORDERExplicitDeleteIDsV206 or {}
            client.IMPERIAL_ORDERExplicitDeleteIDsV206[id] = true
            timer.Simple(30, function()
                if IsValid(client) and istable(client.IMPERIAL_ORDERExplicitDeleteIDsV206) then
                    client.IMPERIAL_ORDERExplicitDeleteIDsV206[id] = nil
                end
            end)
            -- V235 has no numeric-ID tombstone layer. Database deletion is authoritative.
            if character then hook.Run("PreCharacterDeleted", client, character) end
            if not QueueCharacterDelete(client, id) then
                NotifyDeleteResult(client, false, id, "The character delete query could not be queued.")
                return
            end

            pending[client] = {id = id, started = CurTime()}
            timer.Create("IMPERIAL_ORDER.CharacterDelete.VerifyV165." .. PlayerToken(client), verifyDelays[1], 1, function()
                VerifyDeletion(client, id, character, 1)
            end)
        end)

        return true
    end

    local function HandleDeleteRequest(_, client)
        if not IsValid(client) then return end
        BeginDelete(client, net.ReadUInt(32))
    end

    local function InstallReceiver()
        net.Receive(DELETE_REQUEST, HandleDeleteRequest)
        IMPERIAL_ORDER_DELETE_RECEIVER_VERSION = 165
    end
    InstallReceiver()

    hook.Add("PlayerDisconnected", "IMPERIAL_ORDER.CharacterDelete.CleanupV165", function(client)
        pending[client] = nil
        cooldown[client] = nil
        timer.Remove("IMPERIAL_ORDER.CharacterDelete.VerifyV165." .. PlayerToken(client))
        timer.Remove("IMPERIAL_ORDER.CharacterDelete.FinalSyncV165." .. PlayerToken(client))
    end)

    IMPERIAL_ORDER_DeleteCharacterV164 = BeginDelete
    IMPERIAL_ORDER_DeleteCharacterV165 = BeginDelete

    concommand.Add("imperial_order_character_delete_status", function(client)
        if IsValid(client) and not client:IsAdmin() then return end
        local message = "[Imperial Order v165] receiver=" .. tostring(IMPERIAL_ORDER_DELETE_RECEIVER_VERSION)
            .. " database=" .. tostring(mysql ~= nil or sql ~= nil)
            .. " pending=" .. tostring(table.Count(pending))
            .. " ownerOnly=true confirmedDelete=true"

        if IsValid(client) then
            client:PrintMessage(HUD_PRINTCONSOLE, message .. "\n")
        else
            print(message)
        end
    end)
end
