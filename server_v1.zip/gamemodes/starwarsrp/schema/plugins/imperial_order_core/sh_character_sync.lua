IMPERIAL_ORDER_UI_LOADED = IMPERIAL_ORDER_UI_LOADED or {}
IMPERIAL_ORDER_UI_LOADED.character_sync_v236 = true
IMPERIAL_ORDER_UI_LOADED.character_sync_owner_filter_v241 = true

local REQUEST = "IMPERIAL_ORDER.CharacterSync.RequestV34"
local SEND = "IMPERIAL_ORDER.CharacterSync.SendV34"
local DELETE_RESULT = "IMPERIAL_ORDER.CharacterDelete.ResultV36"

local function Read(object, key, getter, fallback, ...)
    if not object then return fallback end

    local keys = {key, ...}
    if istable(object) then
        for _, candidate in ipairs(keys) do
            if candidate and object[candidate] ~= nil then
                return object[candidate]
            end
        end

        if istable(object.vars) then
            for _, candidate in ipairs(keys) do
                if candidate and object.vars[candidate] ~= nil then
                    return object.vars[candidate]
                end
            end
        end
    end

    if getter and type(object[getter]) == "function" then
        local ok, value = pcall(object[getter], object)
        if ok and value ~= nil then return value end
    end

    return fallback
end

local function DecodeModel(value)
    if istable(value) then return tostring(value[1] or "") end

    value = tostring(value or "")
    if string.sub(value, 1, 1) == "[" and util and util.JSONToTable then
        local decoded = util.JSONToTable(value)
        if istable(decoded) then return tostring(decoded[1] or "") end
    end

    return value
end

local function FactionIndex(value)
    local numeric = tonumber(value)
    if numeric then return numeric end

    if ix and ix.faction and ix.faction.teams then
        local faction = ix.faction.teams[tostring(value or "")]
        if faction and faction.index then return tonumber(faction.index) or 0 end
    end

    return 0
end

local function Entry(id, object)
    id = tonumber(Read(object, "id", "GetID", id, "_id")) or tonumber(id)
    if not id or id <= 0 then return nil end

    local model = DecodeModel(Read(object, "model", "GetModel", "", "_model"))
    local faction = Read(object, "faction", "GetFaction", 0, "_faction")

    return {
        id = id,
        name = tostring(Read(object, "name", "GetName", "Operative #" .. id, "_name")),
        description = tostring(Read(object, "description", "GetDescription", "", "_description")),
        faction = FactionIndex(faction),
        class = tonumber(Read(object, "class", "GetClass", 0, "_class")) or 0,
        model = model,
        schemaKey = tostring(Read(object, "imperialOrderSchemaKey", nil, "starwarsrp", "schema", "_schema", "imperial_order_schema_key"))
    }
end

local function Compact(entries)
    local byID = {}
    local output = {}

    for _, entry in pairs(entries or {}) do
        if istable(entry) and tonumber(entry.id) then
            byID[tonumber(entry.id)] = entry
        end
    end

    for _, entry in pairs(byID) do
        output[#output + 1] = entry
    end

    table.sort(output, function(a, b)
        return tonumber(a.id) < tonumber(b.id)
    end)

    return output
end

if SERVER then
    util.AddNetworkString(REQUEST)
    util.AddNetworkString(SEND)
    util.AddNetworkString(DELETE_RESULT)

    local function LoadedCharacter(id)
        id = tonumber(id)
        if not id or not ix or not ix.char or not istable(ix.char.loaded) then return nil end
        return ix.char.loaded[id] or ix.char.loaded[tostring(id)]
    end

    local function AddOwnedIDs(output, source)
        if not istable(source) then return end

        for key, value in pairs(source) do
            local id = tonumber(value)

            if not id and istable(value) then
                id = tonumber(value.id or value._id or value.ID)
                if not id and type(value.GetID) == "function" then
                    local ok, result = pcall(value.GetID, value)
                    if ok then id = tonumber(result) end
                end
            end

            if not id and value == true then id = tonumber(key) end
            if id and id > 0 then output[id] = true end
        end
    end

    local function CharacterBelongsToClient(client, character, id, ownedIDs)
        if not IsValid(client) or not character then return false end

        local steamID64 = tostring(client:SteamID64() or "")
        local storedSteam = tostring(character.steamID or character.steamid or character._steamID or "")

        -- A stored owner is conclusive. Never expose a character whose SteamID
        -- explicitly belongs to somebody else, even if another addon polluted a list.
        if storedSteam ~= "" then return storedSteam == steamID64 end

        if type(character.GetPlayer) == "function" then
            local ok, owner = pcall(character.GetPlayer, character)
            if ok and IsValid(owner) then return owner == client end
        end

        if IsValid(character.player) then return character.player == client end
        if IsValid(character.client) then return character.client == client end

        -- Helix's per-SteamID cache and client.ixCharList are populated server-side.
        -- They are the only acceptable fallback when an old character object lacks
        -- an owner field during the first frame of restoration.
        return ownedIDs[tonumber(id)] == true
    end

    local function OwnedCharacterIDs(client)
        local owned = {}
        if not IsValid(client) then return owned end

        AddOwnedIDs(owned, client.ixCharList)

        if ix and ix.char and istable(ix.char.cache) then
            AddOwnedIDs(owned, ix.char.cache[tostring(client:SteamID64() or "")])
        end

        local active = type(client.GetCharacter) == "function" and client:GetCharacter() or nil
        if active then
            local activeID = tonumber(Read(active, "id", "GetID", nil, "_id"))
            if activeID and activeID > 0 then owned[activeID] = true end
        end

        return owned
    end

    local function Live(client)
        local output = {}
        if not IsValid(client) then return output end

        local ownedIDs = OwnedCharacterIDs(client)
        for id in pairs(ownedIDs) do
            local character = LoadedCharacter(id)
            if character and CharacterBelongsToClient(client, character, id, ownedIDs) then
                local entry = Entry(id, character)
                if entry then output[#output + 1] = entry end
            end
        end

        return Compact(output)
    end

    local function Send(client, entries)
        if not IsValid(client) then return end
        net.Start(SEND)
        net.WriteTable(Compact(entries))
        net.Send(client)
    end

    function IMPERIAL_ORDER_PushCharacterSync(client)
        -- V241: only the requesting player's Helix ownership list is used. Never
        -- merge client.characters, GetCharacters(), global ix.char.loaded rows, or
        -- SQL results into this packet.
        Send(client, Live(client))
    end

    net.Receive(REQUEST, function(_, client)
        IMPERIAL_ORDER_PushCharacterSync(client)
    end)

    hook.Add("PlayerInitialSpawn", "IMPERIAL_ORDER.V241.CharacterSyncJoin", function(client)
        for _, delay in ipairs({1.5, 3, 6}) do
            timer.Simple(delay, function()
                if IsValid(client) then IMPERIAL_ORDER_PushCharacterSync(client) end
            end)
        end
    end)

    hook.Add("OnCharacterCreated", "IMPERIAL_ORDER.V241.CharacterSyncCreated", function(client)
        timer.Simple(0.2, function()
            if IsValid(client) then IMPERIAL_ORDER_PushCharacterSync(client) end
        end)
    end)

    hook.Add("PlayerLoadedCharacter", "IMPERIAL_ORDER.V241.CharacterSyncLoaded", function(client)
        IMPERIAL_ORDER_PushCharacterSync(client)
    end)

    hook.Add("CharacterDeleted", "IMPERIAL_ORDER.V241.CharacterSyncDeleted", function(client)
        timer.Simple(0.2, function()
            if IsValid(client) then IMPERIAL_ORDER_PushCharacterSync(client) end
        end)
    end)

    concommand.Add("imperial_order_character_ownership_status", function(client, _, args)
        if IsValid(client) and not client:IsAdmin() then return end

        local target = client
        local wanted = tostring(args and args[1] or "")
        if wanted ~= "" then
            for _, candidate in ipairs(player.GetAll()) do
                if tostring(candidate:SteamID64() or "") == wanted or tostring(candidate:SteamID() or "") == wanted then
                    target = candidate
                    break
                end
            end
        end

        if not IsValid(target) then
            print("[Imperial Order V241] Usage: imperial_order_character_ownership_status [online SteamID64]")
            return
        end

        local ids = {}
        for id in pairs(OwnedCharacterIDs(target)) do ids[#ids + 1] = tonumber(id) end
        table.sort(ids)

        local line = "[Imperial Order V241] " .. target:Nick() .. " owns: " .. (#ids > 0 and table.concat(ids, ", ") or "none")
        if IsValid(client) then
            client:PrintMessage(HUD_PRINTCONSOLE, line .. "\n")
        else
            print(line)
        end
    end)
else
    IMPERIAL_ORDER_CHARACTER_CACHE = IMPERIAL_ORDER_CHARACTER_CACHE or {}
    local nextRequest = 0

    local function Replace(entries)
        -- Replacement is intentional: never merge a previous player's or stale
        -- session's cache into the newly authorized list.
        IMPERIAL_ORDER_CHARACTER_CACHE = Compact(entries)
        IMPERIAL_ORDER_LAST_CHARACTER_SYNC = CurTime()
        hook.Run("IMPERIAL_ORDERCharacterCacheUpdated", IMPERIAL_ORDER_CHARACTER_CACHE)
    end

    net.Receive(SEND, function()
        Replace(net.ReadTable() or {})
    end)

    function IMPERIAL_ORDER_RequestCharacterSyncV34(force)
        if not force and nextRequest > CurTime() then return false end
        nextRequest = CurTime() + 0.75
        net.Start(REQUEST)
        net.SendToServer()
        return true
    end

    IMPERIAL_ORDER_RequestCharacterSync = IMPERIAL_ORDER_RequestCharacterSyncV34

    net.Receive(DELETE_RESULT, function()
        local ok = net.ReadBool()
        local id = net.ReadUInt(32)
        local message = net.ReadString()

        if ok then
            local kept = {}
            for _, entry in ipairs(IMPERIAL_ORDER_CHARACTER_CACHE or {}) do
                if tonumber(entry.id) ~= tonumber(id) then kept[#kept + 1] = entry end
            end
            Replace(kept)
            local noCharactersRemain = #IMPERIAL_ORDER_CHARACTER_CACHE == 0
            hook.Run("IMPERIAL_ORDERCharacterDeletedClient", tonumber(id), noCharactersRemain)
            timer.Simple(0.25, function() IMPERIAL_ORDER_RequestCharacterSyncV34(true) end)
        end

        if ImperialUI and ImperialUI.Notify then
            ImperialUI.Notify(message, ok and "success" or "warning", 5)
        elseif ix and ix.util and ix.util.Notify then
            ix.util.Notify(message)
        end
    end)

    function IMPERIAL_ORDER_RequestCharacterDeleteV36(id)
        id = tonumber(id)
        if not id or id <= 0 then return false end

        net.Start("IMPERIAL_ORDER.CharacterDelete.RequestV36")
        net.WriteUInt(id, 32)
        net.SendToServer()
        return true
    end
end
