IMPERIAL_ORDER_UI_LOADED = IMPERIAL_ORDER_UI_LOADED or {}

local listReq = "IMPERIAL_ORDER.AdminCharEdit.ListRequestV43"
local listSend = "IMPERIAL_ORDER.AdminCharEdit.ListSendV43"
local updateReq = "IMPERIAL_ORDER.AdminCharEdit.UpdateRequestV43"
local updateResult = "IMPERIAL_ORDER.AdminCharEdit.UpdateResultV43"
local deleteReq = "IMPERIAL_ORDER.AdminCharEdit.DeleteRequestV44"
local deleteResult = "IMPERIAL_ORDER.AdminCharEdit.DeleteResultV44"
local openMenu = "IMPERIAL_ORDER.AdminCharEdit.OpenV43"

local function CanEditCharacters(client)
    if not IsValid(client) then return false end
    if client:IsSuperAdmin() then return true end
    if client:IsAdmin() then return true end
    return false
end

local function SafeCall(obj, method, ...)
    if not obj or not obj[method] or type(obj[method]) ~= "function" then return nil, false end
    local ok, a, b, c = pcall(obj[method], obj, ...)
    if not ok then return nil, false end
    return a, true, b, c
end

local function ReadID(data, fallback)
    if data == nil then return fallback end
    if isnumber(data) then return data end
    if isstring(data) and tonumber(data) then return tonumber(data) end
    if istable(data) then
        if data.id ~= nil then return data.id end
        if data.ID ~= nil then return data.ID end
        local value = SafeCall(data, "GetID")
        if value ~= nil then return value end
    end
    return fallback
end

local function ReadValue(data, key, getter)
    if not istable(data) then return nil end
    if data[key] ~= nil then return data[key] end
    if istable(data.vars) and data.vars[key] ~= nil then return data.vars[key] end
    if getter then
        local value = SafeCall(data, getter)
        if value ~= nil then return value end
    end
    local value = SafeCall(data, "GetVar", key)
    if value ~= nil then return value end
    value = SafeCall(data, "GetData", key)
    if value ~= nil then return value end
    return nil
end

if SERVER then
    util.AddNetworkString(listReq)
    util.AddNetworkString(listSend)
    util.AddNetworkString(updateReq)
    util.AddNetworkString(updateResult)
    util.AddNetworkString(deleteReq)
    util.AddNetworkString(deleteResult)
    util.AddNetworkString(openMenu)

    local function SendResult(client, ok, message)
        if not IsValid(client) then return end
        net.Start(updateResult)
        net.WriteBool(ok == true)
        net.WriteString(tostring(message or ""))
        net.Send(client)
    end

    local function SendDeleteResult(client, ok, id, message)
        if not IsValid(client) then return end
        net.Start(deleteResult)
        net.WriteBool(ok == true)
        net.WriteUInt(tonumber(id) or 0, 32)
        net.WriteString(tostring(message or ""))
        net.Send(client)
    end

    local function GetDepartmentName(id)
        id = tonumber(id)
        local faction = id and ix and ix.faction and ix.faction.indices and ix.faction.indices[id]
        if istable(faction) then return tostring(faction.name or faction.uniqueID or id) end
        return tostring(id or "")
    end

    local function GetClassName(id)
        id = tonumber(id)
        local class = id and ix and ix.class and ix.class.list and ix.class.list[id]
        if istable(class) then return tostring(class.name or class.uniqueID or id) end
        return tostring(id or "")
    end

    local function FindCharacter(id)
        id = tonumber(id)
        if not id then return nil, nil end
        for _, ply in ipairs(player.GetAll()) do
            local char = ply.GetCharacter and ply:GetCharacter() or nil
            if istable(char) and tonumber(ReadID(char)) == id then
                return char, ply
            end
        end
        if ix and ix.char then
            local sources = {ix.char.loaded, ix.char.cache, ix.char.list, ix.char.instances}
            for _, source in ipairs(sources) do
                if istable(source) then
                    local direct = source[id]
                    if istable(direct) and tonumber(ReadID(direct, id)) == id then
                        local owner = SafeCall(direct, "GetPlayer")
                        return direct, IsValid(owner) and owner or nil
                    end
                    for key, value in pairs(source) do
                        if istable(value) and tonumber(ReadID(value, key)) == id then
                            local owner = SafeCall(value, "GetPlayer")
                            return value, IsValid(owner) and owner or nil
                        end
                    end
                end
            end
        end
        return nil, nil
    end

    local function GetCharacterList()
        local seen = {}
        local output = {}
        local function addChar(char, owner)
            if not istable(char) then return end
            local id = tonumber(ReadID(char))
            if not id or seen[id] then return end
            seen[id] = true
            local faction = tonumber(ReadValue(char, "faction", "GetFaction")) or 0
            local class = tonumber(ReadValue(char, "class", "GetClass")) or 0
            output[#output + 1] = {
                id = id,
                player = IsValid(owner) and owner:Nick() or "Offline/Loaded",
                steamID = IsValid(owner) and owner:SteamID64() or "",
                name = tostring(ReadValue(char, "name", "GetName") or ("Operative #" .. id)),
                description = tostring(ReadValue(char, "description", "GetDescription") or ReadValue(char, "desc") or ""),
                faction = faction,
                factionName = GetDepartmentName(faction),
                class = class,
                className = GetClassName(class),
                model = tostring(ReadValue(char, "model", "GetModel") or ""),
                homeworld = tostring(ReadValue(char, "homeworld") or "Unknown"),
                credits = tonumber(ReadValue(char, "credits")) or 0,
                imperialOrderLevel = tonumber(ReadValue(char, "imperialOrderLevel")) or 1,
                imperialOrderXP = tonumber(ReadValue(char, "imperialOrderXP")) or 0,
                imperialOrderSkillPoints = tonumber(ReadValue(char, "imperialOrderSkillPoints")) or 0
            }
        end
        for _, ply in ipairs(player.GetAll()) do
            local char = ply.GetCharacter and ply:GetCharacter() or nil
            addChar(char, ply)
        end
        if ix and ix.char then
            local sources = {ix.char.loaded, ix.char.cache, ix.char.list, ix.char.instances}
            for _, source in ipairs(sources) do
                if istable(source) then
                    for _, char in pairs(source) do
                        if istable(char) then addChar(char, SafeCall(char, "GetPlayer")) end
                    end
                end
            end
        end
        table.sort(output, function(a, b)
            return (tonumber(a.id) or 0) < (tonumber(b.id) or 0)
        end)
        return output
    end

    local function GetDepartmentList()
        local output = {}
        if ix and ix.faction and ix.faction.indices then
            for id, faction in pairs(ix.faction.indices) do
                if istable(faction) then
                    output[#output + 1] = {id = tonumber(id) or id, name = tostring(faction.name or faction.uniqueID or id)}
                end
            end
        end
        table.sort(output, function(a, b) return tostring(a.name) < tostring(b.name) end)
        return output
    end

    local function GetClassList()
        local output = {}
        if ix and ix.class and ix.class.list then
            for id, class in pairs(ix.class.list) do
                if istable(class) then
                    output[#output + 1] = {
                        id = tonumber(id) or id,
                        name = tostring(class.name or class.uniqueID or id),
                        faction = tonumber(class.faction) or 0
                    }
                end
            end
        end
        table.sort(output, function(a, b) return tostring(a.name) < tostring(b.name) end)
        return output
    end

    local function ReadRowValue(row, keys, fallback)
        if not istable(row) then return fallback end
        for _, key in ipairs(keys) do
            local value = row[key]
            if value ~= nil and tostring(value) ~= "" then return value end
        end
        return fallback
    end

    local function IsImperialSchemaRow(row)
        if not istable(row) then return false end
        local marker = string.lower(string.Trim(tostring(ReadRowValue(row, {
            "schema", "_schema", "imperial_order_schema_key", "imperialOrderSchemaKey", "imperial_order_server_name"
        }, ""))))

        -- Older valid rows may have no schema marker. Keep them visible to admins
        -- so broken/offline personnel files can still be deleted.
        return marker == ""
            or marker == "starwarsrp"
            or marker == "imperial_order"
            or marker == "ix: Imperial Order roleplay"
    end

    local function OnlineNameForSteamID(steamID)
        steamID = tostring(steamID or "")
        for _, ply in ipairs(player.GetAll()) do
            if tostring(ply:SteamID64() or "") == steamID or tostring(ply:SteamID() or "") == steamID then
                return ply:Nick()
            end
        end
        return steamID ~= "" and steamID or "Offline/Database"
    end

    local function CharacterEntryFromRow(row)
        if not IsImperialSchemaRow(row) then return nil end

        local id = tonumber(ReadRowValue(row, {"id", "_id", "ID"}))
        if not id or id <= 0 then return nil end

        local faction = tonumber(ReadRowValue(row, {"faction", "_faction"}, 0)) or 0
        local class = tonumber(ReadRowValue(row, {"class", "_class"}, 0)) or 0
        local steamID = tostring(ReadRowValue(row, {"steamid", "steamID", "_steamID", "steamid64", "steamID64"}, ""))

        return {
            id = id,
            player = OnlineNameForSteamID(steamID),
            steamID = steamID,
            name = tostring(ReadRowValue(row, {"name", "_name"}, "Operative #" .. id)),
            description = tostring(ReadRowValue(row, {"description", "_description", "desc", "_desc"}, "")),
            faction = faction,
            factionName = GetDepartmentName(faction),
            class = class,
            className = GetClassName(class),
            model = tostring(ReadRowValue(row, {"model", "_model"}, "")),
            homeworld = tostring(ReadRowValue(row, {"imperial_order_homeworld", "homeworld", "_homeworld"}, "Unknown")),
            credits = tonumber(ReadRowValue(row, {"imperial_order_credits", "credits", "money", "_money"}, 0)) or 0,
            imperialOrderLevel = tonumber(ReadRowValue(row, {"imperial_order_level", "imperialOrderLevel", "level"}, 1)) or 1,
            imperialOrderXP = tonumber(ReadRowValue(row, {"imperial_order_xp", "imperialOrderXP", "xp"}, 0)) or 0,
            imperialOrderSkillPoints = tonumber(ReadRowValue(row, {"imperial_order_skill_points", "imperialOrderSkillPoints", "skillPoints"}, 0)) or 0,
            databaseOnly = true
        }
    end

    local function MergeCharacterEntries(liveEntries, rows)
        local merged = {}
        local byID = {}

        for _, entry in ipairs(istable(liveEntries) and liveEntries or {}) do
            local id = tonumber(entry.id)
            if id and id > 0 then
                byID[id] = entry
                merged[#merged + 1] = entry
            end
        end

        for _, row in ipairs(istable(rows) and rows or {}) do
            local entry = CharacterEntryFromRow(row)
            if entry and not byID[entry.id] then
                byID[entry.id] = entry
                merged[#merged + 1] = entry
            end
        end

        table.sort(merged, function(a, b)
            return (tonumber(a.id) or 0) < (tonumber(b.id) or 0)
        end)

        return merged
    end

    local function QueryAllCharacterRows(callback)
        local finished = false
        local function done(rows)
            if finished then return end
            finished = true
            callback(istable(rows) and rows or {})
        end

        if mysql and type(mysql.Select) == "function" then
            local ok, query = pcall(function() return mysql:Select("ix_characters") end)
            if ok and query and type(query.Callback) == "function" and type(query.Execute) == "function" then
                local configured = pcall(function()
                    query:Callback(function(rows) done(rows) end)
                end)
                if configured and pcall(function() query:Execute() end) then
                    timer.Simple(3, function() done({}) end)
                    return
                end
            end
        end

        if sql and type(sql.Query) == "function" then
            local ok, rows = pcall(sql.Query, "SELECT * FROM ix_characters")
            if ok then
                done(rows)
                return
            end
        end

        done({})
    end

    local function SendList(client)
        if not CanEditCharacters(client) then
            SendResult(client, false, "You do not have permission to edit characters.")
            return
        end

        local liveEntries = GetCharacterList()
        QueryAllCharacterRows(function(rows)
            if not IsValid(client) then return end
            net.Start(listSend)
            net.WriteTable({
                characters = MergeCharacterEntries(liveEntries, rows),
                factions = GetDepartmentList(),
                classes = GetClassList()
            })
            net.Send(client)
        end)
    end

    local function SetStoredValue(char, key, value)
        if not istable(char) then return end
        pcall(function()
            if char.SetVar then char:SetVar(key, value) end
        end)
        pcall(function()
            if char.SetData then char:SetData(key, value) end
        end)
        char.vars = char.vars or {}
        char.vars[key] = value
    end

    local function ApplyString(char, methodList, key, value, maxLen)
        value = string.Trim(tostring(value or ""))
        if value == "" then return end
        value = string.sub(value, 1, maxLen or 512)
        local applied = false
        for _, method in ipairs(methodList) do
            local _, ok = SafeCall(char, method, value)
            if ok then applied = true end
        end
        if key then SetStoredValue(char, key, value) end
        return applied
    end

    local function ApplyNumber(char, key, value, minValue, maxValue)
        value = tonumber(value)
        if value == nil then return end
        value = math.floor(math.Clamp(value, minValue or 0, maxValue or 999999999))
        SetStoredValue(char, key, value)
    end

    local function ValidateModel(model)
        model = string.Trim(tostring(model or ""))
        if model == "" then return nil end
        if not string.StartWith(string.lower(model), "models/") then return nil end
        if not string.EndsWith(string.lower(model), ".mdl") then return nil end
        if util and util.IsValidModel and util.IsValidModel(model) == false then return nil end
        return model
    end

    local function ApplyUpdate(admin, char, owner, data)
        if not istable(char) then return false, "Imperial personnel file was not found or is not loaded." end
        if not istable(data) then return false, "No edit data was sent." end
        ApplyString(char, {"SetName"}, "name", data.name, 64)
        ApplyString(char, {"SetDescription", "SetDesc"}, "description", data.description, 1024)
        ApplyString(char, {}, "homeworld", data.homeworld, 64)
        ApplyNumber(char, "credits", data.credits, 0, 999999999)
        ApplyNumber(char, "imperialOrderLevel", data.imperialOrderLevel, 1, 999)
        ApplyNumber(char, "imperialOrderXP", data.imperialOrderXP, 0, 999999999)
        ApplyNumber(char, "imperialOrderSkillPoints", data.imperialOrderSkillPoints, 0, 9999)
        local model = ValidateModel(data.model)
        if model then
            local _, ok = SafeCall(char, "SetModel", model)
            if not ok then SetStoredValue(char, "model", model) end
            if IsValid(owner) then owner:SetModel(model) end
        end
        local faction = tonumber(data.faction)
        if faction and ix and ix.faction and ix.faction.indices and ix.faction.indices[faction] then
            local _, ok = SafeCall(char, "SetFaction", faction)
            if not ok then SetStoredValue(char, "faction", faction) end
        end
        local class = tonumber(data.class)
        if class and ix and ix.class and ix.class.list and ix.class.list[class] then
            local classData = ix.class.list[class]
            local currentDepartment = tonumber(ReadValue(char, "faction", "GetFaction")) or faction
            if not tonumber(classData.faction) or tonumber(classData.faction) == 0 or tonumber(classData.faction) == tonumber(currentDepartment) then
                local _, ok = SafeCall(char, "SetClass", class)
                if not ok then SetStoredValue(char, "class", class) end
                -- Persist an independent class hint so legacy/custom character loads
                -- can recover the intended job even if Helix returns a blank class.
                SetStoredValue(char, "imperial_orderAssignedClass", class)
            else
                return false, "That class does not belong to the selected faction."
            end
        end
        SafeCall(char, "Save")
        SafeCall(char, "Sync", owner)
        if IsValid(owner) and owner.GetCharacter and owner:GetCharacter() == char then
            timer.Simple(0, function()
                if IsValid(owner) then
                    if IMPERIAL_ORDER_EnsurePlayerVisible then IMPERIAL_ORDER_EnsurePlayerVisible(owner) end
                    if IMPERIAL_ORDER_PushCharacterSync then IMPERIAL_ORDER_PushCharacterSync(owner) end
                    if IMPERIAL_ORDER_QueueWeaponLoadoutV223 then IMPERIAL_ORDER_QueueWeaponLoadoutV223(owner, "admin character edit") end
                end
            end)
        end
        return true, "Imperial personnel file edited successfully."
    end

    local function DeleteFromTables(id)
        id = tonumber(id)
        if not id then return false end

        local deleted = false
        local deleteFields = {
            ix_characters = {"id", "_id"},
            ix_character_data = {"id", "_id", "character_id", "charID"},
            ix_characters_data = {"id", "_id", "character_id", "charID"}
        }

        -- Helix query-builder path (SQLite or MySQL). Each candidate key is a
        -- separate query; combining id and _id in one query would create an AND
        -- condition and fail on installations that expose only one of them.
        if mysql and type(mysql.Delete) == "function" then
            for tableName, fields in pairs(deleteFields) do
                for _, fieldName in ipairs(fields) do
                    local ok, query = pcall(function() return mysql:Delete(tableName) end)
                    if ok and query and type(query.Where) == "function" and type(query.Execute) == "function" then
                        local queued = pcall(function()
                            query:Where(fieldName, id)
                            query:Execute()
                        end)
                        deleted = queued or deleted
                    end
                end
            end
        end

        -- Direct SQLite fallback. Missing legacy tables/columns are ignored.
        if sql and type(sql.Query) == "function" then
            for tableName, fields in pairs(deleteFields) do
                for _, fieldName in ipairs(fields) do
                    local ok = pcall(sql.Query, "DELETE FROM " .. tableName .. " WHERE " .. fieldName .. " = " .. id)
                    deleted = ok or deleted
                end
            end
        end

        return deleted
    end

    local function RemoveFromCaches(id)
        id = tonumber(id) or id
        if ix and ix.char then
            local sources = {ix.char.loaded, ix.char.cache, ix.char.list, ix.char.instances}
            for _, source in ipairs(sources) do
                if istable(source) then
                    source[id] = nil
                    source[tostring(id)] = nil
                    for key, value in pairs(source) do
                        if istable(value) and tostring(ReadID(value, key) or "") == tostring(id or "") then
                            source[key] = nil
                        end
                    end
                end
            end
        end
    end

    local function DeleteCharacterForAdmin(admin, id)
        id = tonumber(id)
        if not CanEditCharacters(admin) then return false, "You do not have permission to delete characters." end
        if not id or id <= 0 then return false, "Invalid character ID." end
        local char, owner = FindCharacter(id)
        local deleted = false
        if char then
            local methods = {"Delete", "Remove"}
            for _, method in ipairs(methods) do
                if char[method] and type(char[method]) == "function" then
                    local ok = pcall(char[method], char)
                    if ok then deleted = true end
                end
            end
        end
        if ix and ix.char then
            local calls = {
                function() if ix.char.Delete then return ix.char.Delete(id) end end,
                function() if ix.char.DeleteByID then return ix.char.DeleteByID(id) end end,
                function() if ix.char.Remove then return ix.char.Remove(id) end end
            }
            for _, call in ipairs(calls) do
                local ok = pcall(call)
                if ok then deleted = true end
            end
        end
        if DeleteFromTables(id) then deleted = true end
        RemoveFromCaches(id)
        if IsValid(owner) then
            local active = owner.GetCharacter and owner:GetCharacter() or nil
            if active and tostring(ReadID(active) or "") == tostring(id) then
                pcall(function() if owner.SetCharacter then owner:SetCharacter(nil) end end)
                pcall(function() owner.ixCharID = nil end)
                pcall(function() owner:SetNoDraw(false) end)
                pcall(function() if owner.SetCharacter then owner:SetCharacter(nil) end end)
            end
            timer.Simple(0.2, function()
                if IsValid(owner) and IMPERIAL_ORDER_PushCharacterSync then IMPERIAL_ORDER_PushCharacterSync(owner) end
            end)
            pcall(function()
                if ix and ix.util and ix.util.Notify then ix.util.Notify("Your Imperial personnel file was deleted by an administrator.", owner) end
            end)
        end
        if deleted then return true, "Imperial personnel file deleted successfully." end
        return false, "Imperial personnel file deletion failed. It may be offline in an external database or already removed."
    end

    net.Receive(listReq, function(_, client)
        SendList(client)
    end)

    net.Receive(updateReq, function(_, client)
        if not CanEditCharacters(client) then
            SendResult(client, false, "You do not have permission to edit characters.")
            return
        end
        local id = net.ReadUInt(32)
        local okRead, data = pcall(net.ReadTable)
        if not okRead then
            SendResult(client, false, "Could not read character edit data.")
            return
        end
        local char, owner = FindCharacter(id)
        local ok, message = ApplyUpdate(client, char, owner, data)
        SendResult(client, ok, message)
        if ok then
            timer.Simple(0.2, function()
                if IsValid(client) then SendList(client) end
                if IsValid(owner) and IMPERIAL_ORDER_PushCharacterSync then IMPERIAL_ORDER_PushCharacterSync(owner) end
            end)
        end
    end)

    net.Receive(deleteReq, function(_, client)
        if not CanEditCharacters(client) then
            SendDeleteResult(client, false, 0, "You do not have permission to delete characters.")
            return
        end
        local id = net.ReadUInt(32)
        local ok, message = DeleteCharacterForAdmin(client, id)
        SendDeleteResult(client, ok, id, message)
        if ok then
            timer.Simple(0.2, function() if IsValid(client) then SendList(client) end end)
        end
    end)

    if ix and ix.command then
        ix.command.Add("CharEdit", {
            description = "Open the Imperial department personnel command editor.",
            adminOnly = true,
            OnRun = function(self, client)
                if not CanEditCharacters(client) then return "You do not have permission to edit characters." end
                net.Start(openMenu)
                net.Send(client)
            end
        })
    end
else
    IMPERIAL_ORDER_UI_LOADED.admin_character_editor_v43 = true
    IMPERIAL_ORDER_UI_LOADED.admin_char_command_v43 = true
    IMPERIAL_ORDER_UI_LOADED.admin_character_delete_v44 = true
    IMPERIAL_ORDER_UI_LOADED.admin_delete_button_v44 = true
    IMPERIAL_ORDER_UI_LOADED.admin_delete_quick_button_v66 = true

    local frame
    local cachedData = {characters = {}, factions = {}, classes = {}}

    local function Notify(message)
        if ix and ix.util and ix.util.Notify then
            ix.util.Notify(tostring(message or ""))
        else
            chat.AddText(Color(190, 38, 38), "[IMPERIAL_ORDER] ", color_white, tostring(message or ""))
        end
    end

    -- V220: this shared file can run before the legacy IMPERIAL_ORDERUI palette helper is
    -- installed. Checking only that IMPERIAL_ORDERUI exists is not enough because V174
    -- creates the table without defining Col/Alpha. Keep the editor self-contained
    -- so admin character recovery remains available even when another UI module
    -- fails or loads later.
    local function UICol(name, fallback)
        local ui = rawget(_G, "IMPERIAL_ORDERUI")
        if istable(ui) and isfunction(ui.Col) then
            local ok, value = pcall(ui.Col, name, fallback)
            if ok and value then return value end
        end

        local palette = rawget(_G, "IMPERIAL_ORDER_COLORS")
        if istable(palette) and palette[name] then return palette[name] end
        return fallback or color_white
    end

    local function UIAlpha(col, alpha)
        local ui = rawget(_G, "IMPERIAL_ORDERUI")
        if istable(ui) and isfunction(ui.Alpha) then
            local ok, value = pcall(ui.Alpha, col, alpha)
            if ok and value then return value end
        end

        col = col or color_white
        return Color(col.r or 255, col.g or 255, col.b or 255, tonumber(alpha) or col.a or 255)
    end

    local function MakeLabel(parent, text)
        local label = parent:Add("DLabel")
        label:SetText(text)
        label:SetFont("IMPERIAL_ORDER.UI.Small")
        label:SetTextColor(UICol("textDim", Color(188, 194, 204)))
        label:Dock(TOP)
        label:DockMargin(0, 6, 0, 2)
        return label
    end

    local function MakeEntry(parent, tall)
        local entry = parent:Add("DTextEntry")
        entry:Dock(TOP)
        entry:SetTall(tall or 28)
        entry:SetFont("IMPERIAL_ORDER.UI.Body")
        entry:SetTextColor(UICol("text", Color(246, 247, 250)))
        entry:SetCursorColor(UICol("white", color_white))
        entry:SetHighlightColor(UICol("red", Color(190, 38, 38)))
        -- Consistent Imperial input chrome instead of the default light Derma box,
        -- matching the same look every other panel in the schema uses.
        entry.Paint = function(self, w, h)
            draw.RoundedBox(4, 0, 0, w, h, Color(6, 7, 10, 245))
            draw.RoundedBox(4, 2, 2, w - 4, h - 4, UIAlpha(UICol("panelAlt", Color(20, 22, 27)), 244))
            surface.SetDrawColor(self:HasFocus() and (UICol("crimson", Color(215, 42, 42))) or (UICol("border", Color(128, 136, 148))))
            surface.DrawOutlinedRect(0, 0, w, h, 1)
            self:DrawTextEntryText(UICol("text", Color(246, 247, 250)), UICol("red", Color(190, 38, 38)), UICol("white", color_white))
        end
        return entry
    end

    local function RequestList()
        net.Start(listReq)
        net.SendToServer()
    end

    local function OpenEditor(data)
        cachedData = data or cachedData
        if IsValid(frame) then frame:Remove() end
        frame = vgui.Create("DFrame")
        frame:SetSize(math.min(ScrW() - 80, 1000), math.min(ScrH() - 80, 720))
        frame:Center()
        frame:SetTitle("")
        frame:MakePopup()
        -- Marked as an IMPERIAL_ORDER-styled panel so the global derma compat sweep
        -- (cl_derma_compat_v93.lua) leaves this custom chrome alone instead
        -- of overwriting it with the generic default-Derma skin a couple
        -- seconds after opening.
        frame.IMPERIAL_ORDERDermaNoStyle = true
        frame.Paint = function(self, w, h)
            if IMPERIAL_ORDERUI and isfunction(IMPERIAL_ORDERUI.Panel) then
                IMPERIAL_ORDERUI.Panel(0, 0, w, h, "IMPERIAL ADMIN CHARACTER EDITOR", nil, false)
            else
                draw.RoundedBox(8, 0, 0, w, h, Color(2, 2, 3, 244))
                draw.RoundedBox(8, 3, 3, w - 6, h - 6, Color(11, 12, 15, 240))
                surface.SetDrawColor(Color(128, 136, 148))
                surface.DrawOutlinedRect(0, 0, w, h, 1)
                surface.SetDrawColor(Color(190, 38, 38))
                surface.DrawRect(0, 0, 5, h)
            end
        end

        if IsValid(frame.btnClose) then
            frame.btnClose:SetText("X")
            frame.btnClose:SetTextColor(UICol("white", color_white))
            frame.btnClose.Paint = function(self, w, h)
                draw.RoundedBox(4, 0, 0, w, h, self:IsHovered() and (UICol("crimson", Color(215, 42, 42))) or Color(36, 12, 14, 245))
                surface.SetDrawColor(UICol("border", Color(128, 136, 148)))
                surface.DrawOutlinedRect(0, 0, w, h, 1)
            end
        end

        local left = frame:Add("DPanel")
        left:Dock(LEFT)
        left:SetWide(420)
        left:DockMargin(10, 34, 8, 10)
        left.IMPERIAL_ORDERDermaNoStyle = true
        left.Paint = function(self, w, h)
            draw.RoundedBox(5, 0, 0, w, h, UIAlpha(UICol("panelAlt", Color(20, 22, 27)), 220))
            surface.SetDrawColor(UIAlpha(UICol("border", Color(128, 136, 148)), 105))
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end

        local right = frame:Add("DPanel")
        right:Dock(FILL)
        right:DockMargin(0, 34, 10, 10)
        right.IMPERIAL_ORDERDermaNoStyle = true
        right.Paint = function(self, w, h)
            draw.RoundedBox(5, 0, 0, w, h, UIAlpha(UICol("panelAlt", Color(20, 22, 27)), 220))
            surface.SetDrawColor(UIAlpha(UICol("border", Color(128, 136, 148)), 105))
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end

        local refresh = left:Add("DButton")
        refresh:SetText("Refresh Characters")
        refresh:Dock(TOP)
        refresh:SetTall(32)
        refresh:DockMargin(8, 8, 8, 6)
        refresh.DoClick = RequestList

        local list = left:Add("DListView")
        list:Dock(FILL)
        list:DockMargin(8, 0, 8, 8)
        list:AddColumn("ID"):SetFixedWidth(48)
        list:AddColumn("Player")
        list:AddColumn("Character")
        list:AddColumn("Department")

        local holder = right:Add("DScrollPanel")
        holder:Dock(FILL)
        holder:DockMargin(12, 10, 12, 10)

        local selectedID = 0
        local selectedDepartment = nil
        local selectedClass = nil

        local function AdminDeleteSelected()
            if selectedID <= 0 then
                Notify("Select a character first.")
                return
            end
            Derma_Query("Delete selected character ID " .. tostring(selectedID) .. "? This cannot be undone.", "Confirm Admin Delete", "Delete", function()
                net.Start(deleteReq)
                net.WriteUInt(selectedID, 32)
                net.SendToServer()
            end, "Cancel")
        end

        local quickDelete = holder:Add("DButton")
        quickDelete:SetText("ADMIN DELETE CHARACTER")
        quickDelete:SetFont("IMPERIAL_ORDER.UI.Small")
        quickDelete:Dock(TOP)
        quickDelete:SetTall(42)
        quickDelete:DockMargin(0, 0, 0, 10)
        quickDelete:SetTextColor(UICol("white", color_white))
        quickDelete.Paint = function(self, w, h)
            draw.RoundedBox(4, 0, 0, w, h, self:IsHovered() and (UICol("crimson", Color(215, 42, 42))) or (UICol("redDark", Color(92, 12, 16))))
            surface.SetDrawColor(UICol("border", Color(128, 136, 148)))
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end
        quickDelete.DoClick = AdminDeleteSelected

        MakeLabel(holder, "Name")
        local nameEntry = MakeEntry(holder)
        MakeLabel(holder, "Description")
        local descEntry = MakeEntry(holder, 70)
        descEntry:SetMultiline(true)
        MakeLabel(holder, "Model Path")
        local modelEntry = MakeEntry(holder)
        MakeLabel(holder, "Homeworld")
        local homeworldEntry = MakeEntry(holder)
        MakeLabel(holder, "Credits")
        local creditsEntry = MakeEntry(holder)
        MakeLabel(holder, "Level")
        local levelEntry = MakeEntry(holder)
        MakeLabel(holder, "XP")
        local xpEntry = MakeEntry(holder)
        MakeLabel(holder, "Skill Points")
        local skillEntry = MakeEntry(holder)

        MakeLabel(holder, "Department")
        local factionBox = holder:Add("DComboBox")
        factionBox:Dock(TOP)
        factionBox:SetTall(28)
        factionBox:SetFont("IMPERIAL_ORDER.UI.Body")
        factionBox:SetTextColor(UICol("text", Color(246, 247, 250)))
        factionBox:AddChoice("Keep Current", nil)
        for _, faction in ipairs(cachedData.factions or {}) do
            factionBox:AddChoice(tostring(faction.name), tonumber(faction.id))
        end
        factionBox.OnSelect = function(_, _, _, value) selectedDepartment = value end

        MakeLabel(holder, "Class")
        local classBox = holder:Add("DComboBox")
        classBox:Dock(TOP)
        classBox:SetTall(28)
        classBox:SetFont("IMPERIAL_ORDER.UI.Body")
        classBox:SetTextColor(UICol("text", Color(246, 247, 250)))
        classBox:AddChoice("Keep Current", nil)
        for _, class in ipairs(cachedData.classes or {}) do
            classBox:AddChoice(tostring(class.name), tonumber(class.id))
        end
        classBox.OnSelect = function(_, _, _, value) selectedClass = value end

        local save = holder:Add("DButton")
        save:SetText("Save Character")
        save:Dock(TOP)
        save:SetTall(38)
        save:DockMargin(0, 14, 0, 0)
        save.DoClick = function()
            if selectedID <= 0 then
                Notify("Select a character first.")
                return
            end
            net.Start(updateReq)
            net.WriteUInt(selectedID, 32)
            net.WriteTable({
                name = nameEntry:GetValue(),
                description = descEntry:GetValue(),
                model = modelEntry:GetValue(),
                homeworld = homeworldEntry:GetValue(),
                credits = creditsEntry:GetValue(),
                imperialOrderLevel = levelEntry:GetValue(),
                imperialOrderXP = xpEntry:GetValue(),
                imperialOrderSkillPoints = skillEntry:GetValue(),
                faction = selectedDepartment,
                class = selectedClass
            })
            net.SendToServer()
        end

        local delete = holder:Add("DButton")
        delete:SetText("Admin Delete Selected Character")
        delete:SetFont("IMPERIAL_ORDER.UI.Small")
        delete:Dock(TOP)
        delete:SetTall(38)
        delete:DockMargin(0, 8, 0, 0)
        delete:SetTextColor(UICol("white", color_white))
        delete.Paint = function(self, w, h)
            draw.RoundedBox(4, 0, 0, w, h, self:IsHovered() and Color(30, 33, 39, 245) or Color(17, 19, 23, 238))
            surface.SetDrawColor(UICol("red", Color(190, 38, 38)))
            surface.DrawRect(0, 0, 4, h)
            surface.SetDrawColor(UICol("border", Color(128, 136, 148)))
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end
        delete.DoClick = AdminDeleteSelected

        local function SelectCharacter(data)
            if not istable(data) then return end
            selectedID = tonumber(data.id) or 0
            selectedDepartment = nil
            selectedClass = nil
            nameEntry:SetValue(tostring(data.name or ""))
            descEntry:SetValue(tostring(data.description or ""))
            modelEntry:SetValue(tostring(data.model or ""))
            homeworldEntry:SetValue(tostring(data.homeworld or ""))
            creditsEntry:SetValue(tostring(data.credits or 0))
            levelEntry:SetValue(tostring(data.imperialOrderLevel or 1))
            xpEntry:SetValue(tostring(data.imperialOrderXP or 0))
            skillEntry:SetValue(tostring(data.imperialOrderSkillPoints or 0))
            factionBox:SetValue(tostring(data.factionName or "Keep Current"))
            classBox:SetValue(tostring(data.className or "Keep Current"))
        end

        for _, char in ipairs(cachedData.characters or {}) do
            local line = list:AddLine(tostring(char.id or ""), tostring(char.player or ""), tostring(char.name or ""), tostring(char.factionName or ""))
            line.imperial_orderCharData = char
        end

        list.OnRowSelected = function(_, _, line)
            if IsValid(line) then SelectCharacter(line.imperial_orderCharData) end
        end
    end

    net.Receive(listSend, function()
        local data = net.ReadTable() or {}
        OpenEditor(data)
    end)

    net.Receive(openMenu, function()
        RequestList()
    end)

    net.Receive(updateResult, function()
        local ok = net.ReadBool()
        local message = net.ReadString()
        Notify(message ~= "" and message or (ok and "Character edited." or "Character edit failed."))
        if ok then RequestList() end
    end)

    net.Receive(deleteResult, function()
        local ok = net.ReadBool()
        local id = net.ReadUInt(32)
        local message = net.ReadString()
        Notify(message ~= "" and message or (ok and "Character deleted." or "Character delete failed."))
        if ok then
            for index, entry in ipairs(cachedData.characters or {}) do
                if tostring(entry.id or "") == tostring(id or "") then
                    table.remove(cachedData.characters, index)
                    break
                end
            end
            RequestList()
        end
    end)

    concommand.Add("imperial_order_admin_charedit", function()
        RequestList()
    end)
end
