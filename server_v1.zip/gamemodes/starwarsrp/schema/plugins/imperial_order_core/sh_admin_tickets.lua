IMPERIAL_ORDER = IMPERIAL_ORDER or {}
IMPERIAL_ORDER_UI_LOADED = IMPERIAL_ORDER_UI_LOADED or {}
IMPERIAL_ORDER_UI_LOADED.admin_ticket_system_v104 = true

-- Imperial Order V104 Admin Ticket System
-- Player:
--   /ticket <message>
--   /tickets
--   imperial_order_ticket_menu
--
-- Staff:
--   imperial_order_ticket_menu
--   imperial_order_ticket_claim <id>
--   imperial_order_ticket_close <id>
--   imperial_order_ticket_goto <id>
--   imperial_order_ticket_bring <id>
--   imperial_order_ticket_reply <id> <message>

local NET_OPEN   = "IMPERIAL_ORDER.Tickets.OpenV104"
local NET_SYNC   = "IMPERIAL_ORDER.Tickets.SyncV104"
local NET_ACT    = "IMPERIAL_ORDER.Tickets.ActionV104"
local NET_NOTICE = "IMPERIAL_ORDER.Tickets.NoticeV104"

local DATA_FILE = "imperial_order/tickets_v104.txt"

local function Trim(value)
    return string.Trim(tostring(value or ""))
end

local function IsTicketStaff(client)
    if not IsValid(client) then return false end
    if client:IsAdmin() or client:IsSuperAdmin() then return true end
    if IMPERIAL_ORDER_IsWhitelistStaffV58 and IMPERIAL_ORDER_IsWhitelistStaffV58(client) then return true end
    return false
end

local function Notify(client, message, color)
    message = tostring(message or "")

    if SERVER then
        if IsValid(client) then
            net.Start(NET_NOTICE)
            net.WriteString(message)
            net.WriteColor(color or Color(215, 42, 42))
            net.Send(client)
        else
            print("[Imperial Order Tickets] " .. message)
        end
    else
        chat.AddText(color or Color(215, 42, 42), "[TICKETS] ", color_white, message)
    end
end

local function FindPlayerBySteam(steam)
    steam = tostring(steam or "")
    for _, ply in ipairs(player.GetAll()) do
        if tostring(ply:SteamID64()) == steam or tostring(ply:SteamID()) == steam then
            return ply
        end
    end
end

local function SafeName(client)
    if IsValid(client) then return tostring(client:Nick()) end
    return "Unknown"
end

local function TicketAllowedForClient(client, ticket)
    if IsTicketStaff(client) then return true end
    if not IsValid(client) or not istable(ticket) then return false end
    return tostring(ticket.steam64 or "") == tostring(client:SteamID64())
        or tostring(ticket.steam or "") == tostring(client:SteamID())
end

if SERVER then
    util.AddNetworkString(NET_OPEN)
    util.AddNetworkString(NET_SYNC)
    util.AddNetworkString(NET_ACT)
    util.AddNetworkString(NET_NOTICE)

    IMPERIAL_ORDER_TICKETS_V104 = IMPERIAL_ORDER_TICKETS_V104 or {
        nextID = 1,
        list = {}
    }

    local function EnsureData()
        IMPERIAL_ORDER_TICKETS_V104 = istable(IMPERIAL_ORDER_TICKETS_V104) and IMPERIAL_ORDER_TICKETS_V104 or {}
        IMPERIAL_ORDER_TICKETS_V104.nextID = tonumber(IMPERIAL_ORDER_TICKETS_V104.nextID) or 1
        IMPERIAL_ORDER_TICKETS_V104.list = istable(IMPERIAL_ORDER_TICKETS_V104.list) and IMPERIAL_ORDER_TICKETS_V104.list or {}
        return IMPERIAL_ORDER_TICKETS_V104
    end

    local function SaveTickets()
        EnsureData()
        file.CreateDir("imperial_order")
        file.Write(DATA_FILE, util.TableToJSON(IMPERIAL_ORDER_TICKETS_V104, true) or "{}")
    end

    local function LoadTickets()
        if file.Exists(DATA_FILE, "DATA") then
            local parsed = util.JSONToTable(file.Read(DATA_FILE, "DATA") or "{}")
            if istable(parsed) then
                IMPERIAL_ORDER_TICKETS_V104 = parsed
            end
        end
        EnsureData()
    end

    LoadTickets()

    local function CompactTicket(ticket)
        return {
            id = tonumber(ticket.id) or 0,
            steam64 = tostring(ticket.steam64 or ""),
            steam = tostring(ticket.steam or ""),
            name = tostring(ticket.name or "Unknown"),
            text = tostring(ticket.text or ""),
            status = tostring(ticket.status or "open"),
            claimedBy = tostring(ticket.claimedBy or ""),
            claimedName = tostring(ticket.claimedName or ""),
            reply = tostring(ticket.reply or ""),
            created = tonumber(ticket.created) or os.time(),
            updated = tonumber(ticket.updated) or os.time()
        }
    end

    local function BuildTicketList(client)
        EnsureData()
        local rows = {}

        for _, ticket in pairs(IMPERIAL_ORDER_TICKETS_V104.list) do
            if istable(ticket) and TicketAllowedForClient(client, ticket) then
                rows[#rows + 1] = CompactTicket(ticket)
            end
        end

        table.sort(rows, function(a, b)
            local aOpen = a.status ~= "closed"
            local bOpen = b.status ~= "closed"
            if aOpen ~= bOpen then return aOpen end
            return (tonumber(a.id) or 0) > (tonumber(b.id) or 0)
        end)

        return rows
    end

    local function SendTickets(client)
        if not IsValid(client) then return end
        net.Start(NET_SYNC)
        net.WriteBool(IsTicketStaff(client))
        net.WriteTable(BuildTicketList(client))
        net.Send(client)
    end

    local function OpenTicketMenu(client)
        if not IsValid(client) then return end
        SendTickets(client)
        net.Start(NET_OPEN)
        net.Send(client)
    end

    local function BroadcastStaffNotice(message)
        for _, ply in ipairs(player.GetAll()) do
            if IsTicketStaff(ply) then
                Notify(ply, message, Color(215, 42, 42))
                SendTickets(ply)
            end
        end
    end

    local function RefreshOwner(ticket)
        if not istable(ticket) then return end
        local owner = FindPlayerBySteam(ticket.steam64)
        if IsValid(owner) then SendTickets(owner) end
    end

    function IMPERIAL_ORDER_CreateTicketV104(client, text)
        if not IsValid(client) then return false end

        text = Trim(text)
        if text == "" then
            Notify(client, "Use /ticket <message> to request staff help.")
            return false
        end

        EnsureData()

        local id = tonumber(IMPERIAL_ORDER_TICKETS_V104.nextID) or 1
        IMPERIAL_ORDER_TICKETS_V104.nextID = id + 1

        local ticket = {
            id = id,
            steam64 = client:SteamID64(),
            steam = client:SteamID(),
            name = client:Nick(),
            text = text,
            status = "open",
            claimedBy = "",
            claimedName = "",
            reply = "",
            created = os.time(),
            updated = os.time()
        }

        IMPERIAL_ORDER_TICKETS_V104.list[id] = ticket
        SaveTickets()

        Notify(client, "Ticket #" .. id .. " created. Staff have been notified.", Color(120, 220, 140))
        BroadcastStaffNotice("New ticket #" .. id .. " from " .. client:Nick() .. ": " .. text)
        SendTickets(client)

        return true
    end

    local function GetTicket(id)
        EnsureData()
        id = tonumber(id) or 0
        return IMPERIAL_ORDER_TICKETS_V104.list[id], id
    end

    local function ClaimTicket(client, id)
        if not IsTicketStaff(client) then return Notify(client, "No ticket staff permission.") end

        local ticket = GetTicket(id)
        if not ticket then return Notify(client, "Ticket not found.") end

        ticket.status = "claimed"
        ticket.claimedBy = client:SteamID64()
        ticket.claimedName = client:Nick()
        ticket.updated = os.time()
        SaveTickets()

        Notify(client, "Claimed ticket #" .. ticket.id .. ".")
        local owner = FindPlayerBySteam(ticket.steam64)
        if IsValid(owner) then Notify(owner, "Your ticket #" .. ticket.id .. " was claimed by " .. client:Nick() .. ".") end

        BroadcastStaffNotice(client:Nick() .. " claimed ticket #" .. ticket.id .. ".")
        RefreshOwner(ticket)
    end

    local function CloseTicket(client, id)
        if not IsTicketStaff(client) then return Notify(client, "No ticket staff permission.") end

        local ticket = GetTicket(id)
        if not ticket then return Notify(client, "Ticket not found.") end

        ticket.status = "closed"
        ticket.closedBy = client:SteamID64()
        ticket.closedName = client:Nick()
        ticket.updated = os.time()
        SaveTickets()

        Notify(client, "Closed ticket #" .. ticket.id .. ".")
        local owner = FindPlayerBySteam(ticket.steam64)
        if IsValid(owner) then Notify(owner, "Your ticket #" .. ticket.id .. " was closed by " .. client:Nick() .. ".") end

        BroadcastStaffNotice(client:Nick() .. " closed ticket #" .. ticket.id .. ".")
        RefreshOwner(ticket)
    end

    local function ReplyTicket(client, id, message)
        if not IsTicketStaff(client) then return Notify(client, "No ticket staff permission.") end

        local ticket = GetTicket(id)
        if not ticket then return Notify(client, "Ticket not found.") end

        message = Trim(message)
        if message == "" then return Notify(client, "Reply cannot be empty.") end

        ticket.reply = client:Nick() .. ": " .. message
        ticket.updated = os.time()
        SaveTickets()

        Notify(client, "Replied to ticket #" .. ticket.id .. ".")
        local owner = FindPlayerBySteam(ticket.steam64)
        if IsValid(owner) then Notify(owner, "Staff replied to ticket #" .. ticket.id .. ": " .. message, Color(120, 220, 140)) end

        BroadcastStaffNotice(client:Nick() .. " replied to ticket #" .. ticket.id .. ".")
        RefreshOwner(ticket)
    end

    local function GotoTicket(client, id)
        if not IsTicketStaff(client) then return Notify(client, "No ticket staff permission.") end

        local ticket = GetTicket(id)
        if not ticket then return Notify(client, "Ticket not found.") end

        local target = FindPlayerBySteam(ticket.steam64)
        if not IsValid(target) then return Notify(client, "Ticket player is not online.") end

        client:SetPos(target:GetPos() + target:GetForward() * -64 + Vector(0, 0, 8))
        Notify(client, "Teleported to ticket #" .. ticket.id .. " player.")
    end

    local function BringTicket(client, id)
        if not IsTicketStaff(client) then return Notify(client, "No ticket staff permission.") end

        local ticket = GetTicket(id)
        if not ticket then return Notify(client, "Ticket not found.") end

        local target = FindPlayerBySteam(ticket.steam64)
        if not IsValid(target) then return Notify(client, "Ticket player is not online.") end

        target:SetPos(client:GetPos() + client:GetForward() * 80 + Vector(0, 0, 8))
        Notify(client, "Brought ticket #" .. ticket.id .. " player to you.")
        Notify(target, "You were brought to staff for ticket #" .. ticket.id .. ".")
    end

    local function DeleteClosedTickets(client)
        if not IsTicketStaff(client) then return Notify(client, "No ticket staff permission.") end

        local removed = 0
        EnsureData()

        for id, ticket in pairs(IMPERIAL_ORDER_TICKETS_V104.list) do
            if istable(ticket) and tostring(ticket.status or "") == "closed" then
                IMPERIAL_ORDER_TICKETS_V104.list[id] = nil
                removed = removed + 1
            end
        end

        SaveTickets()
        Notify(client, "Purged " .. tostring(removed) .. " closed tickets.")
        for _, ply in ipairs(player.GetAll()) do SendTickets(ply) end
    end

    net.Receive(NET_ACT, function(_, client)
        if not IsValid(client) then return end

        local action = net.ReadString()
        local id = net.ReadUInt(16)
        local message = net.ReadString()

        if action == "refresh" then
            return SendTickets(client)
        elseif action == "claim" then
            return ClaimTicket(client, id)
        elseif action == "close" then
            return CloseTicket(client, id)
        elseif action == "reply" then
            return ReplyTicket(client, id, message)
        elseif action == "goto" then
            return GotoTicket(client, id)
        elseif action == "bring" then
            return BringTicket(client, id)
        elseif action == "purge" then
            return DeleteClosedTickets(client)
        end
    end)

    hook.Add("PlayerSay", "IMPERIAL_ORDER.AdminTickets.ChatCommandsV104", function(client, text)
        text = tostring(text or "")
        local lower = string.lower(text)

        if string.StartWith(lower, "/ticket ") or string.StartWith(lower, "!ticket ") then
            local message = string.sub(text, 9)
            IMPERIAL_ORDER_CreateTicketV104(client, message)
            return ""
        end

        if lower == "/ticket" or lower == "!ticket" then
            Notify(client, "Use /ticket <message> to request staff help.")
            return ""
        end

        if lower == "/tickets" or lower == "!tickets" or lower == "/ticketmenu" or lower == "!ticketmenu" then
            OpenTicketMenu(client)
            return ""
        end
    end)

    concommand.Add("imperial_order_ticket", function(client, _, args)
        if not IsValid(client) then return end
        IMPERIAL_ORDER_CreateTicketV104(client, table.concat(args or {}, " "))
    end)

    concommand.Add("imperial_order_ticket_menu", function(client)
        if not IsValid(client) then return end
        OpenTicketMenu(client)
    end)

    concommand.Add("imperial_order_ticket_claim", function(client, _, args) ClaimTicket(client, tonumber(args and args[1]) or 0) end)
    concommand.Add("imperial_order_ticket_close", function(client, _, args) CloseTicket(client, tonumber(args and args[1]) or 0) end)
    concommand.Add("imperial_order_ticket_goto", function(client, _, args) GotoTicket(client, tonumber(args and args[1]) or 0) end)
    concommand.Add("imperial_order_ticket_bring", function(client, _, args) BringTicket(client, tonumber(args and args[1]) or 0) end)
    concommand.Add("imperial_order_ticket_reply", function(client, _, args)
        local id = tonumber(args and args[1]) or 0
        table.remove(args, 1)
        ReplyTicket(client, id, table.concat(args or {}, " "))
    end)
    concommand.Add("imperial_order_ticket_purge_closed", DeleteClosedTickets)

    if ix and ix.command then
        ix.command.Add("Ticket", {
            description = "Create a staff ticket.",
            arguments = ix.type.text,
            OnRun = function(self, client, message)
                IMPERIAL_ORDER_CreateTicketV104(client, message)
            end
        })

        ix.command.Add("Tickets", {
            description = "Open the Imperial ticket terminal.",
            OnRun = function(self, client)
                OpenTicketMenu(client)
            end
        })
    end
else
    IMPERIAL_ORDER_TICKET_ROWS_V104 = IMPERIAL_ORDER_TICKET_ROWS_V104 or {}
    IMPERIAL_ORDER_TICKET_STAFF_V104 = IMPERIAL_ORDER_TICKET_STAFF_V104 or false

    surface.CreateFont("IMPERIAL_ORDER.Tickets.Title", {font = "Trebuchet MS", size = 30, weight = 1000, antialias = true, extended = true})
    surface.CreateFont("IMPERIAL_ORDER.Tickets.Body", {font = "Trebuchet MS", size = 17, weight = 850, antialias = true, extended = true})
    surface.CreateFont("IMPERIAL_ORDER.Tickets.Small", {font = "Trebuchet MS", size = 13, weight = 800, antialias = true, extended = true})
    surface.CreateFont("IMPERIAL_ORDER.Tickets.Button", {font = "Trebuchet MS", size = 15, weight = 900, antialias = true, extended = true})

    local function Col(name, fallback)
        return IMPERIAL_ORDERUI and IMPERIAL_ORDERUI.Col and IMPERIAL_ORDERUI.Col(name, fallback) or ((IMPERIAL_ORDER_COLORS and IMPERIAL_ORDER_COLORS[name]) or fallback or color_white)
    end

    local function SendAction(action, id, message)
        net.Start(NET_ACT)
        net.WriteString(tostring(action or "refresh"))
        net.WriteUInt(tonumber(id) or 0, 16)
        net.WriteString(tostring(message or ""))
        net.SendToServer()
    end

    local function PaintButton(self, w, h, label, accent)
        accent = accent or Col("red", Color(190, 38, 38))
        draw.RoundedBox(5, 0, 0, w, h, self:IsHovered() and Color(34, 37, 43, 245) or Color(15, 17, 21, 240))
        surface.SetDrawColor(accent)
        surface.DrawRect(0, 0, 5, h)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        draw.SimpleText(label, "IMPERIAL_ORDER.Tickets.Button", w / 2, h / 2, Col("text", color_white), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local function MakeButton(parent, label, onClick, w)
        local btn = parent:Add("DButton")
        btn:SetText("")
        btn:SetWide(w or 92)
        btn:SetTall(30)
        btn.Paint = function(self, bw, bh) PaintButton(self, bw, bh, label) end
        btn.DoClick = onClick
        return btn
    end

    local function StatusColor(status)
        status = string.lower(tostring(status or "open"))
        if status == "closed" then return Color(128, 136, 148) end
        if status == "claimed" then return Color(238, 72, 72) end
        return Color(120, 220, 140)
    end

    local function OpenReplyPrompt(ticket)
        if not istable(ticket) then return end
        Derma_StringRequest(
            "Reply to Ticket #" .. tostring(ticket.id),
            "Message to send to " .. tostring(ticket.name or "player") .. ":",
            "",
            function(text)
                SendAction("reply", ticket.id, text)
                timer.Simple(0.2, function() RunConsoleCommand("imperial_order_ticket_menu") end)
            end
        )
    end

    local function BuildTicketRow(parent, ticket, staff)
        local row = parent:Add("DPanel")
        row:SetTall(staff and 148 or 118)
        row:Dock(TOP)
        row:DockMargin(0, 0, 0, 10)

        row.Paint = function(_, w, h)
            draw.RoundedBox(6, 0, 0, w, h, Color(9, 10, 13, 240))
            draw.RoundedBox(6, 2, 2, w - 4, h - 4, Color(15, 17, 21, 235))
            surface.SetDrawColor(StatusColor(ticket.status))
            surface.DrawRect(0, 0, 6, h)
            surface.DrawOutlinedRect(0, 0, w, h, 1)

            draw.SimpleText("#" .. tostring(ticket.id) .. "  " .. string.upper(tostring(ticket.status or "open")), "IMPERIAL_ORDER.Tickets.Body", 16, 15, StatusColor(ticket.status), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText(tostring(ticket.name or "Unknown"), "IMPERIAL_ORDER.Tickets.Body", 16, 42, Col("text", color_white), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText(tostring(ticket.text or ""), "IMPERIAL_ORDER.Tickets.Small", 16, 68, Col("textDim", Color(188, 194, 204)), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            if tostring(ticket.claimedName or "") ~= "" then
                draw.SimpleText("Claimed by: " .. tostring(ticket.claimedName), "IMPERIAL_ORDER.Tickets.Small", 16, 92, Col("steelLight", Color(184, 190, 200)), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            end
            if tostring(ticket.reply or "") ~= "" then
                draw.SimpleText("Reply: " .. tostring(ticket.reply), "IMPERIAL_ORDER.Tickets.Small", 16, staff and 116 or 94, Color(120, 220, 140), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            end
        end

        if staff then
            local x = row:GetWide() - 572

            local claim = MakeButton(row, "CLAIM", function() SendAction("claim", ticket.id) timer.Simple(0.2, function() RunConsoleCommand("imperial_order_ticket_menu") end) end, 82)
            local close = MakeButton(row, "CLOSE", function() SendAction("close", ticket.id) timer.Simple(0.2, function() RunConsoleCommand("imperial_order_ticket_menu") end) end, 82)
            local gotoBtn = MakeButton(row, "GOTO", function() SendAction("goto", ticket.id) end, 82)
            local bring = MakeButton(row, "BRING", function() SendAction("bring", ticket.id) end, 82)
            local reply = MakeButton(row, "REPLY", function() OpenReplyPrompt(ticket) end, 82)

            row.PerformLayout = function(self, w, h)
                local y = h - 38
                local start = math.max(12, w - 452)
                claim:SetPos(start, y)
                close:SetPos(start + 90, y)
                gotoBtn:SetPos(start + 180, y)
                bring:SetPos(start + 270, y)
                reply:SetPos(start + 360, y)
            end
        end
    end

    function IMPERIAL_ORDER_OpenTicketMenuV104()
        SendAction("refresh", 0, "")

        if IsValid(IMPERIAL_ORDER_TICKET_MENU_V104) then
            IMPERIAL_ORDER_TICKET_MENU_V104:Remove()
        end

        local frame = vgui.Create("DFrame")
        IMPERIAL_ORDER_TICKET_MENU_V104 = frame
        frame:SetSize(760, 620)
        frame:Center()
        frame:MakePopup()
        frame:SetTitle("")
        frame:ShowCloseButton(false)

        frame.Paint = function(_, w, h)
            if IMPERIAL_ORDERUI and IMPERIAL_ORDERUI.Panel then
                IMPERIAL_ORDERUI.Panel(0, 0, w, h, "admin tickets", Col("red", Color(190, 38, 38)), false)
            else
                draw.RoundedBox(8, 0, 0, w, h, Color(5, 5, 7, 245))
                surface.SetDrawColor(190, 38, 38)
                surface.DrawOutlinedRect(0, 0, w, h, 1)
            end

            draw.SimpleText("IMPERIAL ADMIN TICKETS", "IMPERIAL_ORDER.Tickets.Title", 24, 32, Col("text", color_white), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end

        local close = MakeButton(frame, "X", function() frame:Remove() end, 36)
        close:SetPos(frame:GetWide() - 52, 14)
        close:SetSize(36, 28)

        local refresh = MakeButton(frame, "REFRESH", function()
            SendAction("refresh", 0, "")
            timer.Simple(0.25, function()
                if IsValid(frame) then
                    frame:Remove()
                    IMPERIAL_ORDER_OpenTicketMenuV104()
                end
            end)
        end, 92)
        refresh:SetPos(frame:GetWide() - 156, 14)

        local purge = nil
        if IMPERIAL_ORDER_TICKET_STAFF_V104 then
            purge = MakeButton(frame, "PURGE CLOSED", function()
                SendAction("purge", 0, "")
                timer.Simple(0.35, function()
                    if IsValid(frame) then
                        frame:Remove()
                        IMPERIAL_ORDER_OpenTicketMenuV104()
                    end
                end)
            end, 126)
            purge:SetPos(frame:GetWide() - 292, 14)
        end

        local newTicket = MakeButton(frame, "NEW TICKET", function()
            Derma_StringRequest("New Ticket", "Describe what you need help with:", "", function(text)
                RunConsoleCommand("imperial_order_ticket", text)
                timer.Simple(0.35, function()
                    if IsValid(frame) then
                        frame:Remove()
                        IMPERIAL_ORDER_OpenTicketMenuV104()
                    end
                end)
            end)
        end, 120)
        newTicket:SetPos(24, frame:GetTall() - 44)

        local scroll = frame:Add("DScrollPanel")
        scroll:SetPos(24, 94)
        scroll:SetSize(frame:GetWide() - 48, frame:GetTall() - 148)

        local rows = IMPERIAL_ORDER_TICKET_ROWS_V104 or {}
        if #rows == 0 then
            local empty = scroll:Add("DLabel")
            empty:SetText("NO TICKETS")
            empty:SetWrap(true)
            empty:SetFont("IMPERIAL_ORDER.Tickets.Body")
            empty:SetTextColor(Col("textDim", Color(188, 194, 204)))
            empty:SetTall(88)
            empty:Dock(TOP)
        else
            for _, ticket in ipairs(rows) do
                BuildTicketRow(scroll, ticket, IMPERIAL_ORDER_TICKET_STAFF_V104)
            end
        end
    end

    net.Receive(NET_SYNC, function()
        IMPERIAL_ORDER_TICKET_STAFF_V104 = net.ReadBool()
        IMPERIAL_ORDER_TICKET_ROWS_V104 = net.ReadTable() or {}
    end)

    net.Receive(NET_OPEN, function()
        timer.Simple(0.05, IMPERIAL_ORDER_OpenTicketMenuV104)
    end)

    net.Receive(NET_NOTICE, function()
        local message = net.ReadString()
        local color = net.ReadColor()
        Notify(nil, message, color)
    end)

    concommand.Add("imperial_order_ticket_menu", function()
        SendAction("refresh", 0, "")
        timer.Simple(0.15, IMPERIAL_ORDER_OpenTicketMenuV104)
    end)

    concommand.Add("imperial_order_ticket_refresh", function()
        SendAction("refresh", 0, "")
    end)
end
