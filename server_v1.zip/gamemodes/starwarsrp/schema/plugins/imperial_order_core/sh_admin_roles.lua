-- Imperial Order v162
-- Shared server-rank display helpers. These helpers intentionally use the
-- player's real Garry's Mod/admin-system usergroup rather than character data.

IMPERIAL_ORDER = IMPERIAL_ORDER or {}

IMPERIAL_ORDER.ServerRankLabels = IMPERIAL_ORDER.ServerRankLabels or {
    user = "PLAYER",
    default = "PLAYER",
    guest = "PLAYER",

    vip = "VIP",
    donator = "DONATOR",
    supporter = "SUPPORTER",

    operator = "OPERATOR",
    trialmod = "TRIAL MODERATOR",
    trialmoderator = "TRIAL MODERATOR",
    moderator = "MODERATOR",
    mod = "MODERATOR",
    seniormod = "SENIOR MODERATOR",
    seniormoderator = "SENIOR MODERATOR",

    junioradmin = "JUNIOR ADMIN",
    admin = "ADMINISTRATOR",
    administrator = "ADMINISTRATOR",
    senioradmin = "SENIOR ADMINISTRATOR",
    headadmin = "HEAD ADMINISTRATOR",
    superadmin = "SUPER ADMINISTRATOR",

    gamemaster = "GAME MASTER",
    eventmaster = "EVENT MASTER",
    eventmanager = "EVENT MANAGER",
    developer = "DEVELOPER",
    dev = "DEVELOPER",
    manager = "MANAGER",
    communitymanager = "COMMUNITY MANAGER",
    coowner = "CO-OWNER",
    owner = "OWNER",
    founder = "FOUNDER"
}

local function NormalizeGroup(value)
    value = string.Trim(string.lower(tostring(value or "")))
    value = string.gsub(value, "[%s_%-%.]", "")
    return value ~= "" and value or "user"
end

local function ReadUserGroup(client)
    if not IsValid(client) then return "user" end

    if type(client.GetUserGroup) == "function" then
        local ok, value = pcall(client.GetUserGroup, client)
        if ok and value ~= nil and tostring(value) ~= "" then
            return tostring(value)
        end
    end

    if type(client.GetNWString) == "function" then
        local value = client:GetNWString("usergroup", "")
        if value == "" then value = client:GetNWString("UserGroup", "") end
        if value ~= "" then return value end
    end

    return "user"
end

local function PrettyCustomGroup(value)
    value = tostring(value or "user")
    value = string.gsub(value, "(%l)(%u)", "%1 %2")
    value = string.gsub(value, "[_%-%.]+", " ")
    value = string.gsub(value, "%s+", " ")
    value = string.Trim(value)

    if value == "" or string.lower(value) == "user" or string.lower(value) == "default" then
        return "PLAYER"
    end

    return string.upper(value)
end

function IMPERIAL_ORDER.GetServerUserGroup(client)
    return string.lower(string.Trim(ReadUserGroup(client)))
end

function IMPERIAL_ORDER.GetServerRankLabel(client)
    local raw = ReadUserGroup(client)
    local key = NormalizeGroup(raw)
    return IMPERIAL_ORDER.ServerRankLabels[key] or PrettyCustomGroup(raw)
end

function IMPERIAL_ORDER.IsServerStaff(client)
    local key = NormalizeGroup(ReadUserGroup(client))
    return key ~= "user" and key ~= "default" and key ~= "guest"
end
