--[[
    Imperial Order - Assignments

    Shared definitions. Loaded on both realms so the client can render the board
    and the objective tracker without asking the server what an assignment is.

    An assignment is:
        requirements -> objectives -> rewards

    Registering one:

        ASSIGN.Register("patrol_sector", {
            name        = "Sector Patrol",
            issuer      = "Sector Command",
            category    = "patrol",
            briefing    = "Sweep the outer corridors and report contacts.",
            requirements = {level = 3, certifications = {"recon"}},
            objectives  = {
                {type = "kill", target = "npc_rebel", count = 6,
                 label = "Eliminate rebel insurgents"},
                {type = "visit", pos = Vector(1024, -512, 96), radius = 220,
                 label = "Report to the checkpoint"}
            },
            rewards     = {credits = 450, xp = 120},
            cooldown    = 1800,        -- seconds before it can be taken again
            repeatable  = true
        })

    IDs are lowercase and permanent. Characters store the ID against their
    completion history, so recycling one rewrites what people have already done.
]]

IMPERIAL_ORDER_ASSIGNMENTS = IMPERIAL_ORDER_ASSIGNMENTS or {}
local ASSIGN = IMPERIAL_ORDER_ASSIGNMENTS

ASSIGN.List = {}
ASSIGN.Order = {}

-- How many assignments a character may hold at once. Keeps the tracker
-- readable and stops people hoarding the whole board.
ASSIGN.MaxActive = 3

-- How often the server re-checks position-based objectives, in seconds.
-- Distance checks are cheap but pointless every frame.
ASSIGN.VisitCheckInterval = 2

ASSIGN.Categories = {
    patrol   = {name = "Patrol",      color = Color(70, 165, 214),  priority = 1},
    combat   = {name = "Combat",      color = Color(174, 8, 15),    priority = 2},
    logistics= {name = "Logistics",   color = Color(85, 184, 112),  priority = 3},
    intel    = {name = "Intelligence",color = Color(226, 169, 60),  priority = 4},
    training = {name = "Training",    color = Color(198, 170, 96),  priority = 5}
}

--[[
    Objective types.

    Each declares how it advances. "event" types are driven by
    ASSIGN.Progress(client, kind, target, amount) from a hook; "poll" types are
    checked on a timer by the server.
]]
ASSIGN.ObjectiveTypes = {
    kill    = {mode = "event", verb = "Eliminate"},
    collect = {mode = "poll",  verb = "Acquire"},
    visit   = {mode = "poll",  verb = "Reach"},
    survive = {mode = "poll",  verb = "Hold"},
    custom  = {mode = "event", verb = "Complete"}
}

function ASSIGN.Register(id, data)
    id = string.lower(string.Trim(tostring(id or "")))
    if (id == "") then return end

    data = data or {}
    data.id = id
    data.name = tostring(data.name or id)
    data.issuer = tostring(data.issuer or "Imperial Command")
    data.category = data.category or "patrol"
    data.briefing = tostring(data.briefing or "")
    data.requirements = data.requirements or {}
    data.rewards = data.rewards or {}
    data.objectives = data.objectives or {}
    data.cooldown = math.max(0, math.floor(tonumber(data.cooldown) or 0))
    data.priority = tonumber(data.priority) or 100

    if (data.repeatable == nil) then data.repeatable = true end

    -- Normalise objectives so the client never has to guess at defaults.
    for index, objective in ipairs(data.objectives) do
        objective.type = ASSIGN.ObjectiveTypes[objective.type] and objective.type or "custom"
        objective.count = math.max(1, math.floor(tonumber(objective.count) or 1))
        objective.index = index

        if (not objective.label) then
            local info = ASSIGN.ObjectiveTypes[objective.type]
            objective.label = (info and info.verb or "Complete") .. " " ..
                tostring(objective.target or "objective")
        end
    end

    if (#data.objectives == 0) then
        ErrorNoHalt("[Imperial Order] Assignment '" .. id .. "' has no objectives, not adding.\n")
        return
    end

    ASSIGN.List[id] = data
    ASSIGN.Order[#ASSIGN.Order + 1] = id

    return data
end

function ASSIGN.Get(id)
    if (not id) then return nil end
    return ASSIGN.List[string.lower(string.Trim(tostring(id)))]
end

function ASSIGN.GetSorted()
    local out = {}
    for _, id in ipairs(ASSIGN.Order) do
        local def = ASSIGN.List[id]
        if (def) then out[#out + 1] = def end
    end

    table.sort(out, function(a, b)
        local ca = ASSIGN.Categories[a.category] or {priority = 99}
        local cb = ASSIGN.Categories[b.category] or {priority = 99}
        if (ca.priority ~= cb.priority) then return ca.priority < cb.priority end
        if (a.priority ~= b.priority) then return a.priority < b.priority end
        return a.name < b.name
    end)

    return out
end

--- Human-readable requirement lines, used by the board and by refusal messages.
-- Shared so the client shows exactly what the server will enforce.
function ASSIGN.DescribeRequirements(def)
    local out = {}
    local req = def and def.requirements or {}

    if (req.level) then
        out[#out + 1] = "Level " .. tostring(req.level)
    end

    if (req.certifications) then
        for _, certID in ipairs(req.certifications) do
            local certName = certID
            if (IMPERIAL_ORDER_CERTS and IMPERIAL_ORDER_CERTS.Get(certID)) then
                certName = IMPERIAL_ORDER_CERTS.Get(certID).name
            end
            out[#out + 1] = certName .. " certification"
        end
    end

    if (req.factions) then
        out[#out + 1] = "Restricted faction"
    end

    return out
end

--- Human-readable reward lines.
function ASSIGN.DescribeRewards(def)
    local out = {}
    local rewards = def and def.rewards or {}

    if (rewards.credits and rewards.credits > 0) then
        out[#out + 1] = rewards.credits .. " credits"
    end

    if (rewards.xp and rewards.xp > 0) then
        out[#out + 1] = rewards.xp .. " XP"
    end

    if (rewards.certification) then
        local certID = rewards.certification.id or rewards.certification
        local tier = rewards.certification.tier or 1
        local label = certID

        if (IMPERIAL_ORDER_CERTS and IMPERIAL_ORDER_CERTS.FormatName) then
            local formatted = IMPERIAL_ORDER_CERTS.FormatName(certID, tier)
            if (formatted) then label = formatted end
        end

        out[#out + 1] = label .. " certification"
    end

    if (rewards.items) then
        for uniqueID, amount in pairs(rewards.items) do
            out[#out + 1] = amount .. "x " .. uniqueID
        end
    end

    return out
end

--[[ ------------------------------------------------------------------------
    Default assignments. Edit freely - nothing below is load-bearing.

    Positions in "visit" objectives are map-specific placeholders. Stand where
    you want the objective and run  imperial_order_assignment_here  to print a
    ready-to-paste Vector.
--------------------------------------------------------------------------- ]]

ASSIGN.Register("perimeter_sweep", {
    name = "Perimeter Sweep",
    issuer = "Garrison Command",
    category = "patrol",
    priority = 1,
    briefing = "Insurgent movement has been reported along the outer perimeter. " ..
               "Sweep the line and remove any hostiles you encounter.",
    objectives = {
        {type = "kill", target = "*", count = 8, label = "Eliminate hostiles"}
    },
    rewards = {credits = 300, xp = 80},
    cooldown = 900,
    repeatable = true
})

ASSIGN.Register("ordnance_disposal", {
    name = "Ordnance Disposal",
    issuer = "Engineering Corps",
    category = "combat",
    priority = 1,
    briefing = "Unexploded ordnance has been located in the lower levels. " ..
               "Certified personnel only.",
    requirements = {certifications = {"eod"}},
    objectives = {
        {type = "kill", target = "*", count = 4, label = "Clear the area of hostiles"},
        {type = "survive", count = 180, label = "Hold the site for 3 minutes"}
    },
    rewards = {credits = 650, xp = 200},
    cooldown = 3600,
    repeatable = true
})

ASSIGN.Register("supply_requisition", {
    name = "Supply Requisition",
    issuer = "Quartermaster",
    category = "logistics",
    priority = 1,
    briefing = "The garrison stores are running short. Acquire the listed " ..
               "materiel and report to the quartermaster.",
    objectives = {
        {type = "collect", target = "ammo_smg", count = 3, label = "Acquire SMG ammunition"}
    },
    rewards = {credits = 250, xp = 60},
    cooldown = 1200,
    repeatable = true
})

ASSIGN.Register("basic_training", {
    name = "Basic Imperial Training",
    issuer = "Training Command",
    category = "training",
    priority = 1,
    briefing = "All incoming personnel must complete basic field training " ..
               "before assignment to active duty.",
    objectives = {
        {type = "kill", target = "*", count = 3, label = "Demonstrate weapon proficiency"}
    },
    rewards = {
        credits = 150,
        xp = 100,
        certification = {id = "cqc", tier = 1}
    },
    cooldown = 0,
    repeatable = false
})

ASSIGN.Register("recon_advance", {
    name = "Forward Reconnaissance",
    issuer = "Imperial Intelligence",
    category = "intel",
    priority = 1,
    briefing = "Establish forward observation and report on enemy positions. " ..
               "Avoid contact where possible.",
    requirements = {level = 5},
    objectives = {
        {type = "survive", count = 300, label = "Maintain observation for 5 minutes"}
    },
    rewards = {
        credits = 500,
        xp = 180,
        certification = {id = "recon", tier = 1}
    },
    cooldown = 7200,
    repeatable = false
})
