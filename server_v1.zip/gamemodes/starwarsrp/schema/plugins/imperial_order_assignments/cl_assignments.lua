--[[
    Imperial Order - Assignments (client)

    Two pieces: the assignment board (opened with /Assignments) and a small
    HUD tracker showing active objectives and their progress.

    The client never computes progress. It draws the numbers the server sends
    on NET_TRACK and nothing else.
]]

if (SERVER) then return end

local ASSIGN = IMPERIAL_ORDER_ASSIGNMENTS
if (not ASSIGN) then return end

local NET_BOARD   = "IMPERIAL_ORDER.Assignments.Board"
local NET_REQUEST = "IMPERIAL_ORDER.Assignments.Request"
local NET_ACTION  = "IMPERIAL_ORDER.Assignments.Action"
local NET_TRACK   = "IMPERIAL_ORDER.Assignments.Track"
local NET_OPEN    = "IMPERIAL_ORDER.Assignments.Open"

local showTracker = CreateClientConVar("imperial_order_assignments_tracker", "1", true, false,
    "Show the active assignment objective tracker.")

surface.CreateFont("IMPERIAL_ORDER.Assign.Title", {
    font = "Trebuchet MS", size = 21, weight = 900, antialias = true, extended = true
})
surface.CreateFont("IMPERIAL_ORDER.Assign.Head", {
    font = "Trebuchet MS", size = 16, weight = 900, antialias = true, extended = true
})
surface.CreateFont("IMPERIAL_ORDER.Assign.Body", {
    font = "Trebuchet MS", size = 14, weight = 600, antialias = true, extended = true
})
surface.CreateFont("IMPERIAL_ORDER.Assign.Small", {
    font = "Trebuchet MS", size = 12, weight = 700, antialias = true, extended = true
})

local function Col(name, fallback)
    if (IU and IU.Colors and IU.Colors[name]) then return IU.Colors[name] end
    return fallback
end

--[[ ------------------------------------------------------------------------
    HUD tracker
--------------------------------------------------------------------------- ]]

local tracked = {}

net.Receive(NET_TRACK, function()
    tracked = {}

    local count = net.ReadUInt(8)
    for _ = 1, count do
        local id = net.ReadString()
        local objectiveCount = net.ReadUInt(8)
        local progress = {}

        for index = 1, objectiveCount do
            progress[index] = net.ReadUInt(32)
        end

        tracked[#tracked + 1] = {id = id, progress = progress}
    end
end)

local function FormatObjective(objective, value)
    if (objective.type == "survive") then
        local remaining = math.max(0, objective.count - value)
        return objective.label .. "  " .. string.format("%d:%02d",
            math.floor(remaining / 60), remaining % 60)
    end

    if (objective.count > 1) then
        return objective.label .. "  " .. value .. "/" .. objective.count
    end

    return objective.label
end

hook.Add("HUDPaint", "IMPERIAL_ORDER.Assignments.Tracker", function()
    if (not showTracker:GetBool()) then return end
    if (#tracked == 0) then return end

    local client = LocalPlayer()
    if (not IsValid(client) or not client:Alive()) then return end
    if (IsValid(ix.gui.menu) or (ix.gui.character and ix.gui.character:IsVisible())) then return end

    local red = Col("red", Color(174, 8, 15))
    local text = Col("text", Color(210, 213, 218))
    local dim = Col("textDim", Color(132, 137, 144))

    local x = ScrW() - 306
    local y = ScrH() * 0.32
    local width = 290

    for _, item in ipairs(tracked) do
        local def = ASSIGN.Get(item.id)

        if (def) then
            local category = ASSIGN.Categories[def.category]
            local accent = red
            local height = 26 + (#def.objectives * 17) + 8

            draw.RoundedBox(3, x, y, width, height, Color(6, 7, 9, 205))
            surface.SetDrawColor(accent.r, accent.g, accent.b, 220)
            surface.DrawRect(x, y, 3, height)

            draw.SimpleText(string.upper(def.name), "IMPERIAL_ORDER.Assign.Small",
                x + 12, y + 12, accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            local lineY = y + 30

            for index, objective in ipairs(def.objectives) do
                local value = item.progress[index] or 0
                local done = value >= objective.count

                draw.SimpleText(done and "+" or "-", "IMPERIAL_ORDER.Assign.Small",
                    x + 12, lineY, done and Col("success", Color(85, 184, 112)) or dim,
                    TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                draw.SimpleText(FormatObjective(objective, value), "IMPERIAL_ORDER.Assign.Small",
                    x + 24, lineY, done and dim or text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                lineY = lineY + 17
            end

            y = y + height + 6
        end
    end
end)

--[[ ------------------------------------------------------------------------
    Assignment board
--------------------------------------------------------------------------- ]]

local activeFrame

local function StyledButton(parent, label, color)
    local button = vgui.Create("DButton", parent)
    button:SetText("")
    button.Paint = function(self, w, h)
        local base = self:IsEnabled() and color or Color(48, 50, 55)
        draw.RoundedBox(3, 0, 0, w, h,
            self:IsHovered() and self:IsEnabled() and base or Color(base.r, base.g, base.b, 70))
        surface.SetDrawColor(base.r, base.g, base.b, self:IsEnabled() and 220 or 80)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        draw.SimpleText(self.Label or label, "IMPERIAL_ORDER.Assign.Small", w / 2, h / 2,
            self:IsEnabled() and Color(238, 240, 243) or Color(132, 137, 144),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    return button
end

local function OpenStaffTools(parent, red, panel, text, dim)
    if (not LocalPlayer():IsAdmin()) then return end

    local frame = vgui.Create("DFrame")
    frame:SetSize(560, 410)
    frame:Center()
    frame:SetTitle("")
    frame:ShowCloseButton(false)
    frame:MakePopup()
    frame.Paint = function(_, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(4, 4, 6, 252))
        draw.RoundedBox(4, 2, 2, w - 4, h - 4, panel)
        surface.SetDrawColor(red)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        surface.DrawRect(0, 0, w, 3)
        draw.SimpleText("ASSIGNMENT CONTROL", "IMPERIAL_ORDER.Assign.Title", 18, 20,
            Color(238, 240, 243), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        draw.SimpleText("AUTHORIZED STAFF PANEL", "IMPERIAL_ORDER.Assign.Small", 18, 47,
            red, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    end

    local close = StyledButton(frame, "X", red)
    close:SetSize(28, 28)
    close:SetPos(516, 14)
    close.DoClick = function() frame:Remove() end

    local playerLabel = vgui.Create("DLabel", frame)
    playerLabel:SetFont("IMPERIAL_ORDER.Assign.Head")
    playerLabel:SetTextColor(text)
    playerLabel:SetText("TARGET PLAYER")
    playerLabel:SetPos(18, 83)
    playerLabel:SizeToContents()

    local players = vgui.Create("DComboBox", frame)
    players:SetPos(18, 108)
    players:SetSize(524, 32)
    players:SetValue("Select a connected player")
    players:SetSortItems(false)
    for _, ply in ipairs(player.GetAll()) do
        local char = ply:GetCharacter()
        players:AddChoice((char and char:GetName() or ply:Nick()) .. "  |  " .. ply:SteamID(), ply)
    end

    local assignmentLabel = vgui.Create("DLabel", frame)
    assignmentLabel:SetFont("IMPERIAL_ORDER.Assign.Head")
    assignmentLabel:SetTextColor(text)
    assignmentLabel:SetText("ASSIGNMENT")
    assignmentLabel:SetPos(18, 157)
    assignmentLabel:SizeToContents()

    local assignments = vgui.Create("DComboBox", frame)
    assignments:SetPos(18, 182)
    assignments:SetSize(524, 32)
    assignments:SetValue("Select an assignment")
    assignments:SetSortItems(false)
    for _, def in ipairs(ASSIGN.GetSorted()) do
        assignments:AddChoice(def.name .. "  [" .. def.id .. "]", def.id)
    end

    local function SendStaffAction(action, needsAssignment)
        local _, target = players:GetSelected()
        local _, id = assignments:GetSelected()
        if (not IsValid(target)) then
            notification.AddLegacy("Select a connected player first.", NOTIFY_ERROR, 4)
            return
        end
        if (needsAssignment and not id) then
            notification.AddLegacy("Select an assignment first.", NOTIFY_ERROR, 4)
            return
        end

        net.Start(NET_ACTION)
            net.WriteString(action)
            net.WriteString(id or "")
            net.WriteEntity(target)
        net.SendToServer()
    end

    local grant = StyledButton(frame, "GRANT / FORCE COMPLETE", red)
    grant:SetPos(18, 235)
    grant:SetSize(254, 38)
    grant.DoClick = function() SendStaffAction("admin_grant", true) end

    local reset = StyledButton(frame, "RESET PLAYER RECORD", Color(190, 45, 48))
    reset:SetPos(288, 235)
    reset:SetSize(254, 38)
    reset.DoClick = function()
        local _, target = players:GetSelected()
        if (not IsValid(target)) then
            notification.AddLegacy("Select a connected player first.", NOTIFY_ERROR, 4)
            return
        end
        Derma_Query("Clear all assignment progress for " .. target:Nick() .. "?", "Confirm Reset",
            "RESET RECORD", function() SendStaffAction("admin_reset", false) end,
            "CANCEL")
    end

    local copy = StyledButton(frame, "COPY MY CURRENT MAP POSITION", Color(91, 95, 104))
    copy:SetPos(18, 292)
    copy:SetSize(524, 34)
    copy.DoClick = function()
        local pos = LocalPlayer():GetPos()
        SetClipboardText(string.format("pos = Vector(%d, %d, %d), radius = 200",
            math.Round(pos.x), math.Round(pos.y), math.Round(pos.z)))
        notification.AddLegacy("Map position copied to clipboard.", NOTIFY_GENERIC, 4)
    end

    local help = vgui.Create("DLabel", frame)
    help:SetFont("IMPERIAL_ORDER.Assign.Small")
    help:SetTextColor(dim)
    help:SetText("Grant completes the selected assignment and awards its configured rewards.\nReset clears the target character's active and completed assignment history.")
    help:SetPos(18, 344)
    help:SetSize(524, 44)
    help:SetWrap(true)
end

local boardFilter = "all"

local function BuildBoard(entries)
    if (IsValid(activeFrame)) then activeFrame:Remove() end
    local red = Col("red", Color(174, 8, 15))
    local panel = Col("panel", Color(12, 14, 17, 250))
    local text = Col("text", Color(228, 230, 233))
    local dim = Col("textDim", Color(151, 156, 165))
    local width, height = math.min(1040, ScrW() - 32), math.min(760, ScrH() - 32)
    local frame = vgui.Create("DFrame")
    activeFrame = frame
    frame:SetSize(width, height)
    frame:Center()
    frame:SetTitle("")
    frame:ShowCloseButton(false)
    frame:SetDraggable(false)
    frame:MakePopup()
    frame:DockPadding(20, 100, 20, 40)
    local held = 0
    for _, entry in ipairs(entries) do
        if (entry.active) then held = held + 1 end
    end
    frame.Paint = function(self, w, h)
        draw.RoundedBox(2, 0, 0, w, h, panel)
        surface.SetDrawColor(52, 55, 62)
        surface.DrawOutlinedRect(0, 0, w, h)
        surface.SetDrawColor(red)
        surface.DrawRect(0, 0, w, 3)
        surface.DrawRect(20, 24, 4, 47)
        draw.SimpleText("IMPERIAL ORDER", "IMPERIAL_ORDER.Assign.Small", 38, 25, red)
        draw.SimpleText("ASSIGNMENT COMMAND", "IMPERIAL_ORDER.Assign.Title", 38, 44, text)
        surface.SetDrawColor(45, 48, 54)
        surface.DrawLine(20, 85, w - 20, 85)
        draw.SimpleText("DUTY ROSTER  /  " .. held .. " OF " .. ASSIGN.MaxActive .. " ACTIVE",
            "IMPERIAL_ORDER.Assign.Small", 20, h - 24, dim)
        draw.SimpleText("F8  /  CLOSE", "IMPERIAL_ORDER.Assign.Small",
            w - 20, h - 24, dim, TEXT_ALIGN_RIGHT)
    end
    local close = StyledButton(frame, "X", red)
    close:SetPos(width - 54, 25)
    close:SetSize(34, 34)
    close.DoClick = function() frame:Remove() end

    local toolbar = vgui.Create("DPanel", frame)
    toolbar:Dock(TOP)
    toolbar:SetTall(36)
    toolbar:DockMargin(0, 0, 0, 16)
    toolbar.Paint = function() end
    local scroll = vgui.Create("DScrollPanel", frame)
    scroll:Dock(FILL)
    local bar = scroll:GetVBar()
    bar:SetWide(5)
    bar.Paint = function() end
    bar.btnUp.Paint = function() end
    bar.btnDown.Paint = function() end
    bar.btnGrip.Paint = function(_, w, h) draw.RoundedBox(0, 0, 0, w, h, red) end

    local function Line(parent, value, font, color)
        local label = vgui.Create("DLabel", parent)
        label:Dock(TOP)
        label:DockMargin(0, 0, 0, 8)
        label:SetFont(font or "IMPERIAL_ORDER.Assign.Body")
        label:SetTextColor(color or text)
        label:SetText(value)
        label:SetWrap(true)
        label:SetAutoStretchVertical(true)
        return label
    end

    local function Populate()
        scroll:Clear()
        local shown = 0
        for _, entry in ipairs(entries) do
            local def = ASSIGN.Get(entry.id)
            local visible = boardFilter == "all"
                or (boardFilter == "active" and entry.active)
                or (boardFilter == "available" and entry.eligible and not entry.active)
            if (def and visible) then
                shown = shown + 1
                local card = scroll:Add("DPanel")
                card:Dock(TOP)
                card:DockMargin(0, 0, 10, 14)
                card:DockPadding(20, 18, 20, 16)
                card:SetTall(260)
                card.Paint = function(_, w, h)
                    draw.RoundedBox(2, 0, 0, w, h, Color(22, 24, 29))
                    surface.SetDrawColor(43, 46, 53)
                    surface.DrawOutlinedRect(0, 0, w, h)
                    surface.SetDrawColor(entry.active and red or Color(76, 79, 86))
                    surface.DrawRect(0, 0, 3, h)
                end
                local category = ASSIGN.Categories[def.category]
                local status = entry.active and "ACTIVE" or (entry.eligible and "AVAILABLE" or "LOCKED")
                Line(card, string.upper(category and category.name or def.category)
                    .. "  /  " .. status .. "  /  COMPLETED " .. entry.completions,
                    "IMPERIAL_ORDER.Assign.Small", dim)
                Line(card, def.name, "IMPERIAL_ORDER.Assign.Title")
                Line(card, def.issuer .. "  |  " .. def.id, "IMPERIAL_ORDER.Assign.Small", dim)
                Line(card, def.briefing)
                Line(card, "MISSION OBJECTIVES", "IMPERIAL_ORDER.Assign.Small", dim)
                for index, objective in ipairs(def.objectives) do
                    local value = entry.progress and entry.progress[index] or 0
                    Line(card, (value >= objective.count and "[COMPLETE]  " or "-  ")
                        .. FormatObjective(objective, value), nil,
                        value >= objective.count and Color(150, 184, 156) or text)
                end
                local rewards = ASSIGN.DescribeRewards(def)
                local requirements = ASSIGN.DescribeRequirements(def)
                if (#rewards > 0) then
                    Line(card, "REWARDS  /  " .. table.concat(rewards, "  |  "), nil, text)
                end
                if (#requirements > 0) then
                    Line(card, "REQUIRES  /  " .. table.concat(requirements, ", "), nil, dim)
                end
                if (not entry.active and not entry.eligible and entry.reason ~= "") then
                    Line(card, entry.reason, nil, Color(220, 155, 155))
                end
                local action = StyledButton(card, entry.active and "ABANDON ASSIGNMENT"
                    or "ACCEPT ASSIGNMENT", red)
                action:Dock(TOP)
                action:DockMargin(0, 6, 0, 0)
                action:SetTall(36)
                action:SetEnabled(entry.active or entry.eligible)
                action.DoClick = function()
                    local function Send()
                        net.Start(NET_ACTION)
                        net.WriteString(entry.active and "abandon" or "accept")
                        net.WriteString(def.id)
                        net.SendToServer()
                    end
                    if (entry.active) then
                        Derma_Query("Abandon " .. def.name .. " and lose its active progress?",
                            "Assignment Command", "ABANDON", Send, "CANCEL")
                    else
                        Send()
                    end
                end
                -- Reflow wrapped labels before measuring; no painted text overlaps.
                card.Think = function(self)
                    local total = 34
                    for _, child in ipairs(self:GetChildren()) do
                        local _, top, _, bottom = child:GetDockMargin()
                        total = total + child:GetTall() + top + bottom
                    end
                    if (math.abs(self:GetTall() - total) > 1) then self:SetTall(total) end
                end
            end
        end
        if (shown == 0) then
            Line(scroll:GetCanvas(), "No assignments in this view.", nil, dim)
        end
    end

    for _, item in ipairs({{"ALL", "all"}, {"ACTIVE", "active"}, {"AVAILABLE", "available"}}) do
        local filter = StyledButton(toolbar, item[1], red)
        filter:Dock(LEFT)
        filter:SetWide(90)
        filter:DockMargin(0, 0, 8, 0)
        filter.DoClick = function() boardFilter = item[2] Populate() end
        filter.Think = function(self)
            self.Label = (boardFilter == item[2] and "> " or "") .. item[1]
        end
    end
    if (LocalPlayer():IsAdmin()) then
        local staff = StyledButton(toolbar, "STAFF TOOLS", red)
        staff:Dock(RIGHT)
        staff:SetWide(110)
        staff.DoClick = function() OpenStaffTools(frame, red, panel, text, dim) end
    end
    local tracker = StyledButton(toolbar, "TRACKER", Color(91, 95, 104))
    tracker:Dock(RIGHT)
    tracker:SetWide(110)
    tracker:DockMargin(0, 0, 8, 0)
    tracker.Think = function(self)
        self.Label = showTracker:GetBool() and "TRACKER: ON" or "TRACKER: OFF"
    end
    tracker.DoClick = function()
        RunConsoleCommand("imperial_order_assignments_tracker", showTracker:GetBool() and "0" or "1")
    end
    Populate()
end

net.Receive(NET_BOARD, function()
    local entries = {}
    local count = net.ReadUInt(8)

    for _ = 1, count do
        local id = net.ReadString()
        local active = net.ReadBool()
        local eligible = net.ReadBool()
        local reason = net.ReadString()
        local completions = net.ReadUInt(16)

        local objectiveCount = net.ReadUInt(8)
        local progress = {}
        for index = 1, objectiveCount do progress[index] = net.ReadUInt(32) end

        entries[#entries + 1] = {
            id = id, active = active, eligible = eligible,
            reason = reason, completions = completions,
            progress = active and progress or nil
        }
    end

    BuildBoard(entries)
end)

net.Receive(NET_OPEN, function()
    net.Start(NET_REQUEST)
    net.SendToServer()
end)

concommand.Add("imperial_order_assignments", function()
    net.Start(NET_REQUEST)
    net.SendToServer()
end)

-- F8 opens and closes the board without requiring a chat or console command.
-- Poll the rising edge so the key also works while a Derma popup owns focus.
hook.Remove("PlayerButtonDown", "IMPERIAL_ORDER.Assignments.F8Menu")
local f8Held = false
hook.Add("Think", "IMPERIAL_ORDER.Assignments.F8Menu", function()
    local down = input.IsKeyDown(KEY_F8)
    local pressed = down and not f8Held
    f8Held = down
    if (not pressed) then return end
    local client = LocalPlayer()
    if (not IsValid(client) or not client:GetCharacter()) then return end
    if (gui.IsGameUIVisible()) then return end

    if (IsValid(activeFrame)) then
        activeFrame:Remove()
        return
    end

    net.Start(NET_REQUEST)
    net.SendToServer()
end)

concommand.Add("imperial_order_assignments_status", function()
    print("[Imperial Order] Tracker enabled: " .. tostring(showTracker:GetBool()))
    print("[Imperial Order] Active assignments: " .. #tracked)
    print("[Imperial Order] Registered definitions: " .. table.Count(ASSIGN.List))

    for _, item in ipairs(tracked) do
        print("  " .. item.id .. "  progress: " .. table.concat(item.progress, ", "))
    end
end)
