--[[
    Imperial Order - Assignments (server)

    State lives on the character so assignments follow the character, not the
    Steam account:

        character:GetData("imperial_orderAssignments")
        {
            active = {
                ["perimeter_sweep"] = {
                    accepted = 1717000000,
                    progress = {8, 0},          -- one counter per objective
                    mark     = 1717000120       -- survive-timer anchor
                }
            },
            completed = { ["basic_training"] = {count = 1, last = 1717000000} }
        }

    Progress is authoritative here. The client is told the numbers so it can
    draw a tracker; it is never asked what they are.
]]

if (CLIENT) then return end

local ASSIGN = IMPERIAL_ORDER_ASSIGNMENTS
if (not ASSIGN) then return end

local NET_BOARD   = "IMPERIAL_ORDER.Assignments.Board"
local NET_REQUEST = "IMPERIAL_ORDER.Assignments.Request"
local NET_ACTION  = "IMPERIAL_ORDER.Assignments.Action"
local NET_TRACK   = "IMPERIAL_ORDER.Assignments.Track"
local NET_OPEN    = "IMPERIAL_ORDER.Assignments.Open"

util.AddNetworkString(NET_BOARD)
util.AddNetworkString(NET_REQUEST)
util.AddNetworkString(NET_ACTION)
util.AddNetworkString(NET_TRACK)
util.AddNetworkString(NET_OPEN)

local DATA_KEY = "imperial_orderAssignments"
local actionCooldown = {}

local function notify(client, message, kind)
    if (not IsValid(client)) then return end

    if (isfunction(IMPERIAL_ORDER_Notify)) then
        local color = kind == "success" and Color(85, 184, 112)
            or kind == "warning" and Color(226, 169, 60)
            or Color(215, 42, 42)
        IMPERIAL_ORDER_Notify(client, message, color, 6)
    elseif (isfunction(client.Notify)) then
        client:Notify(message)
    else
        client:ChatPrint("[Imperial Order] " .. message)
    end
end

local function canAdmin(client)
    if (not IsValid(client) or not client:IsPlayer()) then return false end

    if (isfunction(IMPERIAL_ORDER_CanAccessAdminUI)) then
        local ok, allowed = pcall(IMPERIAL_ORDER_CanAccessAdminUI, client)
        if (ok) then return allowed == true end
    end

    return client:IsSuperAdmin() or client:IsAdmin()
end

local function getCharacter(client)
    if (not IsValid(client) or not isfunction(client.GetCharacter)) then return nil end

    local ok, character = pcall(client.GetCharacter, client)
    if (ok and character and isfunction(character.GetData)) then return character end

    return nil
end

--- Rebuilds state from stored data, discarding anything that no longer parses.
-- Assignments removed from sh_config are dropped here rather than left as
-- untrackable entries that can never complete.
local function sanitize(raw)
    local state = {active = {}, completed = {}}
    if (not istable(raw)) then return state end

    if (istable(raw.active)) then
        for id, entry in pairs(raw.active) do
            local def = ASSIGN.Get(id)

            if (def and istable(entry)) then
                local progress = {}
                for index = 1, #def.objectives do
                    local value = istable(entry.progress) and tonumber(entry.progress[index]) or 0
                    progress[index] = math.Clamp(math.floor(value or 0), 0, def.objectives[index].count)
                end

                state.active[def.id] = {
                    accepted = math.max(0, math.floor(tonumber(entry.accepted) or 0)),
                    mark = math.max(0, math.floor(tonumber(entry.mark) or 0)),
                    progress = progress
                }
            end
        end
    end

    if (istable(raw.completed)) then
        for id, entry in pairs(raw.completed) do
            local def = ASSIGN.Get(id)

            if (def and istable(entry)) then
                state.completed[def.id] = {
                    count = math.max(0, math.floor(tonumber(entry.count) or 0)),
                    last = math.max(0, math.floor(tonumber(entry.last) or 0))
                }
            end
        end
    end

    return state
end

function ASSIGN.GetState(character)
    if (not character or not isfunction(character.GetData)) then
        return {active = {}, completed = {}}
    end

    return sanitize(character:GetData(DATA_KEY, nil))
end

local function saveState(character, state)
    if (not character or not isfunction(character.SetData)) then return end
    character:SetData(DATA_KEY, state)
end

local function countActive(state)
    local total = 0
    for _ in pairs(state.active) do total = total + 1 end
    return total
end

--[[ ------------------------------------------------------------------------
    Eligibility
--------------------------------------------------------------------------- ]]

--- Returns eligible, reason. Reason is shown to the player verbatim.
function ASSIGN.CanAccept(client, def, state)
    local character = getCharacter(client)
    if (not character) then return false, "No active character." end

    state = state or ASSIGN.GetState(character)

    if (state.active[def.id]) then
        return false, "You are already carrying that assignment."
    end

    if (countActive(state) >= ASSIGN.MaxActive) then
        return false, "You may only carry " .. ASSIGN.MaxActive .. " assignments at once."
    end

    local record = state.completed[def.id]

    if (record and record.count > 0) then
        if (not def.repeatable) then
            return false, "That assignment may only be completed once."
        end

        if (def.cooldown > 0) then
            local elapsed = os.time() - record.last
            if (elapsed < def.cooldown) then
                local remaining = def.cooldown - elapsed
                local pretty

                if (isfunction(string.NiceTime)) then
                    pretty = string.NiceTime(remaining)
                else
                    pretty = math.ceil(remaining / 60) .. " minutes"
                end

                return false, "Available again in " .. pretty .. "."
            end
        end
    end

    local req = def.requirements or {}

    if (req.level) then
        local level = tonumber(character:GetVar("imperialOrderLevel", 1)) or 1
        if (level < req.level) then
            return false, "Requires level " .. req.level .. "."
        end
    end

    if (req.certifications and IMPERIAL_ORDER_CERTS) then
        local held = {}
        for _, entry in ipairs(IMPERIAL_ORDER_CERTS.GetCharacterCertifications(character)) do
            held[entry.id] = entry.tier
        end

        for _, certID in ipairs(req.certifications) do
            certID = string.lower(tostring(certID))
            if (not held[certID]) then
                local def2 = IMPERIAL_ORDER_CERTS.Get(certID)
                return false, "Requires the " .. (def2 and def2.name or certID) .. " certification."
            end
        end
    end

    if (req.factions) then
        local faction = character:GetFaction()
        local allowed = false
        for _, value in ipairs(req.factions) do
            if (value == faction) then allowed = true break end
        end
        if (not allowed) then return false, "Your faction is not cleared for that assignment." end
    end

    return true
end

--[[ ------------------------------------------------------------------------
    Accept / abandon / complete
--------------------------------------------------------------------------- ]]

function ASSIGN.Accept(client, id)
    local def = ASSIGN.Get(id)
    if (not def) then return false, "Unknown assignment." end

    local character = getCharacter(client)
    if (not character) then return false, "No active character." end

    local state = ASSIGN.GetState(character)
    local ok, reason = ASSIGN.CanAccept(client, def, state)
    if (not ok) then return false, reason end

    local progress = {}
    for index = 1, #def.objectives do progress[index] = 0 end

    state.active[def.id] = {
        accepted = os.time(),
        mark = os.time(),
        progress = progress
    }

    saveState(character, state)
    ASSIGN.SyncTracker(client)

    hook.Run("ImperialOrderAssignmentAccepted", client, character, def.id)

    return true, "Assignment accepted: " .. def.name
end

function ASSIGN.Abandon(client, id)
    local def = ASSIGN.Get(id)
    if (not def) then return false, "Unknown assignment." end

    local character = getCharacter(client)
    if (not character) then return false, "No active character." end

    local state = ASSIGN.GetState(character)
    if (not state.active[def.id]) then
        return false, "You are not carrying that assignment."
    end

    state.active[def.id] = nil
    saveState(character, state)
    ASSIGN.SyncTracker(client)

    hook.Run("ImperialOrderAssignmentAbandoned", client, character, def.id)

    return true, "Assignment abandoned: " .. def.name
end

--- Pays out rewards through the existing progression systems rather than
-- writing credits/XP directly, so level-ups and perks still apply.
local function grantRewards(client, character, def)
    local rewards = def.rewards or {}
    local granted = {}

    if (rewards.credits and rewards.credits > 0) then
        local current = tonumber(character:GetVar("credits", 0)) or 0
        character:SetVar("credits", current + rewards.credits)
        granted[#granted + 1] = rewards.credits .. " credits"
    end

    if (rewards.xp and rewards.xp > 0) then
        if (IMPERIAL_ORDER_SKILLS and isfunction(IMPERIAL_ORDER_SKILLS.AddXP)) then
            IMPERIAL_ORDER_SKILLS.AddXP(client, rewards.xp, "Assignment: " .. def.name)
        else
            local xp = tonumber(character:GetVar("imperialOrderXP", 0)) or 0
            character:SetVar("imperialOrderXP", xp + rewards.xp)
        end
        granted[#granted + 1] = rewards.xp .. " XP"
    end

    if (rewards.certification and IMPERIAL_ORDER_CERTS and isfunction(IMPERIAL_ORDER_CERTS.Grant)) then
        local certID = rewards.certification.id or rewards.certification
        local tier = rewards.certification.tier or 1
        local ok = IMPERIAL_ORDER_CERTS.Grant(client, certID, tier, def.issuer)
        if (ok) then
            granted[#granted + 1] = (IMPERIAL_ORDER_CERTS.FormatName(certID, tier) or certID) .. " certification"
        end
    end

    if (rewards.items) then
        local inventory = character:GetInventory()
        if (inventory) then
            for uniqueID, amount in pairs(rewards.items) do
                for _ = 1, math.max(1, math.floor(tonumber(amount) or 1)) do
                    inventory:Add(uniqueID)
                end
            end
        end
    end

    return granted
end

function ASSIGN.Complete(client, id)
    local def = ASSIGN.Get(id)
    if (not def) then return false end

    local character = getCharacter(client)
    if (not character) then return false end

    local state = ASSIGN.GetState(character)
    if (not state.active[def.id]) then return false end

    state.active[def.id] = nil

    local record = state.completed[def.id] or {count = 0, last = 0}
    record.count = record.count + 1
    record.last = os.time()
    state.completed[def.id] = record

    saveState(character, state)

    local granted = grantRewards(client, character, def)
    ASSIGN.SyncTracker(client)

    notify(client, "Assignment complete: " .. def.name, "success")
    if (#granted > 0) then
        notify(client, "Awarded " .. table.concat(granted, ", ") .. ".", "success")
    end

    hook.Run("ImperialOrderAssignmentCompleted", client, character, def.id, record.count)

    return true
end

--[[ ------------------------------------------------------------------------
    Progress
--------------------------------------------------------------------------- ]]

--- Advances every active objective matching kind/target.
-- Call from anywhere: ASSIGN.Progress(ply, "kill", "npc_rebel", 1)
-- A target of "*" on the objective matches anything of that kind.
function ASSIGN.Progress(client, kind, target, amount)
    local character = getCharacter(client)
    if (not character) then return end

    amount = math.max(1, math.floor(tonumber(amount) or 1))
    target = string.lower(tostring(target or ""))

    local state = ASSIGN.GetState(character)
    local changed, completed = false, {}

    for id, entry in pairs(state.active) do
        local def = ASSIGN.Get(id)

        if (def) then
            local finished = true

            for index, objective in ipairs(def.objectives) do
                if (objective.type == kind and entry.progress[index] < objective.count) then
                    local wanted = string.lower(tostring(objective.target or "*"))

                    if (wanted == "*" or wanted == target) then
                        entry.progress[index] = math.min(objective.count,
                            entry.progress[index] + amount)
                        changed = true
                    end
                end

                if (entry.progress[index] < objective.count) then finished = false end
            end

            if (finished) then completed[#completed + 1] = id end
        end
    end

    if (changed) then
        saveState(character, state)
        ASSIGN.SyncTracker(client)
    end

    for _, id in ipairs(completed) do
        ASSIGN.Complete(client, id)
    end
end

--[[ ------------------------------------------------------------------------
    Event-driven tracking
--------------------------------------------------------------------------- ]]

hook.Add("OnNPCKilled", "IMPERIAL_ORDER.Assignments.NPCKill", function(npc, attacker)
    if (not IsValid(attacker)) then return end

    -- Credit the owner when the kill came from a weapon or turret.
    if (not attacker:IsPlayer() and isfunction(attacker.GetOwner)) then
        local owner = attacker:GetOwner()
        if (IsValid(owner) and owner:IsPlayer()) then attacker = owner end
    end

    if (not attacker:IsPlayer()) then return end

    ASSIGN.Progress(attacker, "kill", npc:GetClass(), 1)
end)

--[[ ------------------------------------------------------------------------
    Polled tracking (visit / collect / survive)
--------------------------------------------------------------------------- ]]

timer.Create("IMPERIAL_ORDER.Assignments.Poll", ASSIGN.VisitCheckInterval, 0, function()
    for _, client in ipairs(player.GetAll()) do
        local character = getCharacter(client)
        if (character and client:Alive()) then
            local state = ASSIGN.GetState(character)
            local changed, completed = false, {}
            local now = os.time()

            for id, entry in pairs(state.active) do
                local def = ASSIGN.Get(id)

                if (def) then
                    local finished = true

                    for index, objective in ipairs(def.objectives) do
                        local done = entry.progress[index] >= objective.count

                        if (not done) then
                            if (objective.type == "visit" and objective.pos) then
                                local radius = tonumber(objective.radius) or 200
                                if (client:GetPos():DistToSqr(objective.pos) <= radius * radius) then
                                    entry.progress[index] = objective.count
                                    changed = true
                                end

                            elseif (objective.type == "survive") then
                                local elapsed = now - (entry.mark or now)
                                if (elapsed > entry.progress[index]) then
                                    entry.progress[index] = math.min(objective.count, elapsed)
                                    changed = true
                                end

                            elseif (objective.type == "collect" and objective.target) then
                                local inventory = character:GetInventory()
                                if (inventory and isfunction(inventory.GetItemCount)) then
                                    local held = inventory:GetItemCount(objective.target) or 0
                                    if (held ~= entry.progress[index]) then
                                        entry.progress[index] = math.min(objective.count, held)
                                        changed = true
                                    end
                                end
                            end
                        end

                        if (entry.progress[index] < objective.count) then finished = false end
                    end

                    if (finished) then completed[#completed + 1] = id end
                end
            end

            if (changed) then
                saveState(character, state)
                ASSIGN.SyncTracker(client)
            end

            for _, id in ipairs(completed) do
                ASSIGN.Complete(client, id)
            end
        end
    end
end)

-- Dying resets survive timers; holding a position means holding it alive.
hook.Add("PlayerDeath", "IMPERIAL_ORDER.Assignments.ResetSurvive", function(client)
    local character = getCharacter(client)
    if (not character) then return end

    local state = ASSIGN.GetState(character)
    local changed = false

    for id, entry in pairs(state.active) do
        local def = ASSIGN.Get(id)
        if (def) then
            for index, objective in ipairs(def.objectives) do
                if (objective.type == "survive" and entry.progress[index] < objective.count) then
                    entry.progress[index] = 0
                    entry.mark = os.time()
                    changed = true
                end
            end
        end
    end

    if (changed) then
        saveState(character, state)
        ASSIGN.SyncTracker(client)
        notify(client, "Assignment timer reset - you were killed in the field.", "warning")
    end
end)

hook.Add("PlayerSpawn", "IMPERIAL_ORDER.Assignments.RemarkSurvive", function(client)
    timer.Simple(0.5, function()
        if (not IsValid(client)) then return end

        local character = getCharacter(client)
        if (not character) then return end

        local state = ASSIGN.GetState(character)

        for _, entry in pairs(state.active) do entry.mark = os.time() end

        saveState(character, state)
        ASSIGN.SyncTracker(client)
    end)
end)

--[[ ------------------------------------------------------------------------
    Networking
--------------------------------------------------------------------------- ]]

--- Sends only the active assignments, for the on-screen objective tracker.
function ASSIGN.SyncTracker(client)
    if (not IsValid(client)) then return end

    local character = getCharacter(client)
    if (not character) then return end

    local state = ASSIGN.GetState(character)
    local active = {}

    for id, entry in pairs(state.active) do
        active[#active + 1] = {id = id, progress = entry.progress}
    end

    net.Start(NET_TRACK)
        net.WriteUInt(#active, 8)
        for _, item in ipairs(active) do
            net.WriteString(item.id)
            net.WriteUInt(#item.progress, 8)
            for _, value in ipairs(item.progress) do
                net.WriteUInt(math.max(0, value), 32)
            end
        end
    net.Send(client)
end

local function sendBoard(client)
    local character = getCharacter(client)
    if (not character) then return end

    local state = ASSIGN.GetState(character)
    local payload = {}

    for _, def in ipairs(ASSIGN.GetSorted()) do
        local entry = state.active[def.id]
        local record = state.completed[def.id]
        local eligible, reason = ASSIGN.CanAccept(client, def, state)

        payload[#payload + 1] = {
            id = def.id,
            active = entry and true or false,
            progress = entry and entry.progress or nil,
            completions = record and record.count or 0,
            eligible = eligible,
            reason = reason or ""
        }
    end

    net.Start(NET_BOARD)
        net.WriteUInt(#payload, 8)
        for _, item in ipairs(payload) do
            net.WriteString(item.id)
            net.WriteBool(item.active)
            net.WriteBool(item.eligible)
            net.WriteString(string.sub(item.reason, 1, 128))
            net.WriteUInt(item.completions, 16)

            local def = ASSIGN.Get(item.id)
            net.WriteUInt(#def.objectives, 8)
            for index = 1, #def.objectives do
                net.WriteUInt(item.progress and item.progress[index] or 0, 32)
            end
        end
    net.Send(client)
end

net.Receive(NET_REQUEST, function(_, client)
    if (not IsValid(client)) then return end

    local now = CurTime()
    if ((actionCooldown[client] or 0) > now) then return end
    actionCooldown[client] = now + 0.4

    sendBoard(client)
end)

net.Receive(NET_ACTION, function(_, client)
    if (not IsValid(client)) then return end

    local now = CurTime()
    if ((actionCooldown[client] or 0) > now) then return end
    actionCooldown[client] = now + 0.4

    local action = net.ReadString()
    local id = net.ReadString()
    local success, message

    if (action == "accept") then
        success, message = ASSIGN.Accept(client, id)
    elseif (action == "abandon") then
        success, message = ASSIGN.Abandon(client, id)
    elseif (action == "admin_grant") then
        if (not canAdmin(client)) then
            success, message = false, "You are not cleared for staff assignment actions."
        else
            local target = net.ReadEntity()
            local def = ASSIGN.Get(id)
            local character = IsValid(target) and getCharacter(target)

            if (not IsValid(target) or not target:IsPlayer()) then
                success, message = false, "Select a valid player."
            elseif (not def) then
                success, message = false, "Select a valid assignment."
            elseif (not character) then
                success, message = false, "That player has no active character."
            else
                local state = ASSIGN.GetState(character)
                if (not state.active[def.id]) then
                    local progress = {}
                    for index = 1, #def.objectives do
                        progress[index] = def.objectives[index].count
                    end
                    state.active[def.id] = {
                        accepted = os.time(), mark = os.time(), progress = progress
                    }
                    saveState(character, state)
                end

                ASSIGN.Complete(target, def.id)
                success, message = true, target:GetName() .. " credited with " .. def.name .. "."
            end
        end
    elseif (action == "admin_reset") then
        if (not canAdmin(client)) then
            success, message = false, "You are not cleared for staff assignment actions."
        else
            local target = net.ReadEntity()
            local character = IsValid(target) and getCharacter(target)

            if (not IsValid(target) or not target:IsPlayer()) then
                success, message = false, "Select a valid player."
            elseif (not character) then
                success, message = false, "That player has no active character."
            else
                saveState(character, {active = {}, completed = {}})
                ASSIGN.SyncTracker(target)
                success, message = true, target:GetName() .. "'s assignment record cleared."
            end
        end
    else
        return
    end

    notify(client, message, success and "success" or "warning")
    sendBoard(client)
end)

hook.Add("PlayerDisconnected", "IMPERIAL_ORDER.Assignments.Cleanup", function(client)
    actionCooldown[client] = nil
end)

hook.Add("PlayerLoadedCharacter", "IMPERIAL_ORDER.Assignments.Loaded", function(client)
    timer.Simple(0.6, function()
        if (IsValid(client)) then ASSIGN.SyncTracker(client) end
    end)
end)

--[[ ------------------------------------------------------------------------
    Commands
--------------------------------------------------------------------------- ]]

ix.command.Add("Assignments", {
    description = "Open the Imperial assignment board.",
    OnRun = function(self, client)
        net.Start(NET_OPEN)
        net.Send(client)
    end
})

ix.command.Add("AssignmentAbandon", {
    description = "Abandon an assignment you are carrying.",
    arguments = {ix.type.string},
    OnRun = function(self, client, id)
        local _, message = ASSIGN.Abandon(client, id)
        return message
    end
})

ix.command.Add("AssignmentGrant", {
    description = "Force-complete an assignment for a player.",
    adminOnly = true,
    arguments = {ix.type.player, ix.type.string},
    OnRun = function(self, client, target, id)
        if (not canAdmin(client)) then return "You are not cleared for that." end

        local def = ASSIGN.Get(id)
        if (not def) then return "Unknown assignment." end

        local character = getCharacter(target)
        if (not character) then return "Target has no active character." end

        -- Force it active first so Complete has something to close out.
        local state = ASSIGN.GetState(character)
        if (not state.active[def.id]) then
            local progress = {}
            for index = 1, #def.objectives do progress[index] = def.objectives[index].count end
            state.active[def.id] = {accepted = os.time(), mark = os.time(), progress = progress}
            saveState(character, state)
        end

        ASSIGN.Complete(target, def.id)

        return target:GetName() .. " credited with " .. def.name .. "."
    end
})

ix.command.Add("AssignmentReset", {
    description = "Clear a player's assignment history and active assignments.",
    adminOnly = true,
    arguments = {ix.type.player},
    OnRun = function(self, client, target)
        if (not canAdmin(client)) then return "You are not cleared for that." end

        local character = getCharacter(target)
        if (not character) then return "Target has no active character." end

        saveState(character, {active = {}, completed = {}})
        ASSIGN.SyncTracker(target)

        return target:GetName() .. "'s assignment record cleared."
    end
})

ix.command.Add("AssignmentList", {
    description = "List every assignment ID available on this server.",
    OnRun = function(self, client)
        client:ChatPrint("[Imperial Order] Available assignments:")

        for _, def in ipairs(ASSIGN.GetSorted()) do
            local category = ASSIGN.Categories[def.category]
            client:ChatPrint(string.format("  %s  -  %s (%s)%s",
                def.id, def.name,
                category and category.name or def.category,
                def.repeatable and "" or ", one-time"))
        end
    end
})

concommand.Add("imperial_order_assignment_here", function(client)
    if (not IsValid(client) or not canAdmin(client)) then return end

    local pos = client:GetPos()
    local line = string.format("pos = Vector(%d, %d, %d), radius = 200",
        math.Round(pos.x), math.Round(pos.y), math.Round(pos.z))

    client:ChatPrint("[Imperial Order] " .. line)
    print("[Imperial Order] " .. line)
end)
