IMPERIAL ORDER - ASSIGNMENTS
============================

THEMED MENU UPDATE
------------------
Charcoal mission cards, Imperial red accents, and existing IU.Colors support.
All / Active / Available filters, wrapped briefing and reward text, and
objectives visible before accepting. F8 opens and closes the board.
Replace the existing imperial_order_assignments plugin folder in your schema's
plugins directory, then restart the server. Do not install a duplicate copy.
No server-side progression, rewards, or saved character data changed.

An assignment board with objectives, requirements, cooldowns and rewards.
Rewards pay out through your existing progression, and can grant certifications.

The board now includes clickable controls, so normal use does not require chat
commands. Staff see a STAFF TOOLS button for granting/completing assignments,
resetting a character's record, and copying their current map position. The
tracker can also be toggled directly from the board.


COMMANDS
--------
  F8                                    Toggle the assignment board.
  /Assignments                          Open the board.
  /AssignmentAbandon <id>               Drop one you're carrying.
  /AssignmentList                       Print every valid assignment ID.
  /AssignmentGrant <player> <id>        Force-complete for a player.   (staff)
  /AssignmentReset <player>             Wipe their assignment record.  (staff)

Console:
  imperial_order_assignments              Open the board.
  imperial_order_assignments_status       Print tracker state.
  imperial_order_assignments_tracker      Client toggle, 0/1. Default 1.
  imperial_order_assignment_here          Print a Vector for where you're
                                          standing, ready to paste into a
                                          "visit" objective.            (staff)


SHIPPED ASSIGNMENTS
-------------------
  perimeter_sweep     Patrol       Kill 8 hostiles.            15m cooldown
  ordnance_disposal   Combat       Requires EOD cert.           1h cooldown
  supply_requisition  Logistics    Collect items.              20m cooldown
  basic_training      Training     One-time. Awards CQC cert.
  recon_advance       Intel        Requires level 5. Awards Recon cert.

A character may carry 3 at once (ASSIGN.MaxActive).


OBJECTIVE TYPES
---------------
  kill      Event-driven, via the OnNPCKilled hook.
            {type = "kill", target = "npc_rebel", count = 6}
            target = "*" matches any NPC class. Matching is case-insensitive.

  collect   Polled. Counts matching items in the character's inventory.
            {type = "collect", target = "ammo_smg", count = 3}

  visit     Polled. Completes when the player enters the radius.
            {type = "visit", pos = Vector(1024, -512, 96), radius = 220}
            Stand where you want it and run imperial_order_assignment_here.

  survive   Polled. Elapsed seconds since accepting. Resets on death.
            {type = "survive", count = 300}

  custom    Event-driven, advanced only by your own code:
            IMPERIAL_ORDER_ASSIGNMENTS.Progress(ply, "custom", "my_tag", 1)

Polled types are checked every ASSIGN.VisitCheckInterval seconds (default 2).


ADDING YOUR OWN
---------------
Edit sh_config.lua:

    ASSIGN.Register("hangar_defence", {
        name        = "Hangar Defence",
        issuer      = "Naval Command",
        category    = "combat",     -- patrol, combat, logistics, intel, training
        briefing    = "Hold the hangar against boarding parties.",
        requirements = {
            level = 4,
            certifications = {"cqc"},       -- cert IDs from the certifications plugin
            factions = {FACTION_NAVY}       -- optional
        },
        objectives  = {
            {type = "kill", target = "*", count = 10, label = "Repel boarders"},
            {type = "survive", count = 240, label = "Hold for 4 minutes"}
        },
        rewards     = {
            credits = 600,
            xp = 250,
            certification = {id = "heavy", tier = 1},
            items = {["ammo_smg"] = 2}
        },
        cooldown    = 3600,
        repeatable  = true
    })

An assignment with no objectives is rejected at load with a console warning,
rather than becoming a quest nobody can ever finish.

Never reuse an ID for a different assignment. Characters store the ID against
their completion history, so recycling one rewrites what people have done.
Retire the old ID and add a new one instead. Deleting is safe: stored entries
pointing at an ID that no longer exists are dropped on read.


REWARDS GO THROUGH YOUR REAL SYSTEMS
------------------------------------
XP is paid via IMPERIAL_ORDER_SKILLS.AddXP, not by writing the character var
directly, so level-ups, the max-level cap and the accelerated_training prestige
perk all still apply. If the skills plugin is missing it falls back to a direct
write so assignments still function.

Credits go through character:SetVar("credits", ...), the same path salary uses.

Certifications go through IMPERIAL_ORDER_CERTS.Grant, so a certification earned
from an assignment appears on the overhead nameplate immediately, exactly as a
staff-awarded one does.


HOW IT'S STORED
---------------
On the character, so assignments follow the character rather than the player:

    character:GetData("imperial_orderAssignments")
    {
        active = {
            ["perimeter_sweep"] = {
                accepted = 1717000000,
                progress = {8, 0},        -- one counter per objective
                mark     = 1717000120     -- survive-timer anchor
            }
        },
        completed = { ["basic_training"] = {count = 1, last = 1717000000} }
    }

Ordinary Helix character data. No schema change, no migration.

Progress is authoritative on the server. The client is sent the numbers so it
can draw the tracker; it is never asked what they are, and nothing it sends can
advance an objective.


HOOKS
-----
    ImperialOrderAssignmentAccepted  (client, character, id)
    ImperialOrderAssignmentAbandoned (client, character, id)
    ImperialOrderAssignmentCompleted (client, character, id, totalCompletions)

Example, logging completions into the service record system:

    hook.Add("ImperialOrderAssignmentCompleted", "LogToServiceRecord",
    function(client, character, id, count)
        local def = IMPERIAL_ORDER_ASSIGNMENTS.Get(id)
        print(character:GetName() .. " completed " .. def.name)
    end)
