PLUGIN.name = "Imperial Order Assignments"
PLUGIN.author = "1mmortalon3"
PLUGIN.description = "Imperial assignment board with objectives, requirements, cooldowns, and certification rewards."

ix.util.Include("sh_config.lua")
ix.util.Include("sv_assignments.lua")
ix.util.Include("cl_assignments.lua")
