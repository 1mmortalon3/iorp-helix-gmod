local PLUGIN = PLUGIN

PLUGIN.name = "Imperial Order Commslink"
PLUGIN.author = "Imperial Order"
PLUGIN.description = "Standalone Helix communications channels and commands."

ix.util.Include("sh_config.lua")

local CONFIG = ImperialOrderComms.Config

local HELP_LINES = {
    "/ecomms <message> - encrypted faction comms",
    "/rp <message> - local RP comms",
    "/oc <message> - open/global comms",
    "/ec <message> - enemy comms",
    "/ac <message> - Rebel Alliance-only comms",
    "/ic <message> - Imperial-only comms",
    "/sec <message> - secure/command comms",
    "/acomms <message> - anonymous comms",
    "/advert <message> - global advertisement",
    "/commshelp - display the available commands"
}

local COLORS = {
    encrypted = Color(91, 205, 235),
    roleplay = Color(220, 220, 225),
    open = Color(105, 185, 235),
    enemy = Color(235, 92, 92),
    alliance = Color(74, 142, 235),
    imperial = Color(210, 42, 42),
    secure = Color(240, 190, 70),
    anonymous = Color(172, 132, 215),
    advert = Color(245, 164, 62),
    help = Color(91, 205, 235),
    text = Color(225, 225, 230)
}

local function Lower(value)
    return string.lower(tostring(value or ""))
end

local function CharacterData(client)
    if not IsValid(client) or not client.GetCharacter then return nil, nil, nil, nil end

    local character = client:GetCharacter()
    if not character then return nil, nil, nil, nil end

    local factionID = character.GetFaction and character:GetFaction() or nil
    local classID = character.GetClass and character:GetClass() or nil
    local faction = factionID and ix.faction and ix.faction.indices and ix.faction.indices[factionID] or nil
    local class = classID and ix.class and ix.class.list and ix.class.list[classID] or nil

    return factionID, faction, classID, class
end

local function AddSearchValue(output, value)
    if value ~= nil then output[#output + 1] = Lower(value) end
end

local function RoleSearchText(client)
    local _, faction, _, class = CharacterData(client)
    local output = {}

    AddSearchValue(output, faction and faction.name)
    AddSearchValue(output, faction and faction.uniqueID)
    AddSearchValue(output, faction and faction.departmentCode)
    AddSearchValue(output, class and class.name)
    AddSearchValue(output, class and class.uniqueID)
    AddSearchValue(output, class and class.department)
    AddSearchValue(output, IsValid(client) and team.GetName(client:Team()) or nil)

    return table.concat(output, " ")
end

local function ContainsMarker(text, markers)
    for _, marker in ipairs(markers or {}) do
        if string.find(text, Lower(marker), 1, true) then return true end
    end

    return false
end

local function ConfigValueByID(values, numericID, data)
    if not istable(values) then return nil end

    if numericID ~= nil then
        local result = values[numericID]
        if result ~= nil then return result end

        result = values[tostring(numericID)]
        if result ~= nil then return result end
    end

    if istable(data) then
        local uniqueID = tostring(data.uniqueID or "")
        if uniqueID ~= "" and values[uniqueID] ~= nil then return values[uniqueID] end
    end

    return nil
end

local function Allegiance(client)
    local factionID, faction = CharacterData(client)
    local override = Lower(ConfigValueByID(CONFIG.FactionAffiliations, factionID, faction))

    if override == "alliance" or override == "imperial" then return override end

    local role = RoleSearchText(client)
    if ContainsMarker(role, CONFIG.AllianceMarkers) then return "alliance" end
    if ContainsMarker(role, CONFIG.ImperialMarkers) then return "imperial" end

    return nil
end

local function SameFaction(speaker, listener)
    local speakerFaction = CharacterData(speaker)
    local listenerFaction = CharacterData(listener)

    if speakerFaction == nil or listenerFaction == nil then return speaker == listener end
    return tostring(speakerFaction) == tostring(listenerFaction)
end

local function DataGrantsSecure(data)
    return istable(data) and (
        data.canUseSecureComms == true or
        data.commandComms == true or
        data.isCommand == true or
        data.isOfficer == true
    )
end

local function CanUseSecure(client)
    if not IsValid(client) then return false end
    if CONFIG.IncludeAdminsInSecure ~= false and client:IsAdmin() then return true end

    local factionID, faction, classID, class = CharacterData(client)
    if ConfigValueByID(CONFIG.SecureFactions, factionID, faction) == true then return true end
    if ConfigValueByID(CONFIG.SecureClasses, classID, class) == true then return true end
    if DataGrantsSecure(faction) or DataGrantsSecure(class) then return true end

    return ContainsMarker(RoleSearchText(client), CONFIG.CommandMarkers)
end

local function CanSpeak(client)
    if CONFIG.DeadCanChat == true then return true end
    if IsValid(client) and client:Alive() then return true end

    if IsValid(client) then
        if client.NotifyLocalized then
            client:NotifyLocalized("noPerm")
        elseif client.Notify then
            client:Notify("You cannot use comms while dead.")
        end
    end

    return false
end

local function Deny(client, message)
    if IsValid(client) and client.Notify then client:Notify(message) end
    return false
end

local function LocalCanHear(_, speaker, listener)
    if not IsValid(speaker) or not IsValid(listener) then return false end

    local range = tonumber(CONFIG.LocalRange) or 0
    if range <= 0 then range = tonumber(ix.config.Get("chatRange", 280)) or 280 end
    range = math.max(1, range)

    return speaker == listener or speaker:GetPos():DistToSqr(listener:GetPos()) <= range * range
end

local function FactionCanHear(_, speaker, listener)
    return SameFaction(speaker, listener)
end

local function EnemyCanHear(_, speaker, listener)
    if speaker == listener then return true end

    local speakerSide = Allegiance(speaker)
    local listenerSide = Allegiance(listener)
    return speakerSide ~= nil and listenerSide ~= nil and speakerSide ~= listenerSide
end

local function AllianceCanHear(_, _, listener)
    return Allegiance(listener) == "alliance"
end

local function ImperialCanHear(_, _, listener)
    return Allegiance(listener) == "imperial"
end

local function SecureCanHear(_, _, listener)
    return CanUseSecure(listener)
end

local function EnemyCanSay(_, speaker)
    if not CanSpeak(speaker) then return false end
    if Allegiance(speaker) == nil then
        return Deny(speaker, "Enemy comms require an Alliance or Imperial character.")
    end

    return true
end

local function AllianceCanSay(_, speaker)
    if not CanSpeak(speaker) then return false end
    if Allegiance(speaker) ~= "alliance" then
        return Deny(speaker, "Alliance comms are restricted to Rebel Alliance characters.")
    end

    return true
end

local function ImperialCanSay(_, speaker)
    if not CanSpeak(speaker) then return false end
    if Allegiance(speaker) ~= "imperial" then
        return Deny(speaker, "Imperial comms are restricted to Imperial characters.")
    end

    return true
end

local function SecureCanSay(_, speaker)
    if not CanSpeak(speaker) then return false end
    if not CanUseSecure(speaker) then
        return Deny(speaker, "Secure comms require command or officer authorization.")
    end

    return true
end

function PLUGIN:InitializedChatClasses()
    ix.chat.Register("imperial_order_ecomms", {
        prefix = "/ecomms",
        description = "Encrypted faction communications.",
        format = "[ENCRYPTED COMMS] %s: %s",
        color = COLORS.encrypted,
        CanHear = FactionCanHear,
        deadCanChat = CONFIG.DeadCanChat == true,
        bNoIndicator = true
    })

    ix.chat.Register("imperial_order_rp", {
        prefix = "/rp",
        description = "Local roleplay communications.",
        format = "[LOCAL RP] %s: %s",
        color = COLORS.roleplay,
        CanHear = LocalCanHear,
        deadCanChat = CONFIG.DeadCanChat == true
    })

    ix.chat.Register("imperial_order_oc", {
        prefix = "/oc",
        description = "Open global communications.",
        format = "[OPEN COMMS] %s: %s",
        color = COLORS.open,
        deadCanChat = CONFIG.DeadCanChat == true,
        bNoIndicator = true
    })

    ix.chat.Register("imperial_order_ec", {
        prefix = "/ec",
        description = "Communicate with the opposing allegiance.",
        format = "[ENEMY COMMS] %s: %s",
        color = COLORS.enemy,
        CanHear = EnemyCanHear,
        CanSay = EnemyCanSay,
        deadCanChat = CONFIG.DeadCanChat == true,
        bNoIndicator = true
    })

    ix.chat.Register("imperial_order_ac", {
        prefix = "/ac",
        description = "Rebel Alliance-only communications.",
        format = "[ALLIANCE COMMS] %s: %s",
        color = COLORS.alliance,
        CanHear = AllianceCanHear,
        CanSay = AllianceCanSay,
        deadCanChat = CONFIG.DeadCanChat == true,
        bNoIndicator = true
    })

    ix.chat.Register("imperial_order_ic", {
        prefix = "/ic",
        description = "Imperial-only communications.",
        format = "[IMPERIAL COMMS] %s: %s",
        color = COLORS.imperial,
        CanHear = ImperialCanHear,
        CanSay = ImperialCanSay,
        deadCanChat = CONFIG.DeadCanChat == true,
        bNoIndicator = true
    })

    ix.chat.Register("imperial_order_sec", {
        prefix = "/sec",
        description = "Secure communications for command personnel.",
        format = "[SECURE COMMS] %s: %s",
        color = COLORS.secure,
        CanHear = SecureCanHear,
        CanSay = SecureCanSay,
        deadCanChat = CONFIG.DeadCanChat == true,
        bNoIndicator = true
    })

    ix.chat.Register("imperial_order_acomms", {
        prefix = "/acomms",
        description = "Anonymous global communications.",
        color = COLORS.anonymous,
        deadCanChat = CONFIG.DeadCanChat == true,
        bNoIndicator = true,
        OnChatAdd = function(self, _, text)
            chat.AddText(self.color, "[ANONYMOUS COMMS] ", COLORS.text, text)
        end
    })

    ix.chat.Register("imperial_order_advert", {
        prefix = "/advert",
        description = "Post a global advertisement.",
        format = "[ADVERTISEMENT] %s: %s",
        color = COLORS.advert,
        deadCanChat = CONFIG.DeadCanChat == true,
        bNoIndicator = true
    })

    ix.chat.Register("imperial_order_commshelp", {
        color = COLORS.help,
        CanSay = function() return true end,
        OnChatAdd = function(self, _, text)
            chat.AddText(self.color, "[COMMSLINK] ", COLORS.text, text)
        end
    })
end

ix.command.Add("commshelp", {
    description = "Display all Imperial Order Commslink commands.",
    OnRun = function(_, client)
        ix.chat.Send(client, "imperial_order_commshelp", "=== Imperial Order Commslink Commands ===", false, {client})

        for _, line in ipairs(HELP_LINES) do
            ix.chat.Send(client, "imperial_order_commshelp", line, false, {client})
        end
    end
})
