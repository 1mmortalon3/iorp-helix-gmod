ImperialOrderComms = ImperialOrderComms or {}

ImperialOrderComms.Config = {
    -- Set this above zero to override Helix's chatRange for /rp.
    LocalRange = 0,

    -- Staff can use and receive /sec even when their character is not a
    -- command role.
    IncludeAdminsInSecure = true,

    -- Comms are unavailable while dead unless this is enabled.
    DeadCanChat = false,

    -- Faction/class names and unique IDs are searched case-insensitively.
    AllianceMarkers = {
        "rebel",
        "alliance"
    },

    ImperialMarkers = {
        "imperial",
        "empire",
        "emperor",
        "stormtrooper",
        "death trooper",
        "inferno squad",
        "inquisitor"
    },

    CommandMarkers = {
        "high command",
        "commander",
        "commanding",
        "officer",
        "general",
        "admiral",
        "moff",
        "director",
        "dark council"
    },

    -- Optional exact overrides. Keys can be faction numeric IDs or faction
    -- unique IDs; values must be "alliance" or "imperial".
    FactionAffiliations = {
        -- [FACTION_REBEL_ALLIANCE] = "alliance",
        -- ["rebel_alliance"] = "alliance",
        -- [FACTION_IMPERIAL_NAVY] = "imperial"
    },

    -- Optional exact authorization lists for /sec. Keys can be numeric IDs or
    -- unique IDs. A value of true grants secure comms access.
    SecureFactions = {
        -- [FACTION_IMPERIAL_HIGH_COMMAND] = true
    },

    SecureClasses = {
        -- [CLASS_GRAND_ADMIRAL] = true
    }
}
