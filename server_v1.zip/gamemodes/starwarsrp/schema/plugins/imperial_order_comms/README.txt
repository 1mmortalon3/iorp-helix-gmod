Imperial Order COMMSLINK - STANDALONE HELIX PLUGIN

INSTALLATION

1. Place the imperial_order_comms folder in:
   gamemodes/<your_schema>/schema/plugins/
2. Restart the server or change maps.
3. Use /commshelp in chat to confirm the plugin loaded.

COMMANDS

/ecomms <message> - encrypted faction comms
/rp <message> - local RP comms
/oc <message> - open/global comms
/ec <message> - enemy comms
/ac <message> - Rebel Alliance-only comms
/ic <message> - Imperial-only comms
/sec <message> - secure/command comms
/acomms <message> - anonymous comms
/advert <message> - global advertisement
/commshelp - display the available commands

CONFIGURATION

Edit sh_config.lua to change faction-name markers, local chat range, secure
comms authorization, admin access, or dead-player access.

The plugin uses Helix chat classes directly. It does not require DarkRP, the
Imperial Order HUD, or the Imperial communications addon.
