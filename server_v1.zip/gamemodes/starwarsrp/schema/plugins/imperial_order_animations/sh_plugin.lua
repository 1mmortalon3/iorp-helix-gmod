local PLUGIN = PLUGIN

PLUGIN.name = "Imperial Animation Menu"
PLUGIN.author = "1mmortalon3"
PLUGIN.description = "A Helix-compatible roleplay pose menu opened with G. Replaces Perfect Hands without adding a weapon or overriding SWEP animations."

IMPERIAL_ORDER = IMPERIAL_ORDER or {}
IMPERIAL_ORDER.Animations = IMPERIAL_ORDER.Animations or {}

local AP = IMPERIAL_ORDER.Animations

AP.Definitions = AP.Definitions or {}
AP.Order = AP.Order or {}
AP.AllBoneNames = AP.AllBoneNames or {}

local function AddPose(id, name, description, bones)
    AP.Definitions[id] = {
        name = name,
        description = description,
        bones = bones
    }

    AP.Order[#AP.Order + 1] = id

    for boneName in pairs(bones) do
        if boneName ~= "Animation.ZOffset" then
            AP.AllBoneNames[boneName] = true
        end
    end
end

if #AP.Order == 0 then
    AddPose("attention", "Attention", "Stand formally at attention.", {
        ["ValveBiped.Bip01_Head1"] = Angle(0, 12, 0),
        ["ValveBiped.Bip01_L_UpperArm"] = Angle(-6, -6, 0),
        ["ValveBiped.Bip01_R_Forearm"] = Angle(-9, 0, 0),
        ["ValveBiped.Bip01_L_Forearm"] = Angle(9, 0, 0),
        ["ValveBiped.Bip01_R_Thigh"] = Angle(-3, 0, 0),
        ["ValveBiped.Bip01_L_Thigh"] = Angle(3, 5, 0),
        ["ValveBiped.Bip01_R_Foot"] = Angle(20, 0, 0),
        ["ValveBiped.Bip01_L_Foot"] = Angle(-20, 0, 0),
        ["ValveBiped.Bip01_R_Hand"] = Angle(0, 0, 20),
        ["ValveBiped.Bip01_L_Hand"] = Angle(0, 0, -20)
    })

    AddPose("salute", "Imperial Salute", "Stand at attention and salute with your right hand.", {
        ["ValveBiped.Bip01_R_UpperArm"] = Angle(80, -95, -77.5),
        ["ValveBiped.Bip01_R_Forearm"] = Angle(35, -125, -5)
    })

    AddPose("armsbehind", "Hands Behind Back", "Adopt a formal parade-rest stance.", {
        ["ValveBiped.Bip01_R_UpperArm"] = Angle(3, 15, 2),
        ["ValveBiped.Bip01_R_Forearm"] = Angle(-63, 1, -84),
        ["ValveBiped.Bip01_L_UpperArm"] = Angle(3, 15, 2.654),
        ["ValveBiped.Bip01_L_Forearm"] = Angle(53, -29, 31),
        ["ValveBiped.Bip01_R_Thigh"] = Angle(4, 0, 0),
        ["ValveBiped.Bip01_L_Thigh"] = Angle(-8, 0, 0)
    })

    AddPose("armsinfront", "Hands in Front", "Rest both hands in front of your body.", {
        ["ValveBiped.Bip01_R_Forearm"] = Angle(-43, -107, 15),
        ["ValveBiped.Bip01_R_UpperArm"] = Angle(20, -57, -6),
        ["ValveBiped.Bip01_L_UpperArm"] = Angle(-28, -59, 1),
        ["ValveBiped.Bip01_L_Forearm"] = Angle(51, -120, -18),
        ["ValveBiped.Bip01_R_Hand"] = Angle(14, -33, -7),
        ["ValveBiped.Bip01_L_Hand"] = Angle(25, 31, -14)
    })

    AddPose("surrender", "Hands Up", "Raise both hands in surrender.", {
        ["ValveBiped.Bip01_L_Forearm"] = Angle(25, -65, 25),
        ["ValveBiped.Bip01_R_Forearm"] = Angle(-25, -65, -25),
        ["ValveBiped.Bip01_L_UpperArm"] = Angle(-70, -180, 70),
        ["ValveBiped.Bip01_R_UpperArm"] = Angle(70, -180, -70)
    })

    AddPose("armsbehindhead", "Hands Behind Head", "Place both hands behind your head.", {
        ["ValveBiped.Bip01_L_Forearm"] = Angle(25, -115, 15),
        ["ValveBiped.Bip01_R_Forearm"] = Angle(-32, -115, -15),
        ["ValveBiped.Bip01_L_UpperArm"] = Angle(-50, -210, 80),
        ["ValveBiped.Bip01_R_UpperArm"] = Angle(50, -210, -80)
    })

    AddPose("armsonbelt", "Hands on Belt", "Rest both hands on your utility belt.", {
        ["ValveBiped.Bip01_L_Forearm"] = Angle(50, -90, 5),
        ["ValveBiped.Bip01_R_Forearm"] = Angle(-50, -90, 5),
        ["ValveBiped.Bip01_L_UpperArm"] = Angle(-40, 30, -20),
        ["ValveBiped.Bip01_R_UpperArm"] = Angle(40, 30, 20)
    })

    AddPose("comlink", "Comlink", "Speak into a wrist-mounted comlink.", {
        ["ValveBiped.Bip01_R_UpperArm"] = Angle(32.9448, -103.5211, 2.2273),
        ["ValveBiped.Bip01_R_Forearm"] = Angle(-90.3271, -31.3616, -41.8804),
        ["ValveBiped.Bip01_R_Hand"] = Angle(0, 0, -24)
    })

    AddPose("hololink", "Holographic Display", "Inspect a wrist-mounted holographic display.", {
        ["ValveBiped.Bip01_R_UpperArm"] = Angle(10, -20, 0),
        ["ValveBiped.Bip01_R_Hand"] = Angle(0, 1, 50),
        ["ValveBiped.Bip01_Head1"] = Angle(0, -30, -20),
        ["ValveBiped.Bip01_R_Forearm"] = Angle(0, -65, 39.8863)
    })

    AddPose("point", "Direct Forward", "Point forward with your right hand.", {
        ["ValveBiped.Bip01_R_Finger2"] = Angle(4, -52, 0),
        ["ValveBiped.Bip01_R_Finger21"] = Angle(0, -58, 0),
        ["ValveBiped.Bip01_R_Finger3"] = Angle(4, -52, 0),
        ["ValveBiped.Bip01_R_Finger31"] = Angle(0, -58, 0),
        ["ValveBiped.Bip01_R_Finger4"] = Angle(4, -52, 0),
        ["ValveBiped.Bip01_R_Finger41"] = Angle(0, -58, 0),
        ["ValveBiped.Bip01_R_UpperArm"] = Angle(25, -87, 0)
    })

    AddPose("pensive", "Pensive", "Adopt a thoughtful command posture.", {
        ["ValveBiped.Bip01_R_Forearm"] = Angle(-14.4, -106.1841, 76.3190),
        ["ValveBiped.Bip01_R_UpperArm"] = Angle(23.6567, -58.7239, -5.3269),
        ["ValveBiped.Bip01_L_UpperArm"] = Angle(-28.9139, -59.4082, 1.0253),
        ["ValveBiped.Bip01_L_Forearm"] = Angle(51.0387, -120.4417, -18.8699),
        ["ValveBiped.Bip01_R_Hand"] = Angle(-6.2242, -7.9062, 10.8624),
        ["ValveBiped.Bip01_L_Hand"] = Angle(25.9594, 31.5645, -14.9794)
    })

    AddPose("typing", "Console Typing", "Hold your hands over a keyboard or control console.", {
        ["ValveBiped.Bip01_L_Forearm"] = Angle(0, 0, 0),
        ["ValveBiped.Bip01_R_Forearm"] = Angle(0, 0, 0),
        ["ValveBiped.Bip01_L_UpperArm"] = Angle(-28, -65, 50),
        ["ValveBiped.Bip01_R_UpperArm"] = Angle(20, -65, -50)
    })

    AddPose("highfive", "Raised Hand", "Raise one hand for a greeting or signal.", {
        ["ValveBiped.Bip01_L_Forearm"] = Angle(25, -65, 25),
        ["ValveBiped.Bip01_L_UpperArm"] = Angle(-70, -180, 70)
    })

    AddPose("kneel", "Kneel", "Kneel on one knee for roleplay scenes.", {
        ["Animation.ZOffset"] = -17,
        ["ValveBiped.Bip01_R_Forearm"] = Angle(-90, -30, -70),
        ["ValveBiped.Bip01_R_UpperArm"] = Angle(50, -20, 40),
        ["ValveBiped.Bip01_R_Calf"] = Angle(0, 90, 0),
        ["ValveBiped.Bip01_L_Calf"] = Angle(0, 80, 0),
        ["ValveBiped.Bip01_L_Foot"] = Angle(0, 48.5, 0),
        ["ValveBiped.Bip01_R_Thigh"] = Angle(0, -90, 0),
        ["ValveBiped.Bip01_Head1"] = Angle(0, -15, 0)
    })
end

ix.config.Add("imperial_orderAnimationBlendSpeed", 7, "Controls how quickly roleplay poses blend in and out.", nil, {
    data = {min = 1, max = 20, decimals = 1},
    category = "Imperial Animations"
})

ix.config.Add("imperial_orderAnimationMovementCutoff", 8, "Movement speed that cancels a roleplay pose.", nil, {
    data = {min = 0, max = 100, decimals = 0},
    category = "Imperial Animations"
})

function AP.GetPose(id)
    return AP.Definitions[tostring(id or "")]
end

function AP.IsPlaying(client)
    return IsValid(client) and client:GetNW2Bool("imperial_orderAnimationPlaying", false)
end

if SERVER then
    util.AddNetworkString("imperial_orderAnimationsPlay")
    util.AddNetworkString("imperial_orderAnimationsStop")
    util.AddNetworkString("imperial_orderAnimationsOpen")

    local function Notify(client, text)
        if not IsValid(client) then return end

        if isfunction(client.Notify) then
            client:Notify(text)
        else
            client:ChatPrint(text)
        end
    end

    function AP.Stop(client)
        if not IsValid(client) then return end

        client:SetNW2Bool("imperial_orderAnimationPlaying", false)
        client:SetNW2String("imperial_orderAnimationID", "")
    end

    local function ClearPerfectHands(client, restoreDefaultHands)
        if not IsValid(client) then return end

        client:SetNW2Bool("ixPerfectHandsPlaying", false)
        client:SetNW2String("ixPerfectHandsAnimation", "")
        client:SetNW2Entity("ixPerfectHandsHeldEntity", NULL)

        local removedActiveHands = false
        local activeWeapon = client:GetActiveWeapon()

        for _, class in ipairs({"ix_perfecthands", "mvp_perfecthands"}) do
            if IsValid(activeWeapon) and activeWeapon:GetClass() == class then
                removedActiveHands = true
            end

            if client:HasWeapon(class) then
                client:StripWeapon(class)
            end
        end

        if restoreDefaultHands and weapons.GetStored("ix_hands") and not client:HasWeapon("ix_hands") then
            client:Give("ix_hands")
        end

        if removedActiveHands and client:HasWeapon("ix_hands") then
            client:SelectWeapon("ix_hands")
        end
    end

    AP.ClearPerfectHands = ClearPerfectHands

    local function CanPlay(client, poseID)
        if not IsValid(client) or not client:IsPlayer() or not client:Alive() then
            return false, "You must be alive to use an animation."
        end

        if not client:GetCharacter() then
            return false, "Load a character before using animations."
        end

        if client:InVehicle() or client:GetMoveType() == MOVETYPE_OBSERVER then
            return false, "Animations cannot be used in this state."
        end

        if client.IsRestricted and client:IsRestricted() then
            return false, "You cannot use animations while restrained."
        end

        if not AP.GetPose(poseID) then
            return false, "That animation does not exist."
        end

        local allowed, reason = hook.Run("CanUseIMPERIAL_ORDERAnimation", client, poseID)
        if allowed == false then
            return false, reason or "You cannot use that animation right now."
        end

        return true
    end

    net.Receive("imperial_orderAnimationsPlay", function(_, client)
        if (client.imperial_orderNextAnimationRequest or 0) > CurTime() then return end
        client.imperial_orderNextAnimationRequest = CurTime() + 0.2

        local poseID = net.ReadString()
        local allowed, reason = CanPlay(client, poseID)

        if not allowed then
            Notify(client, reason)
            return
        end

        ClearPerfectHands(client, true)
        client:SetNW2String("imperial_orderAnimationID", poseID)
        client:SetNW2Bool("imperial_orderAnimationPlaying", true)
    end)

    net.Receive("imperial_orderAnimationsStop", function(_, client)
        AP.Stop(client)
    end)

    ix.command.Add("Animations", {
        description = "Open the Imperial roleplay animation menu.",
        OnRun = function(_, client)
            if not IsValid(client) or not client:GetCharacter() then
                return "Load a character before opening the animation menu."
            end

            net.Start("imperial_orderAnimationsOpen")
            net.Send(client)
        end
    })

    local cancelKeys = {
        [IN_ATTACK] = true,
        [IN_ATTACK2] = true,
        [IN_RELOAD] = true,
        [IN_USE] = true,
        [IN_JUMP] = true,
        [IN_DUCK] = true,
        [IN_FORWARD] = true,
        [IN_BACK] = true,
        [IN_MOVELEFT] = true,
        [IN_MOVERIGHT] = true,
        [IN_SPEED] = true
    }

    function PLUGIN:KeyPress(client, key)
        if AP.IsPlaying(client) and cancelKeys[key] then
            AP.Stop(client)
        end
    end

    function PLUGIN:SetupMove(client, moveData)
        if not AP.IsPlaying(client) then return end

        local cutoff = math.max(ix.config.Get("imperial_orderAnimationMovementCutoff", 8), 0)
        if moveData:GetVelocity():Length() > cutoff then
            AP.Stop(client)
        end
    end

    function PLUGIN:PlayerSwitchWeapon(client)
        if AP.IsPlaying(client) then
            AP.Stop(client)
        end
    end

    function PLUGIN:PlayerEnteredVehicle(client)
        AP.Stop(client)
    end

    function PLUGIN:PlayerDeath(client)
        AP.Stop(client)
    end

    function PLUGIN:PlayerDisconnected(client)
        AP.Stop(client)
    end

    function PLUGIN:EntityTakeDamage(entity)
        if IsValid(entity) and entity:IsPlayer() and AP.IsPlaying(entity) then
            AP.Stop(entity)
        end
    end

    local function ResetForCharacter(client, delay)
        AP.Stop(client)

        timer.Simple(delay or 0, function()
            if IsValid(client) and client:GetCharacter() then
                ClearPerfectHands(client, true)
            end
        end)
    end

    function PLUGIN:PlayerLoadedCharacter(client)
        ResetForCharacter(client, 0.5)
    end

    function PLUGIN:PlayerSpawn(client)
        ResetForCharacter(client, 0.75)
    end

    function PLUGIN:PostPlayerLoadout(client)
        ResetForCharacter(client, 0)
    end

    function PLUGIN:WeaponEquip(weapon, client)
        if not IsValid(weapon) or not IsValid(client) then return end

        local class = weapon:GetClass()
        if class ~= "ix_perfecthands" and class ~= "mvp_perfecthands" then return end

        timer.Simple(0, function()
            if IsValid(client) then
                ClearPerfectHands(client, true)
            end
        end)
    end
else
    surface.CreateFont("IMPERIAL_ORDER_Animations_Title", {
        font = "Arial",
        size = 30,
        weight = 900,
        antialias = true,
        extended = true
    })

    surface.CreateFont("IMPERIAL_ORDER_Animations_Header", {
        font = "Arial",
        size = 19,
        weight = 800,
        antialias = true,
        extended = true
    })

    surface.CreateFont("IMPERIAL_ORDER_Animations_Text", {
        font = "Arial",
        size = 15,
        weight = 550,
        antialias = true,
        extended = true
    })

    local colors = {
        background = Color(3, 4, 6, 248),
        panel = Color(16, 18, 22, 248),
        panelHover = Color(30, 32, 37, 250),
        red = Color(174, 8, 15),
        redBright = Color(238, 25, 31),
        redDark = Color(73, 4, 8),
        steel = Color(134, 139, 145),
        line = Color(86, 91, 97, 160),
        text = Color(238, 240, 243),
        textDim = Color(145, 150, 158)
    }

    local function Scale(value)
        if ImperialUI and isfunction(ImperialUI.Scale) then
            return ImperialUI.Scale(value)
        end

        local factor = math.min(ScrW() / 1920, ScrH() / 1080)
        return math.max(1, math.floor((tonumber(value) or 0) * math.Clamp(factor, 0.68, 1.35)))
    end

    local function ResetPoseBones(client)
        if not IsValid(client) then return end

        local state = client.imperial_orderAnimationClientState
        if not state then return end

        for boneName in pairs(AP.AllBoneNames) do
            local bone = client:LookupBone(boneName)
            if bone then
                client:ManipulateBoneAngles(bone, angle_zero)
            end
        end

        client:ManipulateBonePosition(0, vector_origin)
        client.imperial_orderAnimationClientState = nil
    end

    AP.ResetPoseBones = ResetPoseBones

    local function ApplyPose(client, pose, playing)
        if not IsValid(client) then return end

        local state = client.imperial_orderAnimationClientState
        if not state then
            state = {
                angles = {},
                z = 0,
                model = client:GetModel()
            }
            client.imperial_orderAnimationClientState = state
        elseif state.model ~= client:GetModel() then
            ResetPoseBones(client)
            state = {
                angles = {},
                z = 0,
                model = client:GetModel()
            }
            client.imperial_orderAnimationClientState = state
        end

        local speed = math.max(ix.config.Get("imperial_orderAnimationBlendSpeed", 7), 0.1)
        local fraction = math.Clamp(FrameTime() * speed, 0, 1)
        local hasVisiblePose = false

        for boneName in pairs(AP.AllBoneNames) do
            local target = angle_zero
            if playing and pose and pose.bones[boneName] then
                target = pose.bones[boneName]
            end

            local current = state.angles[boneName] or angle_zero
            current = LerpAngle(fraction, current, target)
            state.angles[boneName] = current

            if math.abs(current.p) > 0.05 or math.abs(current.y) > 0.05 or math.abs(current.r) > 0.05 then
                hasVisiblePose = true
            end

            local bone = client:LookupBone(boneName)
            if bone then
                client:ManipulateBoneAngles(bone, current)
            end
        end

        local targetZ = 0
        if playing and pose then
            targetZ = tonumber(pose.bones["Animation.ZOffset"]) or 0
        end

        state.z = Lerp(fraction, state.z or 0, targetZ)
        client:ManipulateBonePosition(0, Vector(0, 0, state.z))

        if math.abs(state.z) > 0.05 then
            hasVisiblePose = true
        end

        if not playing and not hasVisiblePose then
            ResetPoseBones(client)
        end
    end

    local function IsPanelActuallyVisible(panel)
        if not IsValid(panel) then return false end

        local current = panel
        while IsValid(current) do
            if not current:IsVisible() then return false end
            current = current:GetParent()
        end

        return true
    end

    local function CanOpenMenu()
        local client = LocalPlayer()
        if not IsValid(client) or not client:Alive() or not client:GetCharacter() then return false end
        if client:GetMoveType() == MOVETYPE_OBSERVER or client:InVehicle() then return false end
        if gui.IsGameUIVisible() then return false end

        local focus = vgui.GetKeyboardFocus()
        if IsValid(focus) and IsPanelActuallyVisible(focus) then return false end

        if IsPanelActuallyVisible(ix.gui.characterMenu) or IsPanelActuallyVisible(ix.gui.characterCreation) then
            return false
        end

        return true
    end

    function AP.OpenMenu()
        -- Closing must be checked before CanOpenMenu because the animation frame
        -- owns keyboard focus while it is open.
        if IsValid(ix.gui.imperial_orderAnimationsMenu) then
            ix.gui.imperial_orderAnimationsMenu:Remove()
            return
        end

        if not CanOpenMenu() then return end

        local frame = vgui.Create("DFrame")
        ix.gui.imperial_orderAnimationsMenu = frame
        frame:SetSize(math.min(ScrW() - Scale(60), Scale(960)), math.min(ScrH() - Scale(60), Scale(700)))
        frame:Center()
        frame:SetTitle("")
        frame:ShowCloseButton(false)
        frame:SetDraggable(false)
        frame:MakePopup()
        frame:SetKeyboardInputEnabled(true)
        frame.startTime = SysTime()

        frame.Paint = function(panel, width, height)
            Derma_DrawBackgroundBlur(panel, panel.startTime)
            surface.SetDrawColor(colors.background)
            surface.DrawRect(0, 0, width, height)
            surface.SetDrawColor(colors.red)
            surface.DrawRect(0, 0, Scale(6), height)
            surface.DrawRect(0, 0, width, Scale(4))
            surface.SetDrawColor(colors.line)
            surface.DrawOutlinedRect(Scale(13), Scale(13), width - Scale(26), height - Scale(26), 1)

            draw.SimpleText("IMPERIAL ANIMATION DIRECTORY", "IMPERIAL_ORDER_Animations_Title", Scale(30), Scale(25), colors.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            draw.SimpleText("G · SELECT A ROLEPLAY POSE", "IMPERIAL_ORDER_Animations_Text", Scale(32), Scale(62), colors.textDim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        end

        frame.OnKeyCodePressed = function(panel, key)
            -- Do not close on the same G key-down event that created the frame.
            -- G toggling is handled by the physical-key edge detector below.
            if key == KEY_ESCAPE then
                panel:Remove()
            end
        end

        local close = vgui.Create("DButton", frame)
        close:SetText("×")
        close:SetFont("IMPERIAL_ORDER_Animations_Header")
        close:SetTextColor(colors.text)
        close:SetSize(Scale(42), Scale(34))
        close:SetPos(frame:GetWide() - Scale(66), Scale(22))
        close.DoClick = function()
            frame:Remove()
        end
        close.Paint = function(panel, width, height)
            surface.SetDrawColor(panel:IsHovered() and colors.redDark or colors.panel)
            surface.DrawRect(0, 0, width, height)
            surface.SetDrawColor(panel:IsHovered() and colors.redBright or colors.line)
            surface.DrawOutlinedRect(0, 0, width, height, 1)
        end

        local stop = vgui.Create("DButton", frame)
        stop:SetText("")
        stop:SetSize(Scale(190), Scale(38))
        stop:SetPos(frame:GetWide() - Scale(270), Scale(68))
        stop.DoClick = function()
            net.Start("imperial_orderAnimationsStop")
            net.SendToServer()
            frame:Remove()
        end
        stop.Paint = function(panel, width, height)
            surface.SetDrawColor(panel:IsHovered() and colors.redDark or colors.panel)
            surface.DrawRect(0, 0, width, height)
            surface.SetDrawColor(colors.red)
            surface.DrawOutlinedRect(0, 0, width, height, 1)
            draw.SimpleText("STOP ANIMATION", "IMPERIAL_ORDER_Animations_Text", width / 2, height / 2, colors.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end

        local scroll = vgui.Create("DScrollPanel", frame)
        scroll:SetPos(Scale(28), Scale(120))
        scroll:SetSize(frame:GetWide() - Scale(56), frame:GetTall() - Scale(148))

        local canvas = scroll:GetCanvas()
        local grid = vgui.Create("DIconLayout", canvas)
        grid:Dock(TOP)
        grid:SetSpaceX(Scale(12))
        grid:SetSpaceY(Scale(12))

        local usableWidth = scroll:GetWide() - Scale(34)
        local columns = usableWidth >= Scale(700) and 3 or 2
        local cardWidth = math.floor((usableWidth - Scale(12) * (columns - 1)) / columns)

        for _, poseID in ipairs(AP.Order) do
            local poseData = AP.GetPose(poseID)
            local selectedPoseID = poseID
            local card = grid:Add("DButton")
            card:SetSize(cardWidth, Scale(112))
            card:SetText("")

            card.Paint = function(panel, width, height)
                surface.SetDrawColor(panel:IsHovered() and colors.panelHover or colors.panel)
                surface.DrawRect(0, 0, width, height)
                surface.SetDrawColor(panel:IsHovered() and colors.redBright or colors.line)
                surface.DrawOutlinedRect(0, 0, width, height, 1)
                surface.SetDrawColor(colors.red)
                surface.DrawRect(0, 0, Scale(4), height)

                draw.SimpleText(poseData.name, "IMPERIAL_ORDER_Animations_Header", Scale(16), Scale(13), colors.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            end

            local description = vgui.Create("DLabel", card)
            description:SetPos(Scale(16), Scale(43))
            description:SetSize(cardWidth - Scale(32), Scale(58))
            description:SetFont("IMPERIAL_ORDER_Animations_Text")
            description:SetTextColor(colors.textDim)
            description:SetText(poseData.description)
            description:SetWrap(true)
            description:SetAutoStretchVertical(false)
            description:SetContentAlignment(7)
            description:SetMouseInputEnabled(false)

            card.DoClick = function()
                net.Start("imperial_orderAnimationsPlay")
                net.WriteString(selectedPoseID)
                net.SendToServer()
                frame:Remove()
            end
        end
    end

    net.Receive("imperial_orderAnimationsOpen", AP.OpenMenu)

    concommand.Add("imperial_order_animations_menu", AP.OpenMenu)
    concommand.Add("imperial_order_animations_stop", function()
        net.Start("imperial_orderAnimationsStop")
        net.SendToServer()
    end)

    local nextGPress = 0
    local gWasDown = false

    local function ToggleFromG()
        if RealTime() < nextGPress then return end
        nextGPress = RealTime() + 0.30
        AP.OpenMenu()
    end

    hook.Remove("PlayerButtonDown", "IMPERIAL_ORDER.Animations.GKeyV259")
    hook.Remove("PlayerBindPress", "IMPERIAL_ORDER.Animations.BlockSprayOnGV259")
    hook.Remove("Think", "IMPERIAL_ORDER.Animations.GKeyEdgeV261")

    hook.Add("PlayerButtonDown", "IMPERIAL_ORDER.Animations.GKeyV261", function(client, key)
        if client ~= LocalPlayer() or key ~= KEY_G then return end
        ToggleFromG()
    end)

    hook.Add("PlayerBindPress", "IMPERIAL_ORDER.Animations.GBindV261", function(_, bind, pressed)
        if not pressed then return end

        bind = string.lower(tostring(bind or ""))
        local physicalG = input.IsKeyDown(KEY_G)
        local sprayBind = string.find(bind, "impulse 201", 1, true) ~= nil

        if physicalG then
            ToggleFromG()
            if sprayBind then return true end
        end
    end)

    -- Some input/Derma states do not emit PlayerButtonDown. This physical-key
    -- edge detector makes G reliable while still triggering only once per press.
    hook.Add("Think", "IMPERIAL_ORDER.Animations.GKeyEdgeV261", function()
        local down = input.IsKeyDown(KEY_G)
        if down and not gWasDown then
            ToggleFromG()
        end
        gWasDown = down
    end)

    hook.Add("Think", "IMPERIAL_ORDER.Animations.ApplyV259", function()
        for _, client in ipairs(player.GetAll()) do
            if IsValid(client) then
                local playing = client:Alive() and client:GetNW2Bool("imperial_orderAnimationPlaying", false)
                local pose = AP.GetPose(client:GetNW2String("imperial_orderAnimationID", ""))

                if playing and pose then
                    ApplyPose(client, pose, true)
                elseif client.imperial_orderAnimationClientState then
                    ApplyPose(client, nil, false)
                end
            end
        end
    end)

    hook.Add("ShutDown", "IMPERIAL_ORDER.Animations.CleanupV259", function()
        for _, client in ipairs(player.GetAll()) do
            ResetPoseBones(client)
        end
    end)

    -- Remove the old Perfect Hands client owners during lua_refresh. A full
    -- restart is still required to unregister the removed SWEP cleanly.
    for _, data in ipairs({
        {"Think", "ixPerfectHandsApplyAnimations"},
        {"PlayerSwitchWeapon", "ixPerfectHandsImmediateBoneCleanup"},
        {"VManipPrePlayAnim", "ixPerfectHandsVManipCompatibility"},
        {"ShouldDisableLegs", "ixPerfectHandsLegsCompatibility"},
        {"ShutDown", "ixPerfectHandsClientCleanup"},
        {"CalcView", "ixPerfectHandsAnimationView"},
        {"InputMouseApply", "ixPerfectHandsFreelook"}
    }) do
        hook.Remove(data[1], data[2])
    end

    ix.perfectHands = nil
end
