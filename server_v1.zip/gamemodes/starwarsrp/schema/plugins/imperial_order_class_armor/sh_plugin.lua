PLUGIN.name = "Imperial Order Class Armor Support"
PLUGIN.author = "OpenAI"
PLUGIN.description = "Applies CLASS.armor and CLASS.maxArmor values when Helix characters spawn, load, or switch classes."

if (CLIENT) then
    return
end

local function GetClassTable(character)
    if (not character or not ix or not ix.class or not ix.class.list) then
        return nil
    end

    local classIndex = character:GetClass()

    if (not isnumber(classIndex) or classIndex <= 0) then
        return nil
    end

    return ix.class.list[classIndex]
end

local function ApplyClassArmor(client, character)
    if (not IsValid(client) or not client:IsPlayer()) then
        return
    end

    character = character or client:GetCharacter()

    if (not character or client:GetCharacter() ~= character) then
        return
    end

    local classTable = GetClassTable(character)

    if (not classTable) then
        client:SetArmor(0)

        if (client.SetMaxArmor) then
            client:SetMaxArmor(0)
        end

        return
    end

    local startingArmor = math.max(tonumber(classTable.armor) or 0, 0)
    local maximumArmor = math.max(tonumber(classTable.maxArmor) or startingArmor, startingArmor)

    if (client.SetMaxArmor) then
        client:SetMaxArmor(maximumArmor)
    end

    client:SetArmor(startingArmor)
end

local function QueueClassArmor(client, character)
    timer.Simple(0, function()
        ApplyClassArmor(client, character)
    end)
end

function PLUGIN:PostPlayerLoadout(client)
    QueueClassArmor(client, client:GetCharacter())
end

function PLUGIN:PlayerLoadedCharacter(client, character)
    QueueClassArmor(client, character)
end

function PLUGIN:PlayerJoinedClass(client)
    QueueClassArmor(client, client:GetCharacter())
end

function PLUGIN:CharacterVarChanged(character, key)
    if (key ~= "class") then
        return
    end

    local client = character:GetPlayer()

    if (IsValid(client)) then
        QueueClassArmor(client, character)
    end
end
