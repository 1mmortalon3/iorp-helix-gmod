hook.Add("OnCharacterCreated", "IMPERIAL_ORDER.V236.StartingCredits", function(client, character)
    if not character then return end
    local amount = ix.config.Get("startingCredits", 500)
    if type(character.SetCredits) == "function" then
        character:SetCredits(amount)
    elseif type(character.SetVar) == "function" then
        character:SetVar("credits", amount)
    end
end)

hook.Add("PlayerShouldTakeDamage", "IMPERIAL_ORDER.V235.PvPControl", function(victim, attacker)
    if not IsValid(attacker) or not attacker:IsPlayer() or not IsValid(victim) or not victim:IsPlayer() then return end
    if not ix.config.Get("pvpEnabled", true) then return false end
    if ix.config.Get("factionPvp", false) then
        local victimChar = victim:GetCharacter()
        local attackerChar = attacker:GetCharacter()
        if victimChar and attackerChar and victimChar:GetFaction() == attackerChar:GetFaction() then return false end
    end
end)

local function PublishMap()
    SetGlobalString("imperial_order_world", game.GetMap() ~= "" and game.GetMap() or "unknown_map")
end
hook.Add("Initialize", "IMPERIAL_ORDER.V235.PublishMap", PublishMap)
hook.Add("InitPostEntity", "IMPERIAL_ORDER.V235.PublishMapPost", PublishMap)
