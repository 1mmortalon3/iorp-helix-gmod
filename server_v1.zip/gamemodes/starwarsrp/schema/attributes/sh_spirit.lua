ATTRIBUTE.name = "Spirit"
ATTRIBUTE.description = "Discipline, resolve, and loyalty under Imperial pressure."
ATTRIBUTE.maxValue = 100
ATTRIBUTE.startingMax = 0
