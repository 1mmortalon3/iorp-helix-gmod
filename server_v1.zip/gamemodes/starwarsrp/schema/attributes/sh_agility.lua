ATTRIBUTE.name = "Agility"
ATTRIBUTE.description = "Speed and reflexes."
ATTRIBUTE.maxValue = 100
ATTRIBUTE.startingMax = 0
