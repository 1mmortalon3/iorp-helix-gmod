ATTRIBUTE.name = "Intellect"
ATTRIBUTE.description = "Technical reasoning."
ATTRIBUTE.maxValue = 100
ATTRIBUTE.startingMax = 0
