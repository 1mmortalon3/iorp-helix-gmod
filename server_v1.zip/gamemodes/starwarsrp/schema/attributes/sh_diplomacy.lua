ATTRIBUTE.name = "Diplomacy"
ATTRIBUTE.description = "Social influence."
ATTRIBUTE.maxValue = 100
ATTRIBUTE.startingMax = 0
