
ix.db = ix.db or {
	schema = {},
	schemaQueue = {},
	type = {
		-- TODO: more specific types, lengths, and defaults
		-- i.e INT(11) UNSIGNED, SMALLINT(4), LONGTEXT, VARCHAR(350), NOT NULL, DEFAULT NULL, etc
		[ix.type.string] = "VARCHAR(255)",
		[ix.type.text] = "TEXT",
		[ix.type.number] = "INT(11)",
		[ix.type.steamid] = "VARCHAR(20)",
		[ix.type.bool] = "TINYINT(1)"
	}
}

ix.db.config = ix.config.server.database or {}

function ix.db.Connect()
	ix.db.config.adapter = ix.db.config.adapter or "sqlite"

	local dbmodule = ix.db.config.adapter
	local hostname = ix.db.config.hostname
	local username = ix.db.config.username
	local password = ix.db.config.password
	local database = ix.db.config.database
	local port = ix.db.config.port

	mysql:SetModule(dbmodule)
	mysql:Connect(hostname, username, password, database, port)
end

function ix.db.AddToSchema(schemaType, field, fieldType)
	if (!ix.db.type[fieldType]) then
		error(string.format("attempted to add field in schema with invalid type '%s'", fieldType))
		return
	end

	if (!mysql:IsConnected() or !ix.db.schema[schemaType]) then
		ix.db.schemaQueue[#ix.db.schemaQueue + 1] = {schemaType, field, fieldType}
		return
	end

	ix.db.InsertSchema(schemaType, field, fieldType)
end

-- this is only ever used internally
function ix.db.InsertSchema(schemaType, field, fieldType)
	local schema = ix.db.schema[schemaType]

	if (!schema) then
		error(string.format("attempted to insert into schema with invalid schema type '%s'", schemaType))
		return
	end

	if (!schema[field]) then
		schema[field] = true

		local query = mysql:Update("ix_schema")
			query:Update("columns", util.TableToJSON(schema))
			query:Where("table", schemaType)
		query:Execute()

		query = mysql:Alter(schemaType)
			query:Add(field, ix.db.type[fieldType])
		query:Execute()
	end
end


-- Imperial Order: verify the physical SQLite character table instead of
-- trusting ix_schema blindly. Helix updates ix_schema before ALTER TABLE, so
-- an interrupted/failed ALTER can leave metadata claiming a column exists
-- while ix_characters is still missing it.
local function ImperialOrderSQLDefault(value)
	if (isnumber(value)) then
		return tostring(value)
	elseif (isbool(value)) then
		return value and "1" or "0"
	elseif (isstring(value)) then
		return "'" .. mysql:Escape(value) .. "'"
	end
end

function ix.db.EnsureCharacterSchema()
	if (mysql.module != "sqlite" or !mysql:IsConnected()) then
		return true
	end

	if (!ix.char or !ix.char.vars) then
		return false
	end

	ix.db._imperialOrderCharacterSchemaVerified = false
	ix.db.EnsureBaseTables()

	local info = sql.Query("PRAGMA table_info(`ix_characters`)")
	if (info == false) then
		ErrorNoHalt("[Imperial Order] Could not inspect ix_characters: " .. tostring(sql.LastError()) .. "\n")
		return false
	end

	local physical = {}
	for _, column in ipairs(info or {}) do
		if (column.name) then
			physical[tostring(column.name)] = true
		end
	end

	local schema = ix.db.schema["ix_characters"] or {}
	local changed = false
	local brandPrefix = "imperial_order_"
	-- Support every pre-Imperial Order database generation without keeping their
	-- old brand identifiers as literal strings in the codebase. Ordered newest
	-- first: the immediately previous brand prefix, then the one before that,
	-- then the oldest four-letter prefix.
	local legacyPrefixes = {
		string.char(112, 114, 97, 120, 117, 115, 95, 105, 109, 112, 101, 114, 105, 97, 108, 95),
		string.char(111, 98, 115, 105, 100, 105, 97, 110, 95),
		string.char(105, 111, 114, 112, 95)
	}

	for _, data in pairs(ix.char.vars) do
		if (data.field) then
			local field = tostring(data.field)
			local added = false

			if (!physical[field]) then
				local fieldType = ix.db.type[data.fieldType or ix.type.string] or "TEXT"
				local safeField = string.Replace(field, "`", "``")
				local statement = "ALTER TABLE `ix_characters` ADD `" .. safeField .. "` " .. fieldType
				local result = sql.Query(statement)

				if (result == false) then
					ErrorNoHalt(
						"[Imperial Order] Failed to create character column '" ..
						field .. "': " .. tostring(sql.LastError()) .. "\n"
					)
					return false
				end

				physical[field] = true
				added = true
				changed = true
				MsgC(Color(120, 220, 255), "[Imperial Order] Repaired character database column: " .. field .. "\n")
			end

			-- If this is a renamed Imperial Order field and a pre-rebrand column still
			-- exists, copy its value into the new column before applying defaults.
			if (string.sub(field, 1, #brandPrefix) == brandPrefix) then
				local suffix = string.sub(field, #brandPrefix + 1)
				local safeNew = string.Replace(field, "`", "``")

				for _, legacyPrefix in ipairs(legacyPrefixes) do
					local legacyField = legacyPrefix .. suffix
					if (physical[legacyField]) then
						local safeOld = string.Replace(legacyField, "`", "``")
						local migrate = sql.Query(
							"UPDATE `ix_characters` SET `" .. safeNew .. "` = `" .. safeOld ..
							"` WHERE `" .. safeNew .. "` IS NULL"
						)

						if (migrate == false) then
							ErrorNoHalt("[Imperial Order] Could not migrate data into '" .. field .. "': " .. tostring(sql.LastError()) .. "\n")
						else
							break
						end
					end
				end
			end

			-- ALTER TABLE adds NULL values for existing rows. Fill those with the
			-- registered Helix default so existing characters remain loadable.
			if (physical[field] and data.default != nil) then
				local sqlDefault = ImperialOrderSQLDefault(data.default)
				if (sqlDefault) then
					local safeField = string.Replace(field, "`", "``")
					local fill = sql.Query(
						"UPDATE `ix_characters` SET `" .. safeField .. "` = " .. sqlDefault ..
						" WHERE `" .. safeField .. "` IS NULL"
					)

					if (fill == false) then
						ErrorNoHalt("[Imperial Order] Could not apply default for '" .. field .. "': " .. tostring(sql.LastError()) .. "\n")
					end
				end
			end

			if (!schema[field]) then
				schema[field] = true
				changed = true
			end
		end
	end

	ix.db.schema["ix_characters"] = schema

	if (changed) then
		local query = mysql:Update("ix_schema")
			query:Update("columns", util.TableToJSON(schema))
			query:Where("table", "ix_characters")
			query:Execute()
	end

	ix.db._imperialOrderCharacterSchemaVerified = true
	return true
end

-- Keep player table creation reusable for SQLite startup recovery.
function ix.db.EnsurePlayerTable()
	if (!mysql:IsConnected()) then
		return false
	end

	local query
	query = mysql:Create("ix_players")
		query:Create("steamid", "VARCHAR(20) NOT NULL")
		query:Create("steam_name", "VARCHAR(32) NOT NULL")
		query:Create("play_time", "INT(11) UNSIGNED DEFAULT NULL")
		query:Create("address", "VARCHAR(15) DEFAULT NULL")
		query:Create("last_join_time", "INT(11) UNSIGNED DEFAULT NULL")
		query:Create("data", "TEXT")
		query:PrimaryKey("steamid")
	query:Execute()

	return mysql.module != "sqlite" or sql.TableExists("ix_players")
end

function ix.db.EnsureBaseTables()
	-- Reusable, non-destructive bootstrap for startup and early player loads.
	ix.db.EnsurePlayerTable()

	local query

	query = mysql:Create("ix_schema")
		query:Create("table", "VARCHAR(64) NOT NULL")
		query:Create("columns", "TEXT NOT NULL")
		query:PrimaryKey("table")
	query:Execute()

	-- table structure will be populated with more fields when vars
	-- are registered using ix.char.RegisterVar
	query = mysql:Create("ix_characters")
		query:Create("id", "INT(11) UNSIGNED NOT NULL AUTO_INCREMENT")
		query:PrimaryKey("id")
	query:Execute()

	query = mysql:Create("ix_inventories")
		query:Create("inventory_id", "INT(11) UNSIGNED NOT NULL AUTO_INCREMENT")
		query:Create("character_id", "INT(11) UNSIGNED NOT NULL")
		query:Create("inventory_type", "VARCHAR(150) DEFAULT NULL")
		query:PrimaryKey("inventory_id")
	query:Execute()

	query = mysql:Create("ix_items")
		query:Create("item_id", "INT(11) UNSIGNED NOT NULL AUTO_INCREMENT")
		query:Create("inventory_id", "INT(11) UNSIGNED NOT NULL")
		query:Create("unique_id", "VARCHAR(60) NOT NULL")
		query:Create("character_id", "INT(11) UNSIGNED DEFAULT NULL")
		query:Create("player_id", "VARCHAR(20) DEFAULT NULL")
		query:Create("data", "TEXT DEFAULT NULL")
		query:Create("x", "SMALLINT(4) NOT NULL")
		query:Create("y", "SMALLINT(4) NOT NULL")
		query:PrimaryKey("item_id")
	query:Execute()



	-- populate schema table if rows don't exist
	query = mysql:InsertIgnore("ix_schema")
		query:Insert("table", "ix_characters")
		query:Insert("columns", util.TableToJSON({}))
	query:Execute()

end

function ix.db.LoadTables()
	ix.db.EnsureBaseTables()

	-- load schema from database
	local query = mysql:Select("ix_schema")
		query:Callback(function(result)
			if (!istable(result)) then
				return
			end

			for _, v in pairs(result) do
				ix.db.schema[v.table] = util.JSONToTable(v.columns)
			end

			-- SQLite uses physical columns so stale metadata cannot skip repairs
			-- or trigger duplicate ALTER statements. MySQL retains its queue.
			if (mysql.module == "sqlite") then
				if (!ix.db.EnsureCharacterSchema()) then
					error("[Helix] Character database initialization failed.")
				end
				return
			end

			-- update schema if needed
			for i = 1, #ix.db.schemaQueue do
				local entry = ix.db.schemaQueue[i]
				ix.db.InsertSchema(entry[1], entry[2], entry[3])
			end

			-- Make sure the real SQLite table matches the registered character
			-- variables before any player character SELECT can run.
			ix.db.EnsureCharacterSchema()
		end)
	query:Execute()
end

function ix.db.WipeTables(callback)
	local query

	query = mysql:Drop("ix_schema")
	query:Execute()

	query = mysql:Drop("ix_characters")
	query:Execute()

	query = mysql:Drop("ix_inventories")
	query:Execute()

	query = mysql:Drop("ix_items")
	query:Execute()

	query = mysql:Drop("ix_players")
		query:Callback(callback)
	query:Execute()
end

hook.Add("InitPostEntity", "ixDatabaseConnect", function()
	-- Connect to the database using SQLite, mysqoo, or tmysql4.
	ix.db.Connect()
end)

local resetCalled = 0

concommand.Add("ix_wipedb", function(client, cmd, arguments)
	-- can only be ran through the server's console
	if (!IsValid(client)) then
		if (resetCalled < RealTime()) then
			resetCalled = RealTime() + 3

			MsgC(Color(255, 0, 0),
				"[Helix] WIPING THE DATABASE WILL PERMENANTLY REMOVE ALL PLAYER, CHARACTER, ITEM, AND INVENTORY DATA.\n")
			MsgC(Color(255, 0, 0), "[Helix] THE SERVER WILL RESTART TO APPLY THESE CHANGES WHEN COMPLETED.\n")
			MsgC(Color(255, 0, 0), "[Helix] TO CONFIRM DATABASE RESET, RUN 'ix_wipedb' AGAIN WITHIN 3 SECONDS.\n")
		else
			resetCalled = 0
			MsgC(Color(255, 0, 0), "[Helix] DATABASE WIPE IN PROGRESS...\n")

			hook.Run("OnWipeTables")
			ix.db.WipeTables(function()
				MsgC(Color(255, 255, 0), "[Helix] DATABASE WIPE COMPLETED!\n")
				RunConsoleCommand("changelevel", game.GetMap())
			end)
		end
	end
end)
